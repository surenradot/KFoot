﻿(function ($) {
    function PaymentAddEdit() {
        var $this = this, form;
        var ArrHeadOptions = new Array();
        var validationSettings;

        function paymentItem(id, acpaymentId, acheadMasterId, amount) {
            this.id = id;
            this.acpaymentId = acpaymentId;
            this.acheadMasterId = acheadMasterId;
            this.amount = amount;
            this.headOptions = ArrHeadOptions;
        }

        var paymentViewModel = {
            paymentItems: ko.observableArray([]),
            Isdisabled: ko.observable(false),
            addItem: function () {
                this.paymentItems.push(new paymentItem(0, 0, 0, ""));
            },
            removeItem: function (item) {
                paymentViewModel.paymentItems.remove(item);

            }

        };

        function initilizeModel() {
            validationSettings = {
                ignore: '.ignore'
            };

            form = new Global.FormHelper($("#frm-add-edit-payment").find("form"), { updateTargetId: "validation-summary", validateSettings: validationSettings }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });
            ArrHeadOptions = headoptions;
            ko.applyBindings(paymentViewModel, $('#ko-payment-details')[0]);
            if (headDetailsList != null && headDetailsList.length > 0) {
                var mappedData = ko.utils.arrayMap(headDetailsList, function (item) {
                    return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                });
                paymentViewModel.paymentItems(mappedData);
                paymentViewModel.Isdisabled(true);
            } else {
                var arr = new Array();
                arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                var mappedData = ko.utils.arrayMap(arr, function (item) {
                    return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                });
                paymentViewModel.paymentItems(mappedData);
                paymentViewModel.Isdisabled(true);
            }

            $("#CostCenterId").on("change", function () {
                var headId = $("option:selected", $(this)).data("head");
                var groupId = $("#GroupId").val();
                $.post('/acpayment/GetHeads', { id: groupId, headId: headId }, function (response) {
                    ArrHeadOptions = new Array();
                    ArrHeadOptions.push({ Text: "Select", Value: "" });
                    $.each(response.data, function (index, item) {
                        ArrHeadOptions.push({ Text: item.name, Value: item.id });
                    });
                    var arr = new Array();
                    arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                    var mappedData = ko.utils.arrayMap(arr, function (item) {
                        return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                    });
                    paymentViewModel.paymentItems(mappedData);
                    paymentViewModel.Isdisabled(true);
                });
            });

            $("#GroupId").on("change", function () {
                var headId = '';
                if ($('#CostCenterId')) {
                    headId = $("option:selected", "#CostCenterId").data("head");
                }
                $.post('/acpayment/GetHeads', { id: $(this).val(), headId: headId }, function (response) {
                    ArrHeadOptions = new Array();
                    ArrHeadOptions.push({ Text: "Select", Value: "" });
                    $.each(response.data, function (index, item) {
                        ArrHeadOptions.push({ Text: item.name, Value: item.id });
                    });
                    var arr = new Array();
                    arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                    var mappedData = ko.utils.arrayMap(arr, function (item) {
                        return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                    });
                    paymentViewModel.paymentItems(mappedData);
                    paymentViewModel.Isdisabled(true);
                });

                switch (parseInt($(this).val())) {
                    case 1:
                        $("#div_PartyId").show();
                        $("#PartyType").val("1");
                        BindStaffList($(this).val());
                        $("#PartyId").removeClass('ignore');
                        break;
                    case 2:
                        $("#div_PartyId").show();
                        $("#PartyType").val("2");
                        BindPartyList($(this).val());
                        $("#PartyId").removeClass('ignore');
                        break;
                    case 3:
                        $("#div_PartyId").hide();
                        $("#PartyType").val("3");
                        $("#PartyId").val('');
                        $("#PartyId").addClass('ignore');
                        break;
                    case 4:
                        $("#div_PartyId").hide();
                        $("#PartyType").val("4");
                        $("#PartyId").val('');
                        $("#PartyId").addClass('ignore');
                        break;
                }
            });

            $("#PaymentMode").on('change', function () {
                switch (parseInt($(this).val())) {
                    case 1:
                        $("#TransactionNo").addClass('ignore');
                        $("#div_TransactionNo").hide();
                        $("#TransactionNo").val('');
                        $("#TransactionDate").addClass('ignore');
                        $("#div_TransactionDate").hide();
                        $("#TransactionDate").val('');
                        $("#AcbankId").addClass('ignore');
                        $("#div_AcbankId").hide();
                        $("#AcbankId").val('');
                        break;
                    case 2:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("DD No");
                        $("#div_TransactionDate").find('label').html("DD Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');

                        break;
                    case 3:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Cheque No");
                        $("#div_TransactionDate").find('label').html("Cheque Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        break;
                    case 4:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        break;
                    case 5:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        break;
                    case 6:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        break;
                    default:
                }
            });

            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $(".btn-submit").click(function () {
                $("#frm-add-edit-payment form").append('<input type="hidden" value="' + $(this).data('action') + '" name="submittype" />');
            });

        }

        function BindStaffList(groupId) {
            var $PartyId = $("#PartyId");
            $PartyId.parent().find('label').html('Staff');
            $.get('/acpayment/getstaff', { id: groupId }, function (response) {
                $PartyId.empty();
                $PartyId.append('<option value="">--Select--</option>');
                $.each(response.data, function (index, item) {
                    $PartyId.append(
                        '<option value="' + item.id + '">'
                        + item.name +
                        '</option>');
                });
            });
        }


        function BindPartyList() {
            var $PartyId = $("#PartyId");
            $PartyId.parent().find('label').html('Party');
            $.get('/acpayment/getparty', function (response) {
                $PartyId.empty();
                $PartyId.append('<option value="">--Select--</option>');
                $.each(response.data, function (index, item) {
                    $PartyId.append(
                        '<option value="' + item.id + '">'
                        + item.name +
                        '</option>');
                });
            });
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new PaymentAddEdit();
        self.init();
    })
})(jQuery);