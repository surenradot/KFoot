﻿(function ($) {
    function PartyIndex() {
        var $this = this, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "First Name", "data": "FirstName", "orderable": true, "searchable": true },
                    { "title": "Last Name", "data": "LastName", "orderable": true, "searchable": true },
                    { "title": "Mobile No", "data": "MobileNo", "orderable": true, "searchable": true },
                    { "title": "IFSC Code", "data": "Ifsccode", "orderable": true, "searchable": true },
                    { "title": "Account No", "data": "AccountNo", "orderable": false, "searchable": false },
                    { "title": "BankName", "data": "BankName", "orderable": false, "searchable": false },
                    { "title": "Branch", "data": "Branch", "orderable": false, "searchable": false },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/acparty/modify/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-add-edit-party' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/acparty/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-party' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/acparty/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-party' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initilizeModel() {

            $("#modal-add-edit-party").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-party").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        $this.init = function () {
            initializeGrid();
            initilizeModel();
        }
    }

    $(function () {
        var self = new PartyIndex();
        self.init();
    })
})(jQuery)