﻿(function ($) {
    function ReceiptAddEdit() {
        var $this = this, form;
        var ArrHeadOptions = new Array();
        var validationSettings;

        function paymentItem(id, acpaymentId, acheadMasterId, amount) {
            this.id = id;
            this.acpaymentId = acpaymentId;
            this.acheadMasterId = acheadMasterId;
            this.amount = amount;
            this.headOptions = ArrHeadOptions;
        }

        var paymentViewModel = {
            paymentItems: ko.observableArray([]),
            Isdisabled: ko.observable(false),
            addItem: function () {
                this.paymentItems.push(new paymentItem(0, 0, 0, ""));
            },
            removeItem: function (item) {
                paymentViewModel.paymentItems.remove(item);

            }

        };

        function initilizeModel() {
            validationSettings = {
                ignore: '.ignore'
            };

            form = new Global.FormHelper($("#frm-add-edit-receipt").find("form"), { updateTargetId: "validation-summary", validateSettings: validationSettings }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });

            ArrHeadOptions = headoptions;

            ko.applyBindings(paymentViewModel, $('#ko-payment-details')[0]);
            if (headDetailsList != null && headDetailsList.length > 0) {
                var mappedData = ko.utils.arrayMap(headDetailsList, function (item) {
                    return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                });
                paymentViewModel.paymentItems(mappedData);
                paymentViewModel.Isdisabled(true);
            } else {
                var arr = new Array();
                arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                var mappedData = ko.utils.arrayMap(arr, function (item) {
                    return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                });
                paymentViewModel.paymentItems(mappedData);
                paymentViewModel.Isdisabled(true);
            }




            $("#IsParty").click(function () {
                if ($(this).prop("checked")) {
                    BindPartyList();
                    $("#PartyType").val(2);
                    $("#div_PartyId").show();
                    $("#PartyId").removeClass('ignore');
                }
                else if (!$(this).prop("checked")) {
                    $("#div_PartyId").hide();
                    $("#PartyId").val('');
                    $("#PartyType").val(1);
                    $("#PartyId").addClass('ignore');
                }
            });


            $("#CostCenterId").on("change", function () {
                var headId = $("option:selected", $(this)).data("head");
                var groupId = $("#GroupId").val();
                paymentViewModel.paymentItems(mappedData);
                $.post('/acreceipt/GetHeads', { id: groupId, headId: headId }, function (response) {
                    ArrHeadOptions = new Array();
                    ArrHeadOptions.push({ Text: "Select", Value: "" });
                    $.each(response.data, function (index, item) {
                        ArrHeadOptions.push({ Text: item.name, Value: item.id });
                    });

                    var arr = new Array();
                    arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                    var mappedData = ko.utils.arrayMap(arr, function (item) {
                        return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                    });
                    paymentViewModel.paymentItems(mappedData);
                    paymentViewModel.Isdisabled(true);

                });

            });

            $("#GroupId").on("change", function () {
                var headId = '';
                if ($('#CostCenterId')) {
                    headId = $("option:selected", "#CostCenterId").data("head");
                }
                paymentViewModel.paymentItems(mappedData);
                $.post('/acreceipt/GetHeads', { id: $(this).val(), headId: headId }, function (response) {
                    ArrHeadOptions = new Array();
                    ArrHeadOptions.push({ Text: "Select", Value: "" });
                    $.each(response.data, function (index, item) {
                        ArrHeadOptions.push({ Text: item.name, Value: item.id });
                    });

                    var arr = new Array();
                    arr.push({ Id: 0, AcpaymentId: 0, AcheadMasterId: "", Amount: "" });
                    var mappedData = ko.utils.arrayMap(arr, function (item) {
                        return new paymentItem(item.Id, item.AcpaymentId, item.AcheadMasterId, item.Amount);
                    });
                    paymentViewModel.paymentItems(mappedData);
                    paymentViewModel.Isdisabled(true);

                });

                switch (parseInt($(this).val())) {
                    case 1:
                        $("#div_PartyId").show();
                        $("#div_IsParty").hide();
                        $("#PartyId").removeClass('ignore');
                        $("#PartyType").val("1");
                        $("#IsParty").prop("checked", false);
                        BindStaffList($(this).val());
                        break;
                    case 2:
                        $("#div_PartyId").show();
                        $("#div_IsParty").hide();
                        $("#PartyId").removeClass('ignore');
                        $("#IsParty").prop("checked", false);
                        $("#PartyType").val("2");
                        BindPartyList($(this).val());
                        break;
                    case 3:
                        $("#div_PartyId").show();
                        $("#div_IsParty").hide();
                        $("#PartyId").removeClass('ignore');
                        $("#IsParty").prop("checked", false);
                        break;
                    case 4:
                        $("#PartyType").val("1");
                        $("#div_PartyId").hide();
                        $("#PartyId").val('');
                        $("#PartyId").addClass('ignore');
                        $("#div_IsParty").show();
                        break;
                    case 5:
                        $("#div_PartyId").show();
                        $("#div_IsParty").hide();
                        $("#PartyId").removeClass('ignore');
                        break;
                    default:

                }
            });

            $("#PaymentMode").on('change', function () {
                switch (parseInt($(this).val())) {
                    case 1:
                        $("#TransactionNo").addClass('ignore');
                        $("#div_TransactionNo").hide();
                        $("#TransactionNo").val('');
                        $("#TransactionDate").addClass('ignore');
                        $("#div_TransactionDate").hide();
                        $("#TransactionDate").val('');
                        $("#div_BankName").hide();
                        $("#BankName").addClass('ignore');
                        $("#BankName").val('');
                        $("#div_ReceivedBankId").hide();
                        $("#ReceivedBankId").addClass('ignore');
                        $("#ReceivedBankId").val('');
                        break;
                    case 2:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("DD No");
                        $("#div_TransactionDate").find('label').html("DD Date");
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        $("#div_BankName").show();
                        $("#BankName").removeClass('ignore');

                        break;
                    case 3:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Cheque No");
                        $("#div_TransactionDate").find('label').html("Cheque Date");
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        $("#div_BankName").show();
                        $("#BankName").removeClass('ignore');
                        break;
                    case 4:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        $("#div_BankName").show();
                        $("#BankName").removeClass('ignore');
                        break;
                    case 5:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        $("#div_BankName").show();
                        $("#BankName").removeClass('ignore');
                        break;
                    case 6:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        $("#div_BankName").show();
                        $("#BankName").removeClass('ignore');
                        break;
                    default:
                }
            });

            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $(".btn-submit").click(function () {
                $("#frm-add-edit-receipt form").append('<input type="hidden" value="' + $(this).data('action') + '" name="submittype" />');
            });

        }

        function BindStaffList(groupId) {
            var $PartyId = $("#PartyId");
            $PartyId.parent().find('label').html('Student');
            $.get('/acreceipt/getstudent', { id: groupId }, function (response) {
                $PartyId.empty();
                $PartyId.append('<option value="">--Select--</option>');
                $.each(response.data, function (index, item) {
                    $PartyId.append(
                        '<option value="' + item.id + '">'
                        + item.name +
                        '</option>');
                });
            });
        }


        function BindPartyList() {
            var $PartyId = $("#PartyId");
            $PartyId.parent().find('label').html('Party');
            $.get('/acreceipt/getparty', function (response) {
                $PartyId.empty();
                $PartyId.append('<option value="">--Select--</option>');
                $.each(response.data, function (index, item) {
                    $PartyId.append(
                        '<option value="' + item.id + '">'
                        + item.name +
                        '</option>');
                });
            });
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new ReceiptAddEdit();
        self.init();
    })
})(jQuery)