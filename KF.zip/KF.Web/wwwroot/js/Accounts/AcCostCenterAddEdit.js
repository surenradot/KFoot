﻿(function ($) {
    function CostCenterAddEdit() {
        var $this = this, form;
        var ArrHeadOptions = new Array();
        var validationSettings;



        function initilizeModel() {
            validationSettings = {
                ignore: '.ignore'
            };

            $('.nav-tabs a').click(function () {
                $(this).tab('show');
            });

            form = new Global.FormHelper($("#frm-add-edit-costcenter form"), { updateTargetId: "validation-summary", validateSettings: validationSettings }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });

            $("#mainpaymentheadch").click(function () {
                if ($(this).prop("checked")) {
                    $(".paymentheadch").prop("checked", true);
                } else {
                    $(".paymentheadch").prop("checked", false);
                }
            });


            $(".paymentheadch").click(function () {
                var totalLi = $(".paymentheadch").length;
                var totalCheckedLi = $(".paymentheadch:checked").length;
                if (totalLi == totalCheckedLi) {
                    $("#mainpaymentheadch").prop("checked", true);
                } else {
                    $("#mainpaymentheadch").prop("checked", false);
                }
            });

            $("#mainreceiptheadch").click(function () {
                if ($(this).prop("checked")) {
                    $(".receiptheadch").prop("checked", true);
                } else {
                    $(".receiptheadch").prop("checked", false);
                }
            });            

            $(".receiptheadch").click(function () {
                var totalLi = $(".receiptheadch").length;
                var totalCheckedLi = $(".receiptheadch:checked").length;
                if (totalLi == totalCheckedLi) {
                    $("#mainreceiptheadch").prop("checked", true);
                } else {
                    $("#mainreceiptheadch").prop("checked", false);
                }
            });
        }

        function CheckHead() {
            var totalLi = $(".receiptheadch").length;
            var totalCheckedLi = $(".receiptheadch:checked").length;
            if (totalLi == totalCheckedLi) {
                $("#mainreceiptheadch").prop("checked", true);
            } else {
                $("#mainreceiptheadch").prop("checked", false);
            }



            var totalLi1 = $(".paymentheadch").length;
            var totalCheckedLi1 = $(".paymentheadch:checked").length;
            if (totalLi1 == totalCheckedLi1) {
                $("#mainpaymentheadch").prop("checked", true);
            } else {
                $("#mainpaymentheadch").prop("checked", false);
            }
        }


        $this.init = function () {
            initilizeModel();
            CheckHead();
        }
    }

    $(function () {
        var self = new CostCenterAddEdit();
        self.init();
    })
})(jQuery)