﻿(function ($) {
    function AcReport() {
        var $this = this, form;
        function initilizeModel() {


            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $("#btn-daybook").click(function () {
                if ($("#frm-acreport").valid()) {
                    $("#repotdetails").html('');
                    $("#repotdetails_hide").hide();
                    var fromDate = moment($("#fromdate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                    var toDate = moment($("#todate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                    Global.ShowLoading();
                    $.ajax('/acreport/getdaybook', {
                        type: "GET",
                        data: { from: fromDate, to: toDate, paymentmode: $("#paymentmode").val(), isDetail: false },
                        success: function (response) {
                            $("#repotdetails").html(response);
                            $("#repotdetails_hide").show();
                        },
                        error: function (jqXHR, status, error) {
                            Global.ShowErrorMessage(jqXHR.responseText);
                            Global.HideLoading();

                        },
                        complete: function () {
                            Global.HideLoading();
                        }
                    });
                }

            });

            $("#btn-daybook-details").click(function () {
                if ($("#frm-acreport").valid()) {
                    $("#repotdetails").html('');
                    $("#repotdetails_hide").hide();
                    var fromDate = moment($("#fromdate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                    var toDate = moment($("#todate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                    Global.ShowLoading();
                    $.ajax('/acreport/getdaybook', {
                        type: "GET",
                        data: { from: fromDate, to: toDate, paymentmode: $("#paymentmode").val(), isDetail: true },
                        success: function (response) {
                            $("#repotdetails").html(response);
                            $("#repotdetails_hide").show();
                        },
                        error: function (jqXHR, status, error) {
                            Global.ShowErrorMessage(jqXHR.responseText);
                            Global.HideLoading();

                        },
                        complete: function () {
                            Global.HideLoading();
                        }
                    });
                }

            });

            $("#viewDetails").click(function () {
                if ($("#frm-acreport").valid()) {
                    $("#repotdetails").html('');
                    var memberType = $("#membertype").val();
                    var url = '';
                    if (parseInt(memberType) == 1) {
                        url = '/acreport/GetStatudent';
                    }
                    else if (parseInt(memberType) == 2) {
                        url = '/acreport/GetStaff';
                    }
                    else if (parseInt(memberType) == 3) {
                        url = '/acreport/GetParty';
                    }
                    Global.ShowLoading();
                    $.ajax(url, {
                        type: "GET",
                        success: function (response) {
                            $("#repotdetails").html(response);
                            $(".viewledger").off("click").on("click", function () {
                                var id = $(this).data('id');
                                var type = $(this).data('type');
                                var fromDate = moment($("#fromdate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                                var toDate = moment($("#todate").val(), 'DD/MM/YYYY').format('DD-MM-YYYY');
                                var url = '/acreport/Ledgerr/' + id + '?type=' + type + '&fromDate=' + fromDate + '&toDate=' + toDate;
                                window.open(url, '_blank');
                            });
                            $('#TableId').DataTable({
                                'paging': true,
                                'pageLength': 10,
                                'lengthChange': true,
                                'searching': true,
                                'ordering': true,
                                'info': true,
                                'autoWidth': false,
                                'processing': true,

                                'language':
                                {
                                    'processing': "<div class=''><i class='fa fa-cog fa-spin site-loader-color'></i></div>",
                                    'search': "Search:",
                                    'searchPlaceholder': "find your text"
                                },
                                'dom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                                'columnDefs': [
                                    { "className": "text-center", "targets": [0, 5] },
                                    { "searchable": true, "targets": [1, 4] },
                                    { "defaultContent": "", "targets": [3] },
                                    { "orderable": true, "targets": [1, 4] }
                                ],
                            });

                        },
                        error: function (jqXHR, status, error) {
                            Global.ShowErrorMessage(jqXHR.responseText);
                            Global.HideLoading();
                        },
                        complete: function () {
                            Global.HideLoading();
                        }
                    });
                }

            });

            $("#btn-costcenter").click(function () {
                var costCenterId = $("#costcenterddl").val();
                GetCostCenterReport(costCenterId);

            });

            if ($('#showcosrcenter') && parseInt($("#showcosrcenter").val()) == 1) {
                GetCostCenterReport('');
            }

            $(".print-btn").click(function () {
                var title = $(this).data('title');
                var divId = $(this).data("id");
                Popup(divId, title);
            });

            $(".pdf-btn").click(function () {
                var pdfForm = $('#pdfForm');
                var divId = $(this).data("id");
                pdfForm.find("input[name='htmlContent']").val($("#" + divId).html());
                pdfForm.submit();
            });


            $(".print_sub_btn").click(function () {

                var htmlContent = $(this).parent().parent().parent().parent().html();
                var css = $("#stylecss").html();
                var $html = '<div>' + css + htmlContent + '</div>';
                var title = $(this).parent().parent().find(".title").val();
                PopupWithHtml($html, title);
            });


            function GetCostCenterReport(costCenterId) {
                $("#repotdetails").html('');
                $("#repotdetails_hide").hide();
                Global.ShowLoading();
                $.ajax('/acreport/getcostcenter', {
                    type: "GET",
                    data: { id: costCenterId },
                    success: function (response) {
                        $("#repotdetails").html(response);
                        $("#repotdetails_hide").show();
                    },
                    error: function (jqXHR, status, error) {
                        Global.ShowErrorMessage(jqXHR.responseText);
                        Global.HideLoading();

                    },
                    complete: function () {
                        Global.HideLoading();
                    }
                });
            }

            function Popup(divName, title) {
                var DocumentContainer = document.getElementById(divName);
                var mywindow = window.open('', 'new div', 'height=400,width=600');
                mywindow.document.write('<html><head><title>' + title + '</title>');
                mywindow.document.write('</head><body >');
                mywindow.document.writeln(DocumentContainer.innerHTML);
                mywindow.document.write('</body></html>');
                mywindow.print();
                mywindow.close();

                return true;
            }

            function PopupWithHtml(html, title) {
                var DocumentContainer = document.getElementById(divName);
                var mywindow = window.open('', 'new div', 'height=400,width=600');
                mywindow.document.write('<html><head><title>' + title + '</title>');
                mywindow.document.write('</head><body >');
                mywindow.document.writeln(html);
                mywindow.document.write('</body></html>');
                mywindow.print();
                mywindow.close();

                return true;
            }
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new AcReport();
        self.init();
    })
})(jQuery)