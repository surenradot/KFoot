﻿(function ($) {
    function ContraAddEdit() {
        var $this = this, form;
        var validationSettings;

        function initilizeModel() {
            validationSettings = {
                ignore: '.ignore'
            };

            form = new Global.FormHelper($("#frm-add-edit-contra").find("form"), { updateTargetId: "validation-summary", validateSettings: validationSettings }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });


            $("#PaymentMode").on('change', function () {
                switch (parseInt($(this).val())) {
                    case 1:
                        $("#TransactionNo").addClass('ignore');
                        $("#div_TransactionNo").hide();
                        $("#TransactionNo").val('');
                        $("#TransactionDate").addClass('ignore');
                        $("#div_TransactionDate").hide();
                        $("#TransactionDate").val('');
                        $("#AcbankId").addClass('ignore');
                        $("#div_AcbankId").hide();
                        $("#AcbankId").val('');
                        $("#div_ReceivedBankId").hide();
                        $("#ReceivedBankId").val('');
                        $("#ReceivedBankId").addClass('ignore');
                        break;
                    case 2:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("DD No");
                        $("#div_TransactionDate").find('label').html("DD Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');

                        break;
                    case 3:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Cheque No");
                        $("#div_TransactionDate").find('label').html("Cheque Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        break;
                    case 4:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        break;
                    case 5:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        break;
                    case 6:
                        $("#TransactionNo").removeClass('ignore');
                        $("#div_TransactionNo").show();
                        $("#TransactionDate").removeClass('ignore');
                        $("#div_TransactionDate").show();
                        $("#div_TransactionNo").find('label').html("Transaction No");
                        $("#div_TransactionDate").find('label').html("Transaction Date");
                        $("#div_AcbankId").show();
                        $("#AcbankId").removeClass('ignore');
                        $("#div_ReceivedBankId").show();
                        $("#ReceivedBankId").removeClass('ignore');
                        break;
                    default:
                }
            });

            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $("input[name='Radiotype']").change(function () {
                if (parseInt($(this).val()) == 1) {
                    $("#div_PartyId").find('label').html("To Bank");
                    $("#div_PaymentMode").hide();
                    $("#PaymentMode").val('');
                    $("#PaymentMode").addClass('ignore');
                    $("#div_TransactionNo").hide();
                    $("#TransactionNo").val('');
                    $("#TransactionNo").addClass('ignore');                    
                    $("#div_ReceivedBankId").hide();
                } else {               
                    $("#div_PartyId").find('label').html("From Bank");
                    $("#div_PaymentMode").show();
                    $("#TransactionNo").removeClass('ignore');
                    $("#PaymentMode").removeClass('ignore');
                }
            });

        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new ContraAddEdit();
        self.init();
    })
})(jQuery)