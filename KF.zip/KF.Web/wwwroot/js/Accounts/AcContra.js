﻿(function ($) {
    function ContraIndex() {
        var $this = this, form;
        var validationSettings;




        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [                    
                    { "title": "Date", "data": "Date", "orderable": true, "searchable": true },
                    { "title": "Voucher No", "data": "EntryNo", "orderable": true, "searchable": true },
                    { "title": "Particular (From)", "data": "ParticularFrom", "orderable": true, "searchable": true },
                    { "title": "Particular (To)", "data": "ParticularTo", "orderable": true, "searchable": true },
                    { "title": "Amount", "data": "Amount", "orderable": true, "searchable": true }
                    //,{
                    //    "data": null, "title": "Action",
                    //    "targets": -1,
                    //    "width": "20%",
                    //    "class": "column-action text-center",
                    //    "shorting": false,
                    //    "orderable": false,
                    //    "mRender": function (data, type, record) {
                    //        var btns = '';
                    //        btns += "<a href='/acpayment/modify/" + record.Id + "' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                    //        btns += "&nbsp;&nbsp;<a href='/acpayment/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-payment' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                    //        if (!record.IsCancel) {
                    //            btns += "&nbsp;&nbsp;<a href='/acpayment/cancel/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-payment' title= 'Cancel' class='badge btn-sm bg-green-gradient'><i class='fa fa-times'></i></a >";
                    //        }
                    //        return btns;
                    //    }
                    //}
                ],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/accontra/create'  class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initilizeModel() {
            $("#modal-delete-payment").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-cancel").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        $this.init = function () {
            initializeGrid();
            // initilizeModel();
        };
    }

    $(function () {
        var self = new ContraIndex();
        self.init();
    })
})(jQuery)