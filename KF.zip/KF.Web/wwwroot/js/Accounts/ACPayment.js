﻿(function ($) {
    function PaymentIndex() {
        var $this = this, form;
        var ArrHeadOptions = new Array();
        var validationSettings;




        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Entry No", "data": "EntryNo", "orderable": true, "searchable": true },
                    { "title": "Date", "data": "Date", "orderable": true, "searchable": true },
                    { "title": "Particular", "data": "Particular", "orderable": false, "searchable": false },
                    { "title": "Entry Type", "data": "GroupId", "orderable": true, "searchable": true },
                    { "title": "Narration", "data": "Narration", "orderable": true, "searchable": true },
                    { "title": "Amount", "data": "Amount", "orderable": true, "searchable": true },
                    {
                        "title": "Status", "data": "Status", "orderable": true, "searchable": true, "mRender": function (data, type, record) {
                            var btns = '';
                            if (record.Status == 'Active') {
                                btns += '<span class="label label-success">' + record.Status + '</span>';
                            } else {
                                btns += '<span class="label label-warning">' + record.Status + '</span>';
                            }
                            return btns;
                        }
                    },



                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/acpayment/modify/" + record.Id + "' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/acpayment/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-payment' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";

                            if (!record.IsCancel) {
                                btns += "&nbsp;&nbsp;<a href='/acpayment/cancel/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-payment' title= 'Cancel' class='badge btn-sm bg-green-gradient'><i class='fa fa-times'></i></a >";
                            }
                            btns += "&nbsp;&nbsp;<a href='javascript:void(0);'  data-url='/acpayment/print/"+ record.Id + "'  title= 'Print' class='badge btnpvoucherprint btn-sm bg-light'><i class='fa fa-print'></i></a >";
                            btns += "&nbsp;&nbsp;<a href='/acpayment/view/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-print' title= 'View' class='badge btn-sm bg-maroon'><i class='fa fa-eye'></i></a >";
                            btns += "&nbsp;&nbsp;<a href='/acpayment/download/" + record.Id + "' title= 'Download' class='badge btn-sm bg-orange'><i class='fa  fa-download'></i></a >";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route,
                fnCallBack: function () {
                    $(".btnpvoucherprint").click(function () {                        
                        var dataUrl = $(this).data('url');
                        $.get(dataUrl, function (response) {
                            Global.Print(response, 'Voucher');
                        });
                    });
                }
            });
        $("#buttonContainer").addClass("pull-right").append("<a href='/acpayment/create'  class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
    }

    function initilizeModel() {
        $("#modal-delete-payment").on('loaded.bs.modal', function (e) {
            form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });
        }).on('hidden.bs.modal', function (e) {
            $(this).removeData('bs.modal');
        });

        $("#modal-delete-print").on('loaded.bs.modal', function (e) {

            $(".print-btn").click(function(){
                var $html = $("#voucherprint").html();
                Global.Print($html, 'Voucher');
            });

            $(".pdf-btn").click(function () {
                var $html = $("#voucherprint").html();
                Global.Pdf($html, 'Voucher');
            });
            
        }).on('hidden.bs.modal', function (e) {
            $(this).removeData('bs.modal');
        });

        $("#modal-delete-cancel").on('loaded.bs.modal', function (e) {
            form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });
        }).on('hidden.bs.modal', function (e) {
            $(this).removeData('bs.modal');
        });
    }   

    $this.init = function () {
        initializeGrid();
        initilizeModel();
    }
}

    $(function () {
    var self = new PaymentIndex();
    self.init();
})
}) (jQuery)