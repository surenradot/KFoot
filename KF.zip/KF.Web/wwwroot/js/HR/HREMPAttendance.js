﻿(function ($) {
    function EMPAttendance() {
        var $this = this, grid, form;

        //----------------------------Start Family info----------------------------------------------
        function attendanceAdd(id, employeeId, name, machineId, date, inTime, outTime, workingHours, attendancestatus, oldinTime, oldoutTime, oldworkingHours, oldattendancestatus, isManual, message, empNo) {
            this.id = id;
            this.employeeId = employeeId;
            this.name = name;
            this.machineId = machineId;
            this.date = date;
            this.inTime = inTime;
            this.outTime = outTime;
            this.workingHours = workingHours;
            this.attendancestatus = attendancestatus;
            this.oldinTime = oldinTime;
            this.oldoutTime = oldoutTime;
            this.oldworkingHours = oldworkingHours;
            this.oldattendancestatus = oldattendancestatus;
            this.isManual = isManual;
            this.message = message;
            this.empNo = empNo;
            this.attendanceTypeList = attendanceTypeListArr;
        }


        var attendanceViewModel = {
            attendanceAssignItems: ko.observableArray([])
        };



        function initializeModalWithForm() {

            form = new Global.FormHelperWithFiles($("#frm-attendance-form"), { updateTargetId: "validation-summary" });
            ko.applyBindings(attendanceViewModel, $('#ko-attendance-table')[0]);
            if (attendanceListArr != null && attendanceListArr.length > 0) {
                var mappedData = ko.utils.arrayMap(attendanceListArr, function (item) {
                    return new attendanceAdd(item.Id, item.EmployeeId, item.Name, item.MachineId, moment(item.Date).format("DD/MM/YYYY"), item.InTime != null ? moment(item.InTime, "HH:mm:ss").format("HH:mm") : '', item.OutTime != null ? moment(item.OutTime, "HH:mm:ss").format("HH:mm") : '', item.WorkingHours, item.Attendancestatus, item.InTime, item.OutTime, item.WorkingHours, item.Attendancestatus, item.IsManual, item.Message, item.EmpNo);
                });
                attendanceViewModel.attendanceAssignItems(mappedData);
            } else {
                attendanceViewModel.attendanceAssignItems([]);
            }

            DatePicker();

            $("#selectAll").click(function () {
                $(".check_select").prop('checked', $(this).prop('checked'));
            });

            $("#applystatus").on('click', function () {
                var val = $("#AttendanceType").val();
                $('.attendancestatusselect').val(val);
            });

            $("#getdata").on('click', function () {
                Global.ShowLoading();
                var employeeId = $("#employeeId").val();
                var departmentId = $("#departmentId").val();
                var designationId = $("#designationId").val();
                var attanceDate = $("#attanceDate").val();
                if (attanceDate == '') {
                    attanceDate = moment(new Date()).format("DD/MM/YYYY");
                    $("#attanceDate").val(attanceDate);
                }

                $.ajax('/hrempattendance/getdata?attanceDate=' + attanceDate + '&employeeId=' + employeeId + '&departmentId=' + departmentId + '&designationId=' + designationId, {
                    type: "GET",
                    contentType: false,
                    processData: false,
                    success: function (result) {
                        attendanceViewModel.attendanceAssignItems([]);
                        if (result != null && result.length > 0) {
                            var mappedData = ko.utils.arrayMap(result, function (item) {
                                return new attendanceAdd(item.id, item.employeeId, item.name, item.machineId, moment(item.date).format("DD/MM/YYYY"), item.inTime != null ? moment(item.inTime, "HH:mm:ss").format("HH:mm") : '', item.outTime != null ? moment(item.outTime, "HH:mm:ss").format("HH:mm") : '', item.workingHours, item.attendancestatus, item.inTime, item.outTime, item.workingHours, item.attendancestatus, item.isManual, item.message, item.empNo);
                            });
                            attendanceViewModel.attendanceAssignItems(mappedData);
                        }
                        DatePicker();
                        Global.HideLoading();
                    },
                    error: function (jqXHR, status, error) {

                        Global.HideLoading();

                    },
                    complete: function (result) {

                    }
                });
            });

            $("#refreshdata").on('click', function () {
                Global.ShowLoading();
                var employeeId = $("#employeeId").val();
                var departmentId = $("#departmentId").val();
                var designationId = $("#designationId").val();
                var attanceDate = $("#attanceDate").val();
                if (attanceDate == '') {
                    attanceDate = moment(new Date()).format("DD/MM/YYYY");
                    $("#attanceDate").val(attanceDate);
                }

                $.ajax('/hrempattendance/refreshmachinedata?attanceDate=' + attanceDate + '&employeeId=' + employeeId + '&departmentId=' + departmentId + '&designationId=' + designationId, {
                    type: "GET",
                    contentType: false,
                    processData: false,
                    success: function (result) {
                        attendanceViewModel.attendanceAssignItems([]);
                        if (result != null && result.length > 0) {
                            var mappedData = ko.utils.arrayMap(result, function (item) {
                                return new attendanceAdd(item.id, item.employeeId, item.name, item.machineId, moment(item.date).format("DD/MM/YYYY"), item.inTime != null ? moment(item.inTime, "HH:mm:ss").format("HH:mm") : '', item.outTime != null ? moment(item.outTime, "HH:mm:ss").format("HH:mm") : '', item.workingHours, item.attendancestatus, item.inTime, item.outTime, item.workingHours, item.attendancestatus, item.isManual, item.message, item.empNo);
                            });
                            attendanceViewModel.attendanceAssignItems(mappedData);
                        }
                        DatePicker();
                        Global.HideLoading();
                    },
                    error: function (jqXHR, status, error) {

                        Global.HideLoading();

                    },
                    complete: function (result) {

                    }
                });

            });

            $("#deleteattendance").on('click', function () {
                Global.ShowLoading();
                var favorite = [];
                $(".check_select:checked").each(function () {
                    if (parseInt($(this).val()) > 0) {
                        favorite.push($(this).val());
                    }
                });
                if (favorite.length == 0) {
                    Global.HideLoading();
                    return;
                }
                var ids = favorite.join(",");


                var employeeId = $("#employeeId").val();
                var departmentId = $("#departmentId").val();
                var designationId = $("#designationId").val();
                var attanceDate = $("#attanceDate").val();
                if (attanceDate == '') {
                    attanceDate = moment(new Date()).format("DD/MM/YYYY");
                    $("#attanceDate").val(attanceDate);
                }

                $.ajax('/hrempattendance/deletedata?ids=' + ids + '&attanceDate=' + attanceDate + '&employeeId=' + employeeId + '&departmentId=' + departmentId + '&designationId=' + designationId, {
                    type: "GET",
                    contentType: false,
                    processData: false,
                    success: function (result) {
                        attendanceViewModel.attendanceAssignItems([]);
                        if (result != null && result.length > 0) {
                            var mappedData = ko.utils.arrayMap(result, function (item) {
                                return new attendanceAdd(item.id, item.employeeId, item.name, item.machineId, moment(item.date).format("DD/MM/YYYY"), item.inTime != null ? moment(item.inTime, "HH:mm:ss").format("HH:mm") : '', item.outTime != null ? moment(item.outTime, "HH:mm:ss").format("HH:mm") : '', item.workingHours, item.attendancestatus, item.inTime, item.outTime, item.workingHours, item.attendancestatus, item.isManual, item.message, item.empNo);
                            });
                            attendanceViewModel.attendanceAssignItems(mappedData);
                        }
                        DatePicker();
                        Global.HideLoading();
                    },
                    error: function (jqXHR, status, error) {

                        Global.HideLoading();

                    },
                    complete: function (result) {
                        Global.HideLoading();
                    }
                });
            });

            $(".inTime").on('change', function () {
                var $tr = $(this).closest('tr');
                var inTime = $(this).val();
                var outTime = $tr.find('.outTime').val();
                if (inTime != '' && outTime != '') {
                    $tr.find('.workingHours').html(((new Date("1970-1-1 " + outTime) - new Date("1970-1-1 " + inTime)) / 1000 / 60 / 60).toFixed(2));
                }
            });


            $(".outTime").on('change', function () {               
                var $tr = $(this).closest('tr');
                var outTime = $(this).val();
                var inTime = $tr.find('.inTime').val();
                if (inTime != '' && outTime != '') {
                    $tr.find('.workingHours').html(((new Date("1970-1-1 " + outTime) - new Date("1970-1-1 " + inTime)) / 1000 / 60 / 60).toFixed(2));
                }
            });
        }

        function DatePicker() {
            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $(".timepicker").inputmask("99:99", { clearIncomplete: false });
            $(".timepicker").blur(function () {
                var currentMask = '';
                var arr = $(this).val().split('');
                if (arr[1] == '_' && arr[0] != '_') {
                    arr[1] = arr[0];
                    arr[0] = '0';
                }

                if (arr[4] == '_' && arr[3] != '_') {
                    arr[4] = arr[3];
                    arr[3] = '0';
                }

                $(arr).each(function (index, value) {
                    if (value == '_')
                        arr[index] = '0';
                    currentMask += arr[index];
                });
                var time = currentMask.split(':');
                if (time[0] == "" || time[0] == 'undefined' || time[0] == '__' || parseInt(time[0]) > 23)
                    time[0] = '';
                if (time[1] == "" || time[1] == 'undefined' || time[1] == '__' || parseInt(time[1]) > 59)
                    time[1] = '';
                var newVal = time[0] + ":" + time[1];
                if (newVal.indexOf("undefined") != -1) {
                    newVal = "";
                }
                $(this).val(newVal);
            });

        }

        $this.init = function () {
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new EMPAttendance();
        self.init();
    });
}(jQuery));