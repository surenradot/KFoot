﻿(function ($) {
    function LeaveTypeAddEdit() {
        var $this = this, form;


        function initilizeModel() {

            form = new Global.FormHelper($("#hrleavetypeform"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });


           

            $('input[type="checkbox"].minimal').iCheck({
                checkboxClass: 'icheckbox_minimal-blue'
            });

            $('.colorpicker').colorpicker();

            $('.colorpicker').on('change', function () {
                $(this).css({ 'background': $(this).val() });
            });

            $(".btncancle").hide();
            $(".btncancle").on('click', function () {
                $(".btncancle").hide();
                $(".btnupdate").hide();
                $("#formview").show();
                $("#formAddEdit").hide();
                $(".btnEdit").show();
                $(".step1").show();
                $(".btn-circle").removeClass("btn-success");
                $(".brnstep1").addClass("btn-success");
            });

            $(".btnEdit").on('click', function () {
                $(".btnEdit").hide();
                $(".btnupdate").show();
                $("#formview").hide();
                $("#formAddEdit").show();
                $(".btncancle").show();
                $(".step1").show();
                $(".btn-circle").removeClass("btn-success");
                $(".brnstep1").addClass("btn-success");
            });

            $("#modal-delete-leavetype").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new LeaveTypeAddEdit();
        self.init();
    })
})(jQuery)