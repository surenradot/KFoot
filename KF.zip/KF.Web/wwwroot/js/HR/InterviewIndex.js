﻿(function ($) {
    function InterviewIndex() {
        var $this = this, grid, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "Name", "orderable": true, "searchable": true },
                    { "title": "Designation", "data": "Designation", "orderable": false, "searchable": false },
                    { "title": "Department", "data": "Department", "orderable": false, "searchable": false },
                    { "title": "InterviewNo", "data": "InterviewNo", "orderable": true, "searchable": true },
                    { "title": "Dob", "data": "Dob", "orderable": true, "searchable": true },
                    { "title": "Email", "data": "Email", "orderable": true, "searchable": true },
                    { "title": "MobileNo", "data": "MobileNo", "orderable": true, "searchable": true },                    
                    { "title": "Status", "data": "Status", "orderable": false, "searchable": false },
                    { "title": "feedback", "data": "feedback", "orderable": false, "searchable": false },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            if (record.isEdit) {
                                btns += "<a href='/interview/create/" + record.Id + "' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i> Edit</a>";
                            }
                            btns += "<a href='/interview/View?id=" + record.Id + "' title='View' class='badge btn-sm bg-default-gradient'><i class='fa fa-eye'></i> View</a>";

                            if (record.isfeedback) {
                                btns += '<a href="/interview/feedback?interviewId=' + record.Id +'" class="btn btn-sm btn-primary mg-l-5" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#modal-add-edit-feedback"><i class="fa fa-plus"></i> Feedback</a>';
                            }
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/interview/create' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");

            $("#modal-add-edit-feedback").on('loaded.bs.modal', function (e) {
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                DatePicker();

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }
        function DatePicker() {
            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

        }

        $this.init = function () {
            initializeGrid();
            
        };
    }
    $(function () {
        var self = new InterviewIndex();
        self.init();
    });
}(jQuery));