﻿(function ($) {
    function DocumentAssign() {
        var $this = this, grid, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Department Name", "data": "Name", "orderable": true, "searchable": true },
                    { "title": "Uploaded Documents", "data": "DocumentNames", "orderable": false, "searchable": false },

                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hremployeedocument/create?employeeId=" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-hremployeedocument-add-edit' title='Assign' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hremployeedocument/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-hremployeedocument-add-edit' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initializeModalWithForm() {
            $("#modal-hremployeedocument-add-edit").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                form = new Global.FormHelperWithFiles($("#frm-hremployeedocument-add-edit form"), { updateTargetId: "validation-summary" });

                $("#DesignationId").change(function () {
                    BindEmpList($(this).val(), $("#departmentId").val());
                });

                $("#departmentId").change(function () {
                    BindEmpList($("#DesignationId").val(), $(this).val());

                });
                $("#employeeId").change(function () {
                    BindAllowedList($(this).val());
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

        }

        function BindEmpList(designationId, departmentId) {
            Global.ShowLoading();
            var $tbl = $("#doclisttbl tbody");
            $tbl.empty();

            var $empList = $("#employeeId");
            $empList.empty();
            $('<option/>', {
                'text': 'Select'
            }).appendTo($empList);
            $.ajax('/HREmployeeDocument/GetemployeeList', {
                type: "POST",
                data: { designationId: designationId, departmentId: departmentId },
                success: function (result) {
                    if (result.length > 0) {
                        for (var i = 0; i < result.length; i++) {
                            var emp = result[i];
                            $('<option/>', {
                                'text': emp.name,
                                'value': emp.id
                            }).appendTo($empList);
                        }
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                    }
                    Global.HideLoading();

                }, complete: function () {
                    Global.HideLoading();

                }
            });

        }

        function BindAllowedList(employeeId) {
            Global.ShowLoading();
            var $tbl = $("#doclisttbl tbody");
            $tbl.empty();
            $.ajax('/hremployeedocument/GetDocList', {
                type: "POST",
                data: { employeeId: employeeId },
                success: function (result) {
                    if (result.length > 0) {
                        for (var i = 0; i < result.length; i++) {
                            var emp = result[i];
                            $('<tr/>', {
                                html: function () {
                                    $('<td/>', {
                                        html: function () {
                                            $('<span/>', {
                                                html: i + 1
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<lable/>', {
                                                html: emp.documentName
                                            }).appendTo(this);

                                            $("<input/>", {
                                                'type': 'hidden',
                                                'name': 'Document[' + i + '].DocumentId',
                                                'value': emp.documentId
                                            }).appendTo(this);

                                            $("<input/>", {
                                                'type': 'hidden',
                                                'name': 'Document[' + i + '].Id',
                                                'value': emp.id
                                            }).appendTo(this);

                                            $("<input/>", {
                                                'type': 'hidden',
                                                'name': 'Document[' + i + '].EmployeeId',
                                                'value': emp.employeeId
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {

                                            $("<input/>", {
                                                'type': 'hidden',
                                                'name': 'Document[' + i + '].fileName',
                                                'value': emp.fileName
                                            }).appendTo(this);

                                            $("<input/>", {
                                                'type': 'file',
                                                'name': 'Document[' + i + '].formFile',
                                                'id': 'Document_' + i + '_formFile'
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);
                                    $('<td/>', {
                                        html: function () {
                                            if (emp.fileName != "" && emp.fileName != null) {
                                                $('<a/>', {
                                                    'href': '/HREmployeeDocument/download?key=' + emp.fileName,
                                                    'title': 'Download',
                                                    'class': 'badge btn-sm bg-yellow-gradient',
                                                    'html': 'Download'
                                                }).appendTo(this);

                                            }

                                        }
                                    }).appendTo(this);
                                }
                            }).appendTo($tbl);
                        }
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                    }
                    Global.HideLoading();

                }, complete: function () {
                    Global.HideLoading();

                }
            });

        }

        $this.init = function () {
            initializeGrid();
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new DocumentAssign();
        self.init();
    });
}(jQuery));