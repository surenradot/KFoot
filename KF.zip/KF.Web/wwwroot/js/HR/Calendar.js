﻿(function ($) {
    function HRCalendarIndex() {
        var $this = this, form;

        //----------------------------Start Holiday----------------------------------------------
        function holidayAssigns(id, calendarId, holidayId, fromDate, todate) {
            this.id = id;
            this.calendarId = calendarId;
            this.holidayId = holidayId;
            this.fromDate = fromDate;
            this.todate = todate;
            this.holidayList = holidayListArray;
        }


        var holidayAssignViewModel = {
            holidayAssignItems: ko.observableArray([]),
            addItem: function () {
                this.holidayAssignItems.push(new holidayAssigns("", "", "", "", ""));
                DatePicker();
            },
            removeItem: function (item) {
                holidayAssignViewModel.holidayAssignItems.remove(item);

            }
        };

        //----------------------------Start Exception----------------------------------------------
        function exceptionAssigns(id, calendarId, exceptionId, fromDate, todate) {
            this.id = id;
            this.calendarId = calendarId;
            this.exceptionId = exceptionId;
            this.fromDate = fromDate;
            this.todate = todate;
            this.exceptionList = exceptionListArray;
        }


        var exceptionAssignViewModel = {
            exceptionAssignItems: ko.observableArray([]),
            addItem: function () {
                this.exceptionAssignItems.push(new exceptionAssigns("", "", "", "", ""));
                DatePicker();
            },
            removeItem: function (item) {
                exceptionAssignViewModel.exceptionAssignItems.remove(item);

            }
        };




        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "Name", "orderable": true, "searchable": true },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hrcalendar/modify/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-add-edit-hrcalendar' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/hrcalendar/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-hrcalendar' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrcalendar/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-hrcalendar' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initilizeModel() {

            $("#modal-add-edit-hrcalendar").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                        
                
                ko.applyBindings(holidayAssignViewModel, $('#ko-holiday-assign')[0]);
                
                if (holidayAssignedList != null && holidayAssignedList.length > 0) {
                    var mappedData = ko.utils.arrayMap(holidayAssignedList, function (item) {
                        return new holidayAssigns(item.Id, item.CalendarId, item.HolidayId, moment(item.FromDate).format("DD/MM/YYYY"), moment(item.Todate).format("DD/MM/YYYY"));
                    });
                    holidayAssignViewModel.holidayAssignItems(mappedData);
                } else {
                    holidayAssignViewModel.holidayAssignItems([]);
                }

                ko.applyBindings(exceptionAssignViewModel, $('#ko-exception-assign')[0]);

                if (exceptionAssignedList != null && exceptionAssignedList.length > 0) {
                     mappedData = ko.utils.arrayMap(exceptionAssignedList, function (item) {
                         return new exceptionAssigns(item.Id, item.CalendarId, item.ExceptionId, moment(item.FromDate).format("DD/MM/YYYY"), moment(item.Todate).format("DD/MM/YYYY"));
                    });
                    exceptionAssignViewModel.exceptionAssignItems(mappedData);
                } else {
                    exceptionAssignViewModel.exceptionAssignItems([]);
                }

                DatePicker();
                


            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-hrcalendar").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }
        function DatePicker() {
            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });     

            $(".fromdatepicker").on('change', function () {
                var $tr = $(this).closest('tr');
                var fromDate = $(this).val();
                var $end = $tr.find('.todatepicker')
                var start = new Date(moment(fromDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
                $end.datepicker('setStartDate', new Date(start));
            });

            $(".todatepicker").on('change', function () {
                var $tr = $(this).closest('tr');
                var fromDate = $(this).val();
                var $end = $tr.find('.fromdatepicker')
                var start = new Date(moment(fromDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
                $end.datepicker('setEndDate', new Date(start));
            });
        }

        $this.init = function () {
            initializeGrid();
            initilizeModel();
        }
    }

    $(function () {
        var self = new HRCalendarIndex();
        self.init();
    })
})(jQuery)