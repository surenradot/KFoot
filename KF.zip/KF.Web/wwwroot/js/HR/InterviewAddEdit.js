﻿(function ($) {
    function InterviewIndex() {
        var $this = this, grid, form;

        //----------------------------Start Family info----------------------------------------------
        function familyinfoadd(id, interviewId, name, relationId, occupation, qualification) {
            this.id = id;
            this.interviewId = interviewId,
                this.name = name;
            this.relationId = relationId;
            this.occupation = occupation;
            this.qualification = qualification;
            this.relationList = relationListArr;
        }


        var familyinfoViewModel = {
            familyinfoAssignItems: ko.observableArray([]),
            addItem: function () {
                this.familyinfoAssignItems.push(new familyinfoadd("", "", "", "", "", ""));
            },
            removeItem: function (item) {
                familyinfoViewModel.familyinfoAssignItems.remove(item);

            }
        };

        //----------------------------End Family info----------------------------------------------


        //----------------------------Start Qualification Details----------------------------------------------
        function qualificationdetailadd(id, interviewId, course, university, year, division, percentage) {
            this.id = id;
            this.interviewId = interviewId;
            this.course = course,
            this.university = university;
            this.year = year;
            this.division = division;
            this.percentage = percentage;
        }


        var qualificationdetailViewModel = {
            qualificationdetailAssignItems: ko.observableArray([]),
            addItem: function () {
                this.qualificationdetailAssignItems.push(new qualificationdetailadd("", "", "", "", "", "",""));
            },
            removeItem: function (item) {
                qualificationdetailViewModel.qualificationdetailAssignItems.remove(item);

            }
        };

        //----------------------------End Qualification Details----------------------------------------------


        //----------------------------Start Qualification Details----------------------------------------------
        function previousCompanyadd(id, interviewId, companyName, contactNo, workProfile, joiningDate, leavingDate, leavingReason, salary) {
            this.id = id;
            this.interviewId = interviewId;
            this.companyName = companyName;
            this.contactNo = contactNo;
            this.workProfile = workProfile;
            this.joiningDate = joiningDate;
            this.leavingDate = leavingDate;
            this.leavingReason = leavingReason;
            this.salary = salary;
        }


        var previousCompanyViewModel = {
            previousCompanyAssignItems: ko.observableArray([]),
            addItem: function () {
                this.previousCompanyAssignItems.push(new previousCompanyadd("", "", "", "", "", "", "", "", ""));
                DatePicker();
            },
            removeItem: function (item) {
                previousCompanyViewModel.previousCompanyAssignItems.remove(item);

            }
            
        };

        //----------------------------End Qualification Details----------------------------------------------


        function initializeModalWithForm() {

            form = new Global.FormHelperWithFiles($("#frm-interview-form"), { updateTargetId: "validation-summary" });
            ko.applyBindings(familyinfoViewModel, $('#ko-interview-familyinfo')[0]);
            if (interviewFamilyInfoList != null && interviewFamilyInfoList.length > 0) {
                var mappedData = ko.utils.arrayMap(interviewFamilyInfoList, function (item) {
                    return new familyinfoadd(item.Id, item.InterviewId, item.Name, item.RelationId, item.Occupation, item.Qualification);
                });
                familyinfoViewModel.familyinfoAssignItems(mappedData);
            } else {
                familyinfoViewModel.familyinfoAssignItems([]);
            }

            ko.applyBindings(qualificationdetailViewModel, $('#ko-interview-qualificationdetails')[0]);
            if (interviewQualificationList != null && interviewQualificationList.length > 0) {
                var mappedData1 = ko.utils.arrayMap(interviewQualificationList, function (item) {
                    return new qualificationdetailadd(item.Id, item.InterviewId, item.Class, item.University, item.Year, item.Division, item.Percentage);
                });
                qualificationdetailViewModel.qualificationdetailAssignItems(mappedData1);
            } else {
                qualificationdetailViewModel.qualificationdetailAssignItems([]);
            }

            ko.applyBindings(previousCompanyViewModel, $('#ko-interview-previouscompanydetail')[0]);
            if (interviewPreviousCompanyList != null && interviewPreviousCompanyList.length > 0) {
                var mappedData2 = ko.utils.arrayMap(interviewPreviousCompanyList, function (item) {
                    return new previousCompanyadd(item.Id, item.InterviewId, item.CompanyName, item.ContactNo, item.WorkProfile, item.JoiningDate, item.LeavingDate, item.LeavingReason, item.Salary);
                });
                previousCompanyViewModel.previousCompanyAssignItems(mappedData2);
            } else {
                previousCompanyViewModel.previousCompanyAssignItems([]);
            }
            DatePicker();

            $("#modal-add-edit-feedback").on('loaded.bs.modal', function (e) {
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                DatePicker();

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        function DatePicker() {
            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

        }

        $this.init = function () {
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new InterviewIndex();
        self.init();
    });
}(jQuery));