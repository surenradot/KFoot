﻿(function ($) {
    function EMPMonthlyAttendance() {
        var $this = this, grid, form;

        //----------------------------Start Family info----------------------------------------------
        function attendanceAdd(id, employeeId, name, empNo, fatherName, month, year, noOfDays, noOfAbsent) {
            this.id = id;
            this.employeeId = employeeId;
            this.name = name;
            this.empNo = empNo;
            this.fatherName = fatherName;
            this.month = month;
            this.year = year;
            this.noOfDays = noOfDays;
            this.noOfAbsent = noOfAbsent;
        }


        var attendanceViewModel = {
            attendanceAssignItems: ko.observableArray([])
        };

        function salaryreportAdd(name, empNo, fatherName, bankNo, designation, office, department, noOfDays, monthlySalary, earnning, deduction, netSalary) {
            this.bankNo = bankNo;
            this.name = name;
            this.empNo = empNo;
            this.fatherName = fatherName;
            this.designation = designation;
            this.office = office;
            this.department = department;
            this.noOfDays = noOfDays;
            this.monthlySalary = monthlySalary;
            this.earnning = earnning;
            this.deduction = deduction;
            this.netSalary = netSalary;
        }


        var salaryreportViewModel = {
            salaryreportItems: ko.observableArray([]),
            salarySlipItems: ko.observableArray([])
        };

        function salarySlipAdd(title, name, empNo, pan, pfno, esino, designation, joinDate, bankAcNo, payDays, reportHeaderContain, amounIncomeHead, amounDeductionHead,
            netPay, totalActual, totalEarning, totalDeducation, netPayword) {
            this.pan = pan;
            this.title = title;
            this.name = name;
            this.empNo = empNo;
            this.pfno = pfno;
            this.esino = esino;
            this.designation = designation;
            this.joinDate = joinDate;
            this.bankAcNo = bankAcNo;
            this.payDays = payDays;
            this.reportHeaderContain = reportHeaderContain;
            this.amounIncomeHead = amounIncomeHead;
            this.amounDeductionHead = amounDeductionHead;
            this.netPay = netPay;
            this.totalActual = totalActual;
            this.totalEarning = totalEarning;
            this.totalDeducation = totalDeducation;
            this.netPayword = netPayword;
        }


        function initializeModalWithForm() {

            form = new Global.FormHelperWithFiles($("#frm-attendance-form"), { updateTargetId: "validation-summary" });
            ko.applyBindings(attendanceViewModel, $('#ko-attendance-table')[0]);
            ko.applyBindings(salaryreportViewModel, $('#ko-attendance-report-table')[0]);

            if (attendanceListArr != null && attendanceListArr.length > 0) {
                var mappedData = ko.utils.arrayMap(attendanceListArr, function (item) {
                    return new attendanceAdd(item.Id, item.EmployeeId, item.Name, item.EmpNo, item.FatherName, item.Month, item.Year, item.NoOfDays, item.NoOfAbsent);
                });
                attendanceViewModel.attendanceAssignItems(mappedData);
            } else {
                attendanceViewModel.attendanceAssignItems([]);
            }


            $("#selectAll").click(function () {
                $(".check_select").prop('checked', $(this).prop('checked'));
            });


            $("#getdata").on('click', function () {

                var month = $("#monthId").val();
                var year = $("#yearId").val();

                if (parseInt(month) > 0 && parseInt(year) > 0) {
                    Global.ShowLoading();
                    $.ajax('/hrempmonthlyattendance/getdata?month=' + month + '&year=' + year, {
                        type: "GET",
                        contentType: false,
                        processData: false,
                        success: function (result) {
                            attendanceViewModel.attendanceAssignItems([]);
                            if (result != null && result.length > 0) {
                                var mappedData = ko.utils.arrayMap(result, function (item) {
                                    return new attendanceAdd(item.id, item.employeeId, item.name, item.empNo, item.fatherName, item.month, item.year, item.noOfDays, item.noOfAbsent);
                                });
                                attendanceViewModel.attendanceAssignItems(mappedData);
                            }
                            Global.HideLoading();
                        },
                        error: function (jqXHR, status, error) {

                            Global.HideLoading();

                        },
                        complete: function (result) {

                        }
                    });
                }

            });


            $("#deleteattendance").on('click', function () {
                Global.ShowLoading();
                var favorite = [];
                $(".check_select:checked").each(function () {
                    if (parseInt($(this).val()) > 0) {
                        favorite.push($(this).val());
                    }
                });
                if (favorite.length == 0) {
                    Global.HideLoading();
                    return;
                }
                var ids = favorite.join(",");


                var month = $("#monthId").val();
                var year = $("#yearId").val();

                if (parseInt(month) > 0 && parseInt(year) > 0) {

                    $.ajax('/hrempmonthlyattendance/deletedata?ids=' + ids + '&month=' + month + '&year=' + year, {
                        type: "GET",
                        contentType: false,
                        processData: false,
                        success: function (result) {
                            attendanceViewModel.attendanceAssignItems([]);
                            if (result != null && result.length > 0) {
                                var mappedData = ko.utils.arrayMap(result, function (item) {
                                    return new attendanceAdd(item.id, item.employeeId, item.name, item.empNo, item.fatherName, item.month, item.year, item.noOfDays, item.noOfAbsent);
                                });
                                attendanceViewModel.attendanceAssignItems(mappedData);
                            }
                            Global.HideLoading();
                        },
                        error: function (jqXHR, status, error) {

                            Global.HideLoading();

                        },
                        complete: function (result) {
                            Global.HideLoading();
                        }
                    });
                }
            });

            $("#estimatedsalaryreport").on('click', function () {
                Global.ShowLoading();
                var favorite = [];
                $(".check_select:checked").each(function () {
                    if (parseInt($(this).val()) > 0) {
                        favorite.push($(this).attr('data-emp'));
                    }
                });
                if (favorite.length == 0) {
                    Global.HideLoading();
                    return;
                }
                var ids = favorite.join(",");


                var month = $("#monthId").val();
                var year = $("#yearId").val();

                if (parseInt(month) > 0 && parseInt(year) > 0) {
                    $("#div_body").hide();
                    $("#div_salary").show();
                    $.ajax('/hrempmonthlyattendance/estimatedsalaryreport?ids=' + ids + '&month=' + month + '&year=' + year, {
                        type: "GET",
                        contentType: false,
                        processData: false,
                        success: function (response) {
                            var result = response.list;
                            $("#div_report_title").html(response.title);
                            
                            salaryreportViewModel.salaryreportItems([]);
                            salaryreportViewModel.salarySlipItems([]);
                            if (result != null && result.length > 0) {
                                var mappedData = ko.utils.arrayMap(result, function (item) {
                                    return new salaryreportAdd(item.name, item.empNo, item.fatherName, item.bankAcNo, item.designation, item.office, item.department, item.noOfDays, item.monthlySalary,
                                        item.earning, item.deduction, item.netSalary);
                                });
                                salaryreportViewModel.salaryreportItems(mappedData);
                            }
                            $("#grandTotal").html(response.grandTotal);
                            Global.HideLoading();
                        },
                        error: function (jqXHR, status, error) {

                            Global.HideLoading();

                        },
                        complete: function (result) {
                            Global.HideLoading();
                        }
                    });
                }
            });

            $("#actualsalaryreport").on('click', function () {
                Global.ShowLoading();
                var favorite = [];
                $(".check_select:checked").each(function () {
                    if (parseInt($(this).val()) > 0) {
                        favorite.push($(this).attr('data-emp'));
                    }
                });
                if (favorite.length == 0) {
                    Global.HideLoading();
                    return;
                }
                var ids = favorite.join(",");


                var month = $("#monthId").val();
                var year = $("#yearId").val();

                if (parseInt(month) > 0 && parseInt(year) > 0) {
                    $("#div_body").hide();
                    $("#div_salary").show();
                    $.ajax('/hrempmonthlyattendance/actualsalaryreport?ids=' + ids + '&month=' + month + '&year=' + year, {
                        type: "GET",
                        contentType: false,
                        processData: false,
                        success: function (response) {                            
                            var result = response.list;
                            $("#div_report_title").html(response.title);
                            
                            salaryreportViewModel.salaryreportItems([]);
                            salaryreportViewModel.salarySlipItems([]);
                            if (result != null && result.length > 0) {
                                var mappedData = ko.utils.arrayMap(result, function (item) {
                                    return new salaryreportAdd(item.name, item.empNo, item.fatherName, item.bankAcNo, item.designation, item.office, item.department, item.noOfDays, item.monthlySalary,
                                        item.earning, item.deduction, item.netSalary);
                                });
                                salaryreportViewModel.salaryreportItems(mappedData);
                            }
                            $("#grandTotal").html(response.grandTotal);
                            Global.HideLoading();
                        },
                        error: function (jqXHR, status, error) {

                            Global.HideLoading();

                        },
                        complete: function (result) {
                            Global.HideLoading();
                        }
                    });
                }
            });

            $("#printsalaryslip").on('click', function () {
                Global.ShowLoading();
                var favorite = [];
                $(".check_select:checked").each(function () {
                    if (parseInt($(this).val()) > 0) {
                        favorite.push($(this).attr('data-emp'));
                    }
                });
                if (favorite.length == 0) {
                    Global.HideLoading();
                    return;
                }
                var ids = favorite.join(",");


                var month = $("#monthId").val();
                var year = $("#yearId").val();

                if (parseInt(month) > 0 && parseInt(year) > 0) {
                    $("#div_body").hide();
                    $("#div_salary").show();
                    $("#div_report_title").html("");
                    $.ajax('/hrempmonthlyattendance/PrintSalarySlip?ids=' + ids + '&month=' + month + '&year=' + year, {
                        type: "GET",
                        contentType: false,
                        processData: false,
                        success: function (result) {
                            salaryreportViewModel.salaryreportItems([]);
                            salaryreportViewModel.salarySlipItems([]);
                            if (result != null && result.length > 0) {
                                var mappedData = ko.utils.arrayMap(result, function (item) {
                                    return new salarySlipAdd(item.title, item.name, item.empNo, item.pan, item.pfNo, item.esiNo, item.designation, item.joinDate,
                                        item.bankAcNo, item.payDays, item.reportHeaderContain, item.amounIncomeHead, item.amounDeductionHead, item.netPay, item.totalActual,
                                        item.totalEarning, item.totalDeducation, item.netPayword);
                                });
                                salaryreportViewModel.salarySlipItems(mappedData);
                            }
                            Global.HideLoading();
                        },
                        error: function (jqXHR, status, error) {

                            Global.HideLoading();

                        },
                        complete: function (result) {
                            Global.HideLoading();
                        }
                    });
                }
            });

            $("#btn_back").on('click', function () {
                $("#div_body").show();
                $("#div_salary").hide();
            });

            $(".print-btn").click(function () {
                var title = $(this).data('title');
                var divId = $(this).data("id");
                Popup(divId, title);
            });

        }


        function Popup(divName, title) {
           // debugger
            var DocumentContainer = document.getElementById(divName);
            var mywindow = window.open('', 'new div', 'height=400,width=600');
            mywindow.document.write('<html><head><title>' + title + '</title>');
            mywindow.document.write('</head><body >');
            mywindow.document.writeln(DocumentContainer.innerHTML);
            mywindow.document.write('</body></html>');
            mywindow.print();
            // mywindow.close();
            return true;
        }

        $this.init = function () {
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new EMPMonthlyAttendance();
        self.init();
    });
}(jQuery));