﻿(function ($) {
    function ShiftPattern() {
        var $this = this, grid, form, formDelete, frmAddLang;


        //----------------------------Start Shift Pattern Dates----------------------------------------------
        function ShiftPatternDates(id, shiftDatestr, shiftId) {
            this.id = id;
            this.date = shiftDatestr;
            this.shiftId = shiftId;
            this.shiftList = shiftListArray;
        }


        var shiftPatternDatesViewModel = {
            ShiftPatternDateItems: ko.observableArray([]),
            WorkingDayChange: function (index, event) {
                var context = event.target;
                var id = "HrshiftPatternDates_" + index + "isWorkingDay";
                var shift = $("#HrshiftPatternDates_" + index + "shiftId");
                var $ComparisionValue = $("#" + id);
                if ($ComparisionValue.prop("checked")) {
                    shift.attr("data-msg-required", "*required");
                    shift.attr("data-rule-required", "true");
                } else {
                    shift.removeAttr("data-msg-required");
                    shift.removeAttr("data-rule-required");
                    shift.removeClass("error");
                    shift.addClass("valid");
                }
            }
        };

        //----------------------------End Shift Pattern Dates----------------------------------------------

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "Name", "orderable": true, "searchable": true },
                    { "title": "Start Date", "data": "StartDate", "orderable": false, "searchable": false },
                    //{ "title": "Shift Name", "data": "shiftName", "orderable": false, "searchable": false },
                    { "title": "End Date", "data": "EndTime", "orderable": false, "searchable": false },

                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hrshiftpattern/modify/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-shiftpattern-add-edit' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";                            
                            btns += "&nbsp;&nbsp;<a href='/hrshiftpattern/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-shiftpattern-delete' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            btns += "&nbsp;&nbsp;<a href='/hrshiftpattern/Assignment/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-shiftpattern-assignment' title= 'Shift Pattern Assign To EMP ' class='badge btn-sm bg-success'>Assign To EMP</a >";
                            
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrshiftpattern/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-shiftpattern-add-edit' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initializeModalWithForm() {
            $("#modal-shiftpattern-add-edit").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                form = new Global.FormHelper($("#frm-shiftpattern-add-edit form"), { updateTargetId: "validation-summary" });

                $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
                $('.datepicker').datepicker({
                    autoclose: true,
                    format: "dd/mm/yyyy"
                });


                $(".timepicker").inputmask("99:99", { clearIncomplete: false });
                $(".timepicker").blur(function () {
                    var currentMask = '';
                    var arr = $(this).val().split('');
                    if (arr[1] == '_' && arr[0] != '_') {
                        arr[1] = arr[0];
                        arr[0] = '0';
                    }

                    if (arr[4] == '_' && arr[3] != '_') {
                        arr[4] = arr[3];
                        arr[3] = '0';
                    }

                    $(arr).each(function (index, value) {
                        if (value == '_')
                            arr[index] = '0';
                        currentMask += arr[index];
                    });
                    var time = currentMask.split(':');
                    if (time[0] == "" || time[0] == 'undefined' || time[0] == '__' || parseInt(time[0]) > 23)
                        time[0] = '';
                    if (time[1] == "" || time[1] == 'undefined' || time[1] == '__' || parseInt(time[1]) > 59)
                        time[1] = '';
                    var newVal = time[0] + ":" + time[1];
                    if (newVal.indexOf("undefined") != -1) {
                        newVal = "";
                    }
                    $(this).val(newVal);
                });

                //----------------------------Shift Pattern Date----------------------------------------------
                ko.applyBindings(shiftPatternDatesViewModel, $('#ko-Shift-Pattern-Dates')[0]);

                if (ShiftPatternDateList != null && ShiftPatternDateList.length > 0) {
                    var mappedData = ko.utils.arrayMap(ShiftPatternDateList, function (item) {
                        return new ShiftPatternDates(item.Id, item.ShiftDatestr, item.ShiftId);
                    });
                    shiftPatternDatesViewModel.ShiftPatternDateItems(mappedData);
                } else {
                    shiftPatternDatesViewModel.ShiftPatternDateItems([]);
                }
                //----------------------------Shift Pattern Date----------------------------------------------


                $("#StartDate").on("change", function () {
                    if ($(this).val() != "" && parseInt($("#WeeksInCycle").val()) > 0) {
                        var startArr = $(this).val().split("/");
                        var startDate = new Date(startArr[2], parseInt(startArr[1]) - 1, startArr[0]);
                        var endDate = startDate;
                        endDate.setDate(endDate.getDate() + parseInt(7 * parseInt($("#WeeksInCycle").val())));
                        SetShiftPatternDates(new Date(startArr[2], parseInt(startArr[1]) - 1, startArr[0]), endDate, $("#ShiftId").val());
                    }
                });

                $("#WeeksInCycle").on("change", function () {
                    if ($("#StartDate").val() != "" && parseInt($(this).val()) > 0) {
                        var startArr = $("#StartDate").val().split("/");
                        var startDate = new Date(startArr[2], parseInt(startArr[1]) - 1, startArr[0]);
                        var endDate = startDate;
                        endDate.setDate(endDate.getDate() + parseInt(7 * parseInt($(this).val())));
                        SetShiftPatternDates(new Date(startArr[2], parseInt(startArr[1]) - 1, startArr[0]), endDate, $("#ShiftId").val());
                    }
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });


            $("#modal-shiftpattern-delete").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                formDelete = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" });
                //form = new Global.FormHelper($("#frm-staff-delete form"), { updateTargetId: "validation-summary" });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

        }

        function initializeAssignmentModalWithForm() {
           
            $("#modal-shiftpattern-assignment").on('loaded.bs.modal', function (e) {
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                IndividualStaff();


            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });


            $("#modal-shiftpatternassignment-delete").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                formDelete = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" });
                //form = new Global.FormHelper($("#frm-staff-delete form"), { updateTargetId: "validation-summary" });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

        }

        function IndividualStaff() {           
            PatternArry = new Array();
            if (AssignStaffList != null && AssignStaffList.length > 0) {
                for (var i = 0; i < AssignStaffList.length; i++) {
                    PatternArry.push({ Id: AssignStaffList[i].Id, EmployeeId: AssignStaffList[i].EmployeeId, AssignmentFrom: moment(AssignStaffList[i].AssignmentFrom).format("DD/MM/YYYY"), AssignmentTo: AssignStaffList[i].AssignmentTo != null ? moment(AssignStaffList[i].AssignmentTo).format("DD/MM/YYYY") : AssignStaffList[i].AssignmentTo });
                }
            }

            form = new Global.FormHelper($("#frm-shiftpattern-assignment-add-edit form"), { updateTargetId: "validation-summary", validateSettings: { ignore: '.ignore' } }, undefined, function (response) {
                if (response.isSuccess) {
                    if (response.data.isQuickShift) {
                        var $div = $("#ModelQuickShiftAvailability");
                        $div.empty();
                        $('<div/>', {
                            'class': 'validation-summary-errors',
                            'data-valmsg-summary': 'true',
                            html: function () {
                                $('<ul/>', {
                                    html: function () {
                                        for (var i = 0; i < response.data.messages.length; i++) {
                                            $('<li/>', {
                                                html: '- ' + response.data.messages[i]
                                            }).appendTo(this);
                                        }
                                    }
                                }).appendTo(this);
                            }
                        }).appendTo($div);
                        $("#modal-QuickShiftAvailability-warning").modal({
                            backdrop: 'static',
                            keyboard: false
                        }).find("#btn-QuickShiftAvailability-Yes").off('click').on('click', function () {

                            $('<input/>', {
                                'type': 'hiden',
                                'name': 'checkad-hoc',
                                'value': 'true'
                            }).appendTo('#Individualstaff form');
                            $('<input/>', {
                                'type': 'hiden',
                                'name': 'AdhocId',
                                'value': response.data.id
                            }).appendTo('#Individualstaff form');
                            $("#modal-QuickShiftAvailability-warning").modal('hide').data('bs.modal', null);
                            $("#Individualstaff form").submit();
                        });
                    } else
                        if (response.data.isRequestFromCalendar) {
                            tashiftManagerObject.refreshCalendarOutSide(response.data.messages);
                        }
                        else {
                            window.location.href = response.redirectUrl;
                        }

                } else {
                    form.find("#validation-summary").html(response);
                }
            });

            staffIndex = parseInt($("#index").val());

            form.find('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            form.find('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            form.find("#btnAddSelectedStaff").off('click').on('click', function () {
                
                $("#modal-assign-individual-staff-startdate").modal({
                    backdrop: 'static',
                    keyboard: false
                }).find("#btn-assign-individual-staff-startdate-Yes").off('click').on('click', function () {
                    if ($("#individual-staff-startdate-form").valid()) {
                        $('#AvailableStaffList :selected').each(function (i, selected) {
                            var employeeId = $(this).val();
                            var shiftPatternId = form.find("#ShiftPatternId").val();
                            var membershipDate = $("#individual_staff_startDate").val();
                            $('<option/>', {
                                'value': $(selected).val(),
                                'text': $(selected).text() + " (" + membershipDate + ")",
                                'data-name': $(selected).text()
                            }).appendTo($('#AssignStaffList'));
                            $("#AvailableStaffList option:selected").remove();
                            $("#modal-assign-individual-staff-startdate").modal('hide').data('bs.modal', null);
                            PatternArry.push({ Id: 0, EmployeeId: employeeId, AssignmentFrom: membershipDate });
                            $("#individual_staff_startDate").val('');

                        });
                    }
                });
            });

            form.find("#btnRemoveSelectedStaff").off('click').on('click', function () {
                $('#AssignStaffList :selected').each(function (i, selected) {
                    var employeeId = $(selected).val();
                    var staffName = $(selected).data('name'); 
                    var id = $("#id_" + employeeId).val();
                        var startDate = $(selected).data('startdate');
                    var $end = $('#endDate');
                    var start = new Date(moment(startDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
                    $end.datepicker('setStartDate', new Date(start));
                    $end.on('changeDate', function (e) {                        
                            var start = new Date(moment(startDate, "DD/MM/YYYY").format("MM/DD/YYYY"));
                            $end.datepicker('setStartDate', new Date(start));
                        });
                    if (id != undefined && employeeId) {
                        $("#modal-assign-individual-staff-enddate").modal({
                            backdrop: 'static',
                            keyboard: false
                        }).find("#btn-assign-individual-staff-enddate-Yes").off('click').on('click', function () {
                            if ($("#assign-individual-staff-enddate-form").valid()) {
                                var primaryKey = $(selected).data('id');
                                //var groupDetail = GetStaffList(PatternArry, parseInt(staffId));
                                //if (groupDetail != "") {
                                //    PatternArry.splice($.inArray(groupDetail[0], PatternArry), 1);
                                //}
                                var groupDetail = GetStaffList(PatternArry, employeeId);
                                
                                var groupDetail1 = groupDetail;
                                if (groupDetail != "") {
                                    PatternArry.splice($.inArray(groupDetail[0], PatternArry), 1);
                                    groupDetail1[0].AssignmentTo = $("#endDate").val();
                                    PatternArry.push(groupDetail1[0]);
                                }
                                $(selected).text($(selected).data('name') + "(" + $(selected).data('startdate') + " To " + $("#endDate").val() + ")");
                                $("#AssignmentStaff_AssignmentTo_" + employeeId).val($("#endDate").val());

                              
                                $("#div_" + $(selected).val()).remove();
                               // $("#AssignStaffList option:selected").remove();
                                if (staffIndex == 1) {
                                    staffIndex = 0;
                                }
                                $("#endDate").val('');
                                $("#modal-assign-individual-staff-enddate").modal('hide').data('bs.modal', null);
                            }
                        })

                    } else {
                        $('<option/>', {
                            'value': employeeId,
                            'text': staffName
                        }).appendTo($('#AvailableStaffList'));
                        $("#div_" + $(selected).val()).remove();
                        $("#AssignStaffList option:selected").remove();
                        if (staffIndex == 1) {
                            staffIndex = 0;
                        }

                        $("#modal-assign-individual-staff-enddate").modal('hide').data('bs.modal', null);
                    }

                });
            });

            //$(".btn-assign-individual-staff-confirm-No").click(function () {
            //    $("#modal-assign-individual-staff-confirm").modal('hide').data('bs.modal', null);
            //    $("#modal-assign-individual-staff-startdate").modal('hide').data('bs.modal', null);
            //    $("#startDate").val('');
            //});

            $(".btn-assign-individual-staff-startdate-No").click(function () {
                $("#modal-assign-individual-staff-startdate").modal('hide').data('bs.modal', null);
                $("#startDate").val('');
            });

            //$(".btn-assign-individual-staff-confirm-close").click(function () {
            //    $("#modal-assign-individual-staff-confirm").modal('hide').data('bs.modal', null);
            //});

            $(".btn-assign-individual-staff-enddate-No").click(function () {
                $("#modal-assign-individual-staff-enddate").modal('hide').data('bs.modal', null);
                $("#endDate").val('');
            });

            //$(".btn-assign-individual-staff-warning-close").off('click').on('click', function () {
            //    $("#modal-assign-individual-staff-warning").modal('hide').data('bs.modal', null);
            //    $("#modal-assign-individual-staff-startdate").modal('hide').data('bs.modal', null);
            //    $("#startDate").val('');
            //});

            //$(".btn-assign-individual-staff-enddate-warning-close").off('click').on('click', function () {
            //    $("#endDate").val('');
            //    $("#modal-assign-individual-staff-enddate").modal('hide').data('bs.modal', null);
            //    $("#modal-assign-individual-staff-enddate-warning").modal('hide').data('bs.modal', null);
            //});

            

            form.find("#btn-submit").on('click', function () {
                
                var $element = $('#staffDetails');
                $element.empty();
                if (PatternArry != null && PatternArry.length > 0) {
                    for (var i = 0; i < PatternArry.length; i++) {
                        $("<div/>", {
                            "class": "staff-div",
                            'id': PatternArry[i].EmployeeId,
                            html: function () {
                                $("<input/>", {
                                    'type': 'hidden',
                                    'id': 'index_' + PatternArry[i].EmployeeId,
                                    value: i
                                }).appendTo(this);
                                $("<input/>", {
                                    'type': 'hidden',
                                    'id': 'id_' + PatternArry[i].EmployeeId,
                                    'name': 'AssignmentStaff[' + i + '].Id',
                                    value: PatternArry[i].Id
                                }).appendTo(this);
                                $("<input/>", {
                                    'type': 'hidden',
                                    'name': 'AssignmentStaff[' + i + '].EmployeeId',
                                    value: PatternArry[i].EmployeeId
                                }).appendTo(this);
                                $("<input/>", {
                                    'type': 'hidden',
                                    'name': 'AssignmentStaff[' + i + '].index',
                                    value: i
                                }).appendTo(this);
                                $("<input/>", {
                                    'type': 'hidden',
                                    'id': 'AssignmentStaff_AssignmentFrom_' + PatternArry[i].EmployeeId,
                                    'name': 'AssignmentStaff[' + i + '].AssignmentFrom',
                                    value: PatternArry[i].AssignmentFrom
                                }).appendTo(this);                                
                                $("<input/>", {
                                    'type': 'hidden',
                                    'id': 'AssignmentStaff_AssignmentTo_' + PatternArry[i].EmployeeId,
                                    'name': 'AssignmentStaff[' + i + '].AssignmentTo',
                                    value: PatternArry[i].AssignmentTo
                                }).appendTo(this);
                            }
                        }).appendTo($element);
                    }
                }

                var staffIds = form.find("#AssignStaffList");
                if (staffIds.find('option').length > 0) {
                    staffIds.addClass("ignore");
                   // staffIds.val(staffIds[0].val());
                } else {
                    staffIds.removeClass("ignore");
                }
                form.find("#AssignedFrom").addClass("ignore");
                
                return form.valid();

            });            
        }

        function GetStaffList(groupArr, staffId) {
            if (staffId) {
                var result = $.grep(groupArr, function (e) { return e.EmployeeId == staffId; });
                if (result != null && result.length > 0)
                    return result;
                else
                    return '';
            } else {
                return '';
            }
        }

        function SetShiftPatternDates(startDate, endDate, selectedShiftId) {
            var newDateaArr = new Array();
            while (startDate < endDate) {
                //newDateaArr.push(moment(startDate).format("DD/MM/YYYY"));
                newDateaArr.push(moment(startDate).format("ddd,DD MMM YYYY"));
                var newDate = startDate.setDate(startDate.getDate() + 1);
                startDate = new Date(newDate);
            }


            var mappedData = ko.utils.arrayMap(newDateaArr, function (d) {
                return new ShiftPatternDates(0, d, selectedShiftId);
            });
            shiftPatternDatesViewModel.ShiftPatternDateItems(mappedData);

        }

        $this.init = function () {
            ko.applyBindings(datamodel.ShiftPatternModel);
            initializeGrid();
            initializeModalWithForm();
            initializeAssignmentModalWithForm();
        };
    }
    $(function () {
        var self = new ShiftPattern();
        self.init();
    });
}(jQuery));

var ShiftPatternModel = function () {
    var self = this;
    self.manageShiftPatternList = ko.observableArray([]);
}

var datamodel = {
    ShiftPatternModel: new ShiftPatternModel()
};