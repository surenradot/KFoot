﻿(function ($) {
    function EMPAttendance() {
        var $this = this, grid, form;

        //----------------------------Start Family info----------------------------------------------
        function salarystructureAdd(id, employeeId, fromDate, toDate) {
            this.id = id;
            this.employeeId = employeeId;
            this.fromDate = fromDate;
            this.toDate = toDate;
        }

        function salarystructureDetailAdd(id, salaryStructureId, salaryHeadId, salaryHead, isAmount, isBasic, amount, totalAmount, typeId) {
            this.id = id;
            this.salaryStructureId = salaryStructureId;
            this.salaryHeadId = salaryHeadId;
            this.salaryHead = salaryHead;
            this.amount = amount;
            this.isAmount = isAmount;
            this.isBasic = isBasic;
            this.totalAmount = totalAmount;
            this.typeId = typeId;
        }

        var salarystructureViewModel = {
            salarystructureItems: ko.observableArray([])
        };

        var salarystructuredetailViewModel = {
            incomeItems: ko.observableArray([]),

            deductionItem: ko.observableArray([]),

            updatededuAmount: function (dedu) {
                UpdateDecValues(dedu);
                return true;    // return default browser behavior to allow check/uncheck
            },

            updateIncoAmount: function (dedu) {
                var totalBasicAmount = 0;
                var test = ko.utils.arrayFilter(salarystructuredetailViewModel.incomeItems(), function (prod) {
                    totalBasicAmount += parseFloat(!prod.isAmount ? 0 : prod.totalAmount);
                    return prod;
                });

                ko.utils.arrayForEach(salarystructuredetailViewModel.incomeItems(), function (de) {
                    if (de.salaryHeadId == dedu.salaryHeadId) {
                        var totalAmount = dedu.isAmount ? dedu.amount : (totalBasicAmount * dedu.amount) / 100;
                        de.totalAmount = totalAmount;
                        $('.totalamounttd' + dedu.salaryHeadId).html(totalAmount).toFixed(2);
                        $('.totalamounttdm' + dedu.salaryHeadId).html((totalAmount / 12).toFixed(2));
                        $('.totalamountval' + dedu.salaryHeadId).val(totalAmount.toFixed(2));
                       // if (dedu.isAmount) {
                            UpdatePerValues();
                       // }
                    }
                });
                UpdateTotalValues();
                return true;    // return default browser behavior to allow check/uncheck
            }
        };


        function UpdateDecValues(dedu) {
            var totalBasicAmount = 0;
            var test = ko.utils.arrayFilter(salarystructuredetailViewModel.incomeItems(), function (prod) {

                if (dedu.typeId == 2 && jQuery.inArray(prod.salaryHeadId, PFHeadListArr) >= 0) {
                    totalBasicAmount += parseFloat(prod.totalAmount);
                } else if (dedu.typeId == 3 && jQuery.inArray(prod.salaryHeadId, ESICHeadListArr) >= 0) {
                    totalBasicAmount += parseFloat(prod.totalAmount);
                } else {
                    totalBasicAmount += parseFloat(prod.isAmount ? prod.totalAmount : 0);
                }

                return prod;
            });

            ko.utils.arrayForEach(salarystructuredetailViewModel.deductionItem(), function (de) {
                var totalBasicAmount1 = totalBasicAmount;
                if (de.typeId == 2) {
                    if (totalBasicAmount1 > PFLimit) {
                        totalBasicAmount1 = isMin ? PFLimit : totalBasicAmount1;
                    }
                } else
                    if (de.typeId == 3) {
                        if (totalBasicAmount1 > ESICLimit) {
                            totalBasicAmount1 = ESICLimit;
                        }
                    }
                if (de.salaryHeadId == dedu.salaryHeadId) {
                    var totalAmount = dedu.isAmount ? dedu.amount : (totalBasicAmount1 * dedu.amount) / 100;
                    de.totalAmount = totalAmount;
                    $('.totalamountdetd' + dedu.salaryHeadId).html(totalAmount.toFixed(2));
                    $('.totalamountdetdm' + dedu.salaryHeadId).html((totalAmount/12).toFixed(2));
                    $('.totalamountdeval' + dedu.salaryHeadId).val(totalAmount.toFixed(2));
                }
            });

            UpdateTotalValues();
        }

        function UpdatePerValues() {
            var totalBasicAmount = 0;            
            var test = ko.utils.arrayFilter(salarystructuredetailViewModel.incomeItems(), function (prod) {
                totalBasicAmount += parseFloat(prod.isAmount && prod.isBasic ? prod.totalAmount : 0);                
                return prod;
            });        

            var test1 = ko.utils.arrayFilter(salarystructuredetailViewModel.incomeItems(), function (prod) {

                if (!prod.isAmount) {
                    var totalAmount = (totalBasicAmount * prod.amount) / 100;
                    prod.totalAmount = totalAmount;
                    $('.totalamounttd' + prod.salaryHeadId).html(totalAmount);
                    $('.totalamountval' + prod.salaryHeadId).val(totalAmount);
                }

                return prod;
            });

            var test2 = ko.utils.arrayFilter(salarystructuredetailViewModel.deductionItem(), function (prod) {

                //if (!prod.isAmount) {
                //    var totalAmount = (totalBasicAmount * prod.amount) / 100;
                //    prod.totalAmount = totalAmount;
                //    $('.totalamountdetd' + prod.salaryHeadId).html(totalAmount);
                //    $('.totalamountdeval' + prod.salaryHeadId).val(totalAmount);
                //}
                UpdateDecValues(prod);                
                return prod;
            }); 
            
        }

        function UpdateTotalValues() {            
            var totalInc = 0;
            var totalDec = 0;
            var test = ko.utils.arrayFilter(salarystructuredetailViewModel.incomeItems(), function (prod) {               
                totalInc += prod.totalAmount;
                return prod;
            });

            $('.inctotal').html(totalInc.toFixed(2));           
            $('.inctotalm').html((totalInc/12).toFixed(2));           

            var test3 = ko.utils.arrayFilter(salarystructuredetailViewModel.deductionItem(), function (prod) {

                totalDec += prod.totalAmount;
                return prod;
            });

            $('.decctotal').html(totalDec.toFixed(2));
            $('.decctotalm').html((totalDec/12).toFixed(2));

            var yearly = (totalInc - totalDec);
            $(".yearly").html(yearly.toFixed(2));
            $(".monthly").html((yearly/12).toFixed(2));
        }

        function initializeModalWithForm() {

            ko.applyBindings(salarystructureViewModel, $('#ko-salarystructure-table')[0]);

            $("#modal-add-edit-hrempsalarystructure").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                DatePicker();
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, function (result) {
                    if (result.isSuccess) {
                        showMessage(result.data);
                        $("#modal-add-edit-hrempsalarystructure").modal('hide').data('bs.modal', null);
                        var employeeId = $("#employeeId").val();
                        GetAllRecord(employeeId);
                    } else {
                        $("#validation-summary").html('<span style="color:red;">' + result.data + '</span>');
                    }
                }, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });


            $("#modal-details-hrempsalarystructure").on('loaded.bs.modal', function (e) {

                ko.applyBindings(salarystructuredetailViewModel, $('#ko-salarystructuredetail-table')[0]);
                salarystructuredetailViewModel.incomeItems([]);
                if (incomeListArr != null && incomeListArr.length > 0) {
                    var mappedData = ko.utils.arrayMap(incomeListArr, function (item) {
                        return new salarystructureDetailAdd(item.Id, item.SalaryStructureId, item.SalaryHeadId, item.SalaryHead, item.IsAmount, item.IsBasic, item.Amount, item.TotalAmount, item.TypeId);
                    });
                    salarystructuredetailViewModel.incomeItems(mappedData);
                }


                salarystructuredetailViewModel.deductionItem([]);
                if (deductionListArr != null && deductionListArr.length > 0) {
                    var mappedData1 = ko.utils.arrayMap(deductionListArr, function (item) {
                        return new salarystructureDetailAdd(item.Id, item.SalaryStructureId, item.SalaryHeadId, item.SalaryHead, item.IsAmount, item.IsBasic, item.Amount, item.TotalAmount, item.TypeId);
                    });
                    salarystructuredetailViewModel.deductionItem(mappedData1);
                }

                UpdateTotalValues();
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, function (result) {
                    if (result.isSuccess) {
                        showMessage(result.data);
                        $("#modal-details-hrempsalarystructure").modal('hide').data('bs.modal', null);
                    } else {
                        $("#validation-summary").html('<span style="color:red;">' + result.data + '</span>');
                    }
                }, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-hrempsalarystructure").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, function (result) {
                    if (result.isSuccess) {
                        showMessage(result.data);
                        $("#modal-delete-hrempsalarystructure").modal('hide').data('bs.modal', null);
                        var employeeId = $("#employeeId").val();
                        GetAllRecord(employeeId);
                    } else {
                        $("#validation-summary").html('<span style="color:red;">' + result.data + '</span>');
                    }
                }, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#employeeId").on('change', function () {
                var val = $(this).val();
                if (val != '') {
                    var newUrl = '/hrempsalarystructure/create?employeeId=' + val;
                    $("#addnewrecord").attr('href', newUrl);
                    GetAllRecord(val);
                    $("#addnewrecord").show();
                } else {
                    $("#addnewrecord").hide();
                }
            });

            $("#getdata").on('click', function () {
                var employeeId = $("#employeeId").val();
                GetAllRecord(employeeId);
            });

        }

        function GetAllRecord(employeeId) {
            Global.ShowLoading();

            $.ajax('/hrempsalarystructure/getdata?employeeId=' + employeeId, {
                type: "GET",
                contentType: false,
                processData: false,
                success: function (result) {
                    salarystructureViewModel.salarystructureItems([]);
                    if (result != null && result.length > 0) {
                        var mappedData = ko.utils.arrayMap(result, function (item) {
                            return new salarystructureAdd(item.id, item.employeeId, moment(item.fromDate).format("DD/MM/YYYY"), moment(item.toDate).format("DD/MM/YYYY"));
                        });
                        salarystructureViewModel.salarystructureItems(mappedData);
                    }
                    DatePicker();
                    Global.HideLoading();
                },
                error: function (jqXHR, status, error) {

                    Global.HideLoading();

                },
                complete: function (result) {

                }
            });
        }

        function DatePicker() {
            $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
            $('.datepicker').datepicker({
                autoclose: true,
                format: "dd/mm/yyyy"
            });

            $(".timepicker").inputmask("99:99", { clearIncomplete: false });
            $(".timepicker").blur(function () {
                var currentMask = '';
                var arr = $(this).val().split('');
                if (arr[1] == '_' && arr[0] != '_') {
                    arr[1] = arr[0];
                    arr[0] = '0';
                }

                if (arr[4] == '_' && arr[3] != '_') {
                    arr[4] = arr[3];
                    arr[3] = '0';
                }

                $(arr).each(function (index, value) {
                    if (value == '_')
                        arr[index] = '0';
                    currentMask += arr[index];
                });
                var time = currentMask.split(':');
                if (time[0] == "" || time[0] == 'undefined' || time[0] == '__' || parseInt(time[0]) > 23)
                    time[0] = '';
                if (time[1] == "" || time[1] == 'undefined' || time[1] == '__' || parseInt(time[1]) > 59)
                    time[1] = '';
                var newVal = time[0] + ":" + time[1];
                if (newVal.indexOf("undefined") != -1) {
                    newVal = "";
                }
                $(this).val(newVal);
            });

        }

        function showMessage(message) {
            $("#notificationMessage").html('<div class="alert alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + message + '</div>')
        }

        $this.init = function () {
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new EMPAttendance();
        self.init();
    });
}(jQuery));