﻿(function ($) {
    function InvestmentDeclaration() {
        var $this = this, grid, form, formDelete, frmAddLang;


        //----------------------------Start Shift Pattern Dates----------------------------------------------
        function HousePropertyAdd(id, propertyDetail, financialDetail, annualRent, annualTaxPaid, rebateMaintenance, interest, netIncome, employeeId, isVerify) {
            this.id = id;
            this.propertyDetail = propertyDetail;
            this.financialDetail = financialDetail;
            this.annualRent = annualRent;
            this.annualTaxPaid = annualTaxPaid;
            this.rebateMaintenance = rebateMaintenance;
            this.interest = interest;
            this.netIncome = netIncome;
            this.employeeId = employeeId;
            this.isVerify = isVerify;
        }


        var HousePropertyViewModel = {
            HousePropertyeItems: ko.observableArray([]),
            addItem: function () {
                this.HousePropertyeItems.push(new HousePropertyAdd("", "", "", "", "", "", "", "", "", false));
            },
            removeItem: function (item) {
                HousePropertyViewModel.HousePropertyeItems.remove(item);

            }

        };

        //----------------------------End Shift Pattern Dates----------------------------------------------



        function initializeModalWithForm() {
            form = new Global.FormHelperWithFiles($("#frm-InvestmentDeclaration-add-edit form"), { updateTargetId: "validation-summary" });

            UpdateStatus();

            ko.applyBindings(HousePropertyViewModel, $('#ko-HousePropertyAdd')[0]);

            if (housePropertyList != null && housePropertyList.length > 0) {
                var mappedData = ko.utils.arrayMap(housePropertyList, function (item) {
                    return new HousePropertyAdd(item.Id, item.PropertyDetail, item.FinancialDetail, item.AnnualRent, item.AnnualTaxPaid, item.RebateMaintenance, item.Interest,
                        item.NetIncome, item.EmployeeId, item.IsVerify);
                });
                HousePropertyViewModel.HousePropertyeItems(mappedData);
                UpdateStatus();
            } else {
                //HousePropertyViewModel.HousePropertyeItems([]);

                mappedData = ko.utils.arrayMap([1], function (item) {
                    return new HousePropertyAdd("", "", "", "", "", "", "", "", "", false);
                });
                HousePropertyViewModel.HousePropertyeItems(mappedData);
            }

        }

        function UpdateStatus() {
            $(".verifyrecord").on('click', function () {
                Global.ShowLoading();
                var id = $(this).data('id');
                var typeId = $(this).data('type');
                var empId = $(this).data('employeeid');
                var name = $(this).data('nme');
                var index = $(this).data('index');
                var nameattr = name + '[' + index + '].IsVerify';
                var fileAttr = name + '[' + index + '].file';
                if (parseInt(typeId) == 5) {
                    nameattr = name + '.IsVerify';
                    fileAttr = name + '.file';
                }
                var $verifytd = $(this);
                var $hidVerify = $("input[name='" + nameattr + "']");
                var $hidFile = $("input[name='" + fileAttr + "']");
                $.post('/hrtdsinvestmentdeclaration/verify', { id: id, typeId: typeId, employeeId: empId }, function (response) {
                    if (parseInt(typeId) == 5) {
                        $("#disabilitystatus").html("Verified");
                        $(".removefile").remove();
                    } else {
                        $verifytd.parent().html("Verified");
                    }
                    
                    $hidFile.remove();
                    $hidVerify.val('true');
                    Global.HideLoading();
                });
            });
        }

        $this.init = function () {

            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new InvestmentDeclaration();
        self.init();
    });
}(jQuery));

