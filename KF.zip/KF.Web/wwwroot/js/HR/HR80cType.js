﻿(function ($) {
    function HR80cTypeIndex() {
        var $this = this, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Section", "data": "Section", "orderable": true, "searchable": true },
                    { "title": "Type of Investment", "data": "InvestmentType", "orderable": true, "searchable": true },                    
                    { "title": "Amount Limit (In Rs.)", "data": "Amount", "orderable": false, "searchable": false },
                    {
                        "title": "Proof Required later", "data": "Proof", "orderable": false, "searchable": false, "mRender": function (data, type, record) {
                            var btns = '';
                            if (record.Proof == true) {
                                btns += '<span class="label label-success">Yes</span>';
                            } else {
                                btns += '<span class="label label-warning">No</span>';
                            }
                            return btns;
                        } },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hrtds80ctype/modify/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-add-edit-hrtds80ctype' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/hrtds80ctype/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-hrtds80ctype' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrtds80ctype/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-hrtds80ctype' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initilizeModel() {

            $("#modal-add-edit-hrtds80ctype").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
                $('.datepicker').datepicker({
                    autoclose: true,
                    format: "dd/mm/yyyy"
                });   

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-hrtds80ctype").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }        

        $this.init = function () {
            initializeGrid();
            initilizeModel();
        }
    }

    $(function () {
        var self = new HR80cTypeIndex();
        self.init();
    })
})(jQuery)