﻿(function ($) {
    function RoleGroup() {
        var $this = this, form;

        function initializeGrid() {
            $('#tblrolegroup').DataTable({
                'paging': true,
                'pageLength': 10,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false,
                'processing': true,

                'language':
                {
                    'processing': "<div class=''><i class='fa fa-cog fa-spin site-loader-color'></i></div>",
                    'search': "Search:",
                    'searchPlaceholder': "find your text"
                },
                'dom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                'columnDefs': [                   
                    { "className": "text-center", "targets": [1, 2] },
                    { "searchable": true, "targets": [1, 2] },
                    { "defaultContent": "", "targets": [2] },
                    { "orderable": true, "targets": [0,2] }
                ],
            });            
            $("#buttonContainer").addClass("pull-right").append("<a href='/hruserrolegroup/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-rolegroup' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }


        function initilizeModel() {

            $("#modal-add-edit-rolegroup").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });               

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-delete-rolegroup").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });
            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        $this.init = function () {  
            initializeGrid();
            initilizeModel();
        }
    }

    $(function () {
        var self = new RoleGroup();
        self.init();
    })
})(jQuery)