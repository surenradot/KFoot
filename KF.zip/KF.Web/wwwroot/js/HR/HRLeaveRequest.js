﻿(function ($) {
    function LeaveRequest() {
        var $this = this, grid, form, formDelete, frmAddLang;
        
        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "EpmName", "orderable": true, "searchable": true },
                    { "title": "Leave Type", "data": "LeaveType", "orderable": false, "searchable": true },                    
                    { "title": "Start Date", "data": "StartDate", "orderable": false, "searchable": false },
                    { "title": "End Date", "data": "EndDate", "orderable": false, "searchable": false },
                    { "title": "No Of Days", "data": "NoOfDays", "orderable": false, "searchable": false },
                    { "title": "Allowance Adjusted", "data": "AllowanceAdjustedDays", "orderable": false, "searchable": false },
                    { "title": "Working Days", "data": "WorkingDays", "orderable": false, "searchable": false },
                    {
                        "title": "Leave Status", "data": "LeaveStatus", "orderable": false, "searchable": false,  "mRender": function (data, type, record) {
                            var btns = '';
                            if (record.LeaveStatus == 'Approved') {
                                btns += '<span class="label label-success">' + record.LeaveStatus + '</span>';
                            } else if (record.LeaveStatus == 'Reject'){
                                btns += '<span class="label label-warning">' + record.LeaveStatus + '</span>';
                            } else if (record.LeaveStatus == 'Cancelled') {
                                btns += '<span class="label label-danger">' + record.LeaveStatus + '</span>';
                            } if (record.LeaveStatus == 'Pending') {
                                btns += '<span class="label label-primary">' + record.LeaveStatus + '</span>';
                            }
                            return btns;
                        }
                    },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            if (record.isEditable){
                                btns += "<a href='/hrleaverequest/modify/" + record.Id + "?type=" + (actionName == 'list' ? 'child' : '') +"' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-leaverequest-add-edit' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            }
                            if (record.isCancel) {
                                btns += "&nbsp;&nbsp;<a href='/hrleaverequest/cancel/" + record.Id + "?type=" + (actionName == 'list' ? 'child' : '') +"' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-leaverequest-cancelleave' title= 'Cancel' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            }

                            if (record.isApprove) {
                                btns += "&nbsp;&nbsp;<a href='/hrleaverequest/approve/" + record.Id + "?type=" + (actionName=='list'?'child':'')+"' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-leaverequest-approveleave' title= 'Approve' class='badge btn-sm bg-success'><i class='fa fa-bars' aria-hidden='true'></i></a >";
                            }

                            if (record.isReject) {
                                btns += "&nbsp;&nbsp;<a href='/hrleaverequest/reject/" + record.Id + "?type=" + (actionName == 'list' ? 'child' : '') +"' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-leaverequest-approveleave' title= 'Reject' class='badge btn-sm bg-success'><i class='fa fa-ban' aria-hidden='true'></i></a >";
                            }                          
                            
                            
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrleaverequest/create?type=" + (actionName == 'list' ? 'child' : '') +"' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-leaverequest-add-edit' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initializeModalWithForm() {
            $("#modal-leaverequest-add-edit").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                form = new Global.FormHelper($("#frm-leaverequest-add-edit form"), { updateTargetId: "validation-summary" });

                $('.StartDateLeave').datepicker({
                    keyboardNavigation: false,
                    forceParse: false,
                    toggleActive: false,
                    autoclose: true,
                    format: 'dd/mm/yyyy'
                }).on('show', function (e) {
                    if (form.find(".EndDateLeave").val() != "") {

                        var start = new Date(moment(form.find(".EndDateLeave").val(), "DD/MM/YYYY").format("MM/DD/YYYY"));
                        var endDate = new Date(moment(form.find(".EndDateLeave").val(), "DD/MM/YYYY").add(-parseInt($(".NoOfDaysLeave option:last-child").val()), 'days').format("MM/DD/YYYY"));
                        if (form.find(".StartDateLeave").val() == "") {
                            form.find('.StartDateLeave').datepicker('setDate', new Date(start));
                        }

                    }
                }).inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });

                $('.EndDateLeave').datepicker({
                    keyboardNavigation: false,
                    forceParse: false,
                    toggleActive: false,
                    autoclose: true,
                    format: 'dd/mm/yyyy'
                }).on('show', function (e) {
                    if ($(".StartDateLeave").val() != "") {
                        var start = new Date(moment($(".StartDateLeave").val(), "DD/MM/YYYY").format("MM/DD/YYYY"));
                        var endDate = new Date(moment($(".StartDateLeave").val(), "DD/MM/YYYY").add(parseInt($(".NoOfDaysLeave option:last-child").val()), 'days').format("MM/DD/YYYY"));
                        if (form.find(".EndDateLeave").val() == "") {
                            form.find('.EndDateLeave').datepicker('setDate', new Date(start));
                            //$('.EndDateLeave').datepicker('setStartDate', new Date(start));
                        }
                        //$('.EndDateLeave').datepicker('setEndDate', new Date(endDate));
                    }
                }).inputmask("dd/mm/yyyy", { "placeholder": "dd/mm/yyyy" });

                $('#LeaveTypeId').on("change", function () {

                    if ($(this).val() != "") {
                        var leaveTypeId = $(this).val();
                        var currentval = parseFloat($('#NoOfDays').val()).toFixed(2);
                        currentval = currentval == 'NaN' ? "" : currentval;
                        showLoading();
                        $.ajax({
                            url: "/hrleaverequest/GetNoOfDays?leaveTypeId=" + leaveTypeId,
                            type: 'POST',
                            dataType: 'json',
                            contentType: 'application/json',
                            success: function (data) {
                                $('#NoOfDays').empty();
                                $('#NoOfDays').append('<option value="">Please Select...</option>');
                                $.each(data, function (index, item) {
                                    $('#NoOfDays').append(
                                        '<option value="' + item.id + '">'
                                        + item.name +
                                        '</option>');
                                });
                                $('#NoOfDays').val(currentval);
                                hideLoading();
                            }
                        });
                    }

                });

                $('#btn-submit').off('click').click(function () {
                    if ($("#formLeaveRequestCommon").valid()) {
                        showLoading();
                        $(":disabled", form).removeAttr("disabled");
                    }
                });

                $(document).off("change", ".StartDateLeave").on("change", ".StartDateLeave", function (event) {

                    event.stopImmediatePropagation();
                    var $form = $(this).parents("form:first");

                    if ($form.find(".EndDateLeave").val() != "" || ($form.find("#NoOfDays").val() != "" && $form.find("#NoOfDays").val() != null)) {
                        var isCalcuteDays = true;
                        validateLeaveDetails($form, isCalcuteDays, function (data) {
                            if ($(".EndDateLeave").val() == "") {
                                $form.find(".EndDateLeave").val(data.endDt);
                            }
                            if ($(".EndDateLeave").val() != "" && $(".StartDateLeave").val() != "") {
                                $("#NoOfDays").val(Math.round(data.noOfDays).toFixed(2));
                                $("#WorkingDays").val(Math.round(data.workingDays).toFixed(2));
                            }
                        });
                    }
                });

                $(document).off("change", ".EndDateLeave").on("change", ".EndDateLeave", function (event) {
                    event.stopImmediatePropagation();
                    var $form = $(this).parents("form:first");
                    if ($('#LeaveTypeId').val() == "") {
                        $(this).val("");
                        $("#modal-leavetype-warning").modal({
                            backdrop: 'static',
                            keyboard: false
                        }).find(".btn-leavetype-warning-close").off('click').on('click', function () {
                            $("#modal-leavetype-warning").modal('hide').data('bs.modal', null);
                        });
                        return;
                    }
                    if ($form.find(".StartDateLeave").val() != "" || ($form.find("#NoOfDays").val() != "" && $form.find("#NoOfDays").val() != null)) {
                        var isCalcuteDays = true;
                        validateLeaveDetails($form, isCalcuteDays, function (data) {
                            if ($(".StartDateLeave").val() == "") {
                                $form.find(".StartDateLeave").val(data.endDt);
                            }

                            if ($(".EndDateLeave").val() != "" && $(".StartDateLeave").val() != "") {
                                $("#NoOfDays").val(Math.round(data.noOfDays).toFixed(2));
                                $("#WorkingDays").val(Math.round(data.workingDays).toFixed(2));
                            }
                        });
                    }
                });

                $(document).off("change", "#NoOfDays").on("change", "#NoOfDays:visible", function (event) {
                    var $form = $(this).parents("form:first");
                    var startDate = $form.find("#StartDate:visible").val();
                    startDate = moment(startDate, "DD/MM/YYYY");

                    var endDate = $form.find("#EndDate:visible").val();
                    endDate = moment(endDate, "DD/MM/YYYY");

                    if ((startDate.isValid() || endDate.isValid()) && $(this).val() != "") {
                        var isCalcuteDays = false;
                        validateLeaveDetails($form, isCalcuteDays, function (data) {
                            if (isCalcuteDays) {
                                $("#NoOfDays:visible").val(Math.round(data.allowanceTimeInDays).toFixed(2));
                            }
                            $form.find("#StartDate:visible").val(data.startDt);
                            $form.find("#EndDate:visible").val(data.endDt);
                        });
                    }
                    else { $(this).val(""); }
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });


            $("#modal-leaverequest-approveleave").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($("#frm-approvestaffleave-add form"), { updateTargetId: "validation-summary" });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-leaverequest-cancelleave").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" });


            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });



        }

        $this.init = function () {
            initializeGrid();
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new LeaveRequest();
        self.init();
    });
}(jQuery));


function validateLeaveDetails($form, isCalcuteDays, fnCallback) {


    if ($form.find("#LeaveTypeId").val() == "") {
        $(this).val("");
        $("#modal-leavetype-warning").modal({
            backdrop: 'static',
            keyboard: false
        }).find(".btn-leavetype-warning-close").off('click').on('click', function () {
            $("#modal-leavetype-warning").modal('hide').data('bs.modal', null);
        });
        return;
    }

    showLoading();
    var leaveRequestId = "0";
    if ($form.find('.clsLeaveRequestId').val() != undefined && $form.find('.clsLeaveRequestId').val() != "") {
        leaveRequestId = $form.find('.clsLeaveRequestId').val();
    }
    var noOfDays = Math.abs($form.find('#NoOfDays').val());
    $.ajax({
        url: "/hrleaverequest/ValidateLeaveRequest?id=" + $(".clsLeaveRequestId").val() + "&isCalcuteDays=" + isCalcuteDays + "&leaveType=" + $form.find("#LeaveTypeId").val() + "&startDate=" + $form.find("#StartDate").val() + "&endDate=" +
            $form.find("#EndDate").val() + "&noOfDays=" + noOfDays + "&leaveRequestId=" + leaveRequestId + "&employeeId=" + $('#EmployeeId').val() + "&allowanceTypeId=" + $form.find('#AllowanceTypeId').val() + "&companyId=" + $("#leaveCompanyId").val(),
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        success: function (data) {
            if (data.isSuccess == 0) {

                $form.find('.clsMessage').html('');
                $form.find('.clsMessage').hide();
                //$form.find('.clsCheck').attr('disabled', true);
                $form.find('#btn-submit').show();

                //$form.find('#LeaveTypeId').prop("disabled", true);
                //$form.find('#StartDate').prop("disabled", true);
                //$form.find('#EndDate').prop("disabled", true);
                //$form.find('#NoOfDays').prop("disabled", true);
                $form.find('.clsNotes').show();
                $form.find('#AllowanceAdjustedDays').val(data.allowanceTimeInDays);

                $form.find('.clsInfo').html('Working DAYS : ' + data.workingDays + ' Days, Allowance DAYS : ' + data.allowanceTimeInDays);
                if (typeof (fnCallback) == "function") {
                    fnCallback(data);
                }
            }
            else {
                $form.find('.clsMessageLeave').html(data.message);
                $form.find('.clsMessageLeave').show();
                $form.find('.clsInfo').html('');
                $form.find('#btn-submit').hide();
            }
            hideLoading();
        }
    });
};