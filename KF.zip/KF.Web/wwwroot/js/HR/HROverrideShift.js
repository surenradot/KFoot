﻿(function ($) {
    function OverrideRule() {
        var $this = this, grid, form, formDelete, frmAddLang;

        
     
        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Emp Name", "data": "EpmName", "orderable": true, "searchable": true },
                    { "title": "Shift Name", "data": "ShiftName", "orderable": true, "searchable": true },
                    { "title": "Date", "data": "OverrideDate", "orderable": false, "searchable": false },
                    { "title": "Start Time", "data": "StartTime", "orderable": false, "searchable": false },
                    { "title": "End Time", "data": "EndTime", "orderable": false, "searchable": false },                    
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hroverrideshift/modify/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-add-edit-hroverrideshift' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/hroverrideshift/delete/" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-delete-hroverrideshift' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hroverrideshift/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-hroverrideshift' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initializeModalWithForm() {
            $("#modal-add-edit-hroverrideshift").on('loaded.bs.modal', function (e) {
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($("#frm-overriderule-add-edit form"), { updateTargetId: "validation-summary" });


                $('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
                $('.datepicker').datepicker({
                    autoclose: true,
                    format: "dd/mm/yyyy"
                });       

                $(".timepicker").inputmask("99:99", { clearIncomplete: false });
                $(".timepicker").blur(function () {
                    var currentMask = '';
                    var arr = $(this).val().split('');
                    if (arr[1] == '_' && arr[0] != '_') {
                        arr[1] = arr[0];
                        arr[0] = '0';
                    }

                    if (arr[4] == '_' && arr[3] != '_') {
                        arr[4] = arr[3];
                        arr[3] = '0';
                    }

                    $(arr).each(function (index, value) {
                        if (value == '_')
                            arr[index] = '0';
                        currentMask += arr[index];
                    });
                    var time = currentMask.split(':');
                    if (time[0] == "" || time[0] == 'undefined' || time[0] == '__' || parseInt(time[0]) > 23)
                        time[0] = '';
                    if (time[1] == "" || time[1] == 'undefined' || time[1] == '__' || parseInt(time[1]) > 59)
                        time[1] = '';
                    var newVal = time[0] + ":" + time[1];
                    if (newVal.indexOf("undefined") != -1) {
                        newVal = "";
                    }
                    $(this).val(newVal);
                });
                $('#ColourCode').colorpicker().on('change', function () {
                    $(this).css("background-color", $(this).val());
                });


              


                $("#ShiftId").on('change', function () {
                    if (parseInt($(this).val()) > 0) {
                       
                        $(".shiftnotselected").hide();
                        $(".timepicker").prop("disabled", true);
                        $(".shiftselected").show();
                        $(".shiftSelectedstarttime").removeAttr('disabled');
                        $(".shiftSelectedendTime").removeAttr('disabled');
                        $.get("/hrshift/GetShift?ShiftId=" + $(this).val(), function (result) {
                            $("#lablestarttime").text(result.startTime);
                            $(".OverrideStartTime").val(result.startTime);
                            $(".shiftSelectedstarttime").val(result.startTime);
                            $("#lableendtime").text(result.endTime);
                            $(".OverrideFinishTime").val(result.endTime);
                            $(".shiftSelectedendTime").val(result.endTime);
                            $(".colorcodediv").hide();
                            $("#ColourCode").val(result.colourCode);
                            
                        });
                    } else {
                        $(".shiftnotselected").show();
                        $(".timepicker").removeAttr('disabled');
                        $(".timepicker").val('');
                        $(".shiftselected").hide();
                        $(".shiftSelectedstarttime").prop("disabled", true);
                        $(".shiftSelectedendTime").prop("disabled", true);
                    }

                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

           

           

            $("#modal-delete-hroverrideshift").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                formDelete = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

        }

        $this.init = function () {
            initializeGrid();
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new OverrideRule();
        self.init();
    });
}(jQuery));

