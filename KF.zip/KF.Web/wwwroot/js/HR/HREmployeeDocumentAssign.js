﻿(function ($) {
    function DocumentAssign() {
        var $this = this, grid, form, formDelete, frmAddLang;


        //----------------------------Start Shift Pattern Dates----------------------------------------------
        function documentAssigns(id, departmentId, documentId, isForNew, isForOld, orderNo, remark) {
            this.id = id;
            this.departmentId = departmentId;
            this.documentId = documentId;
            this.isForNew = isForNew;
            this.isForOld = isForOld;
            this.orderNo = orderNo;
            this.remark = remark;
            this.docList = docListArray;
        }


        var documentAssignViewModel = {
            documentAssignItems: ko.observableArray([]),
            addItem: function () {
                this.documentAssignItems.push(new documentAssigns("", $("#department-id").val(), "", false, false, "", ""));
            },
            removeItem: function (item) {
                documentAssignViewModel.documentAssignItems.remove(item);

            }
        };

        //----------------------------End Shift Pattern Dates----------------------------------------------

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Department Name", "data": "Name", "orderable": true, "searchable": true },
                    { "title": "Assign Documents", "data": "DocumentNames", "orderable": false, "searchable": false },

                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/hremployeedocumentassign/create?documentId=" + record.Id + "' data-backdrop='static' data-keyboard='false' data-toggle='modal' data-target='#modal-employeedocumentassign-add-edit' title='Assign' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            return btns;
                        }
                    }],
                order: [[0, "asc"]],
                url: route
            });
            //$("#buttonContainer").addClass("pull-right").append("<a href='/hrshiftpattern/create' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-shiftpattern-add-edit' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Add New</a>");
        }

        function initializeModalWithForm() {
            $("#modal-employeedocumentassign-add-edit").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });
                form = new Global.FormHelper($("#frm-employeedocumentassign-add-edit form"), { updateTargetId: "validation-summary" });
                ko.applyBindings(documentAssignViewModel, $('#ko-doc-assign')[0]);

                if (documentAssignedList != null && documentAssignedList.length > 0) {
                    var mappedData = ko.utils.arrayMap(documentAssignedList, function (item) {
                        return new documentAssigns(item.Id, item.DepartmentId, item.DocumentId, item.IsForNew, item.IsForOld, item.OrderNo, item.Remark);
                    });
                    documentAssignViewModel.documentAssignItems(mappedData);
                } else {
                    documentAssignViewModel.documentAssignItems([]);
                }

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

        }

        $this.init = function () {          
            initializeGrid();
            initializeModalWithForm();
        };
    }
    $(function () {
        var self = new DocumentAssign();
        self.init();
    });
}(jQuery));