﻿(function ($) {
    function AllowanceIndex() {
        var $this = this, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "EpmName", "orderable": true, "searchable": true },
                    { "title": "Designation", "data": "Designation", "orderable": true, "searchable": true },
                    { "title": "Leave type", "data": "LeaveType", "orderable": true, "searchable": true },
                    { "title": "Allowed", "data": "Allowed", "orderable": false, "searchable": false },
                    { "title": "Used", "data": "Used", "orderable": false, "searchable": false },
                    { "title": "Remaining", "data": "Remaining", "orderable": false, "searchable": false }
                ],
                order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrempallowance/viewall' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-view-allowance-individual' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Individual Assign</a> <a href='/hrempallowance/create?type=group' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-allowance' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Group Assign</a>");
        }

        function initializeGrid1() {
            $('#TableId').DataTable({
                'paging': true,
                'pageLength': 10,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false,
                'processing': true,

                'language':
                {
                    'processing': "<div class=''><i class='fa fa-cog fa-spin site-loader-color'></i></div>",
                    'search': "Search:",
                    'searchPlaceholder': "find your text"
                },
                'dom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>"           
            })
            $("#buttonContainer").addClass("pull-right").append("<a href='/hrempallowance'  class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-refresh'></i> Refresh</a> <a href='/hrempallowance/viewall' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-view-allowance-individual' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Individual Assign</a> <a href='/hrempallowance/create?type=group' data-toggle='modal' data-backdrop='static' data-keyboard='false' data-target='#modal-add-edit-allowance' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Group Assign</a>");
        }

        function initilizeModel() {

            $("#modal-add-edit-allowance").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                $("#DesignationId").change(function () {
                    BindEmpList($(this).val(), $("#departmentId").val());
                });

                $("#departmentId").change(function () {
                    BindEmpList($("#DesignationId").val(), $(this).val());

                });

                $("#defaultValue").change(function () {
                    $('.allowed').val($(this).val());
                });

                $("#LeaveTypeId").change(function () {
                    $('.leaveTypeId').val($(this).val());
                });


            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $("#modal-view-allowance-individual").on('loaded.bs.modal', function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                $("#EmployeeId").change(function () {
                    if ($(this).val() != "") {
                        var url = "/HREmpAllowance/create?employeeId=" + $(this).val();
                        $("#add-alloance").attr("href", url);
                        $("#add-alloance").show();
                        BindAllowedList($(this).val());
                    } else {
                        $("#add-alloance").attr("href", "/HREmpAllowance/create?employeeId=");
                        $("#add-alloance").hide();
                    }
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });

            $(document).on('loaded.bs.modal', "#modal-view-allowance-individual-add-edit", function (e) {
                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });


                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, function (response) {
                    if (response.isSuccess) {
                        $("#back-validation-summary").html('<div class="alert alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');
                        $("#modal-view-allowance-individual-add-edit").modal('hide').data('bs.modal', null);
                        BindAllowedList(response.data.empId);
                    } else {

                        form.find("#validation-summary").html('<div class="alert alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');

                    }
                }, function (response) {
                    if (!response.isSuccess) {
                        form.find("#validation-summary").html('<div class="alert alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');
                    }
                });


            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
                $(e.target).removeData("bs.modal").find(".modal-content").empty();
            });

            $(document).on('loaded.bs.modal', "#modal-view-allowance-individual-delete", function (e) {

                $(this).on('keyup keypress', function (e) {
                    var code = e.keyCode || e.which;
                    if (code == 13) {
                        e.preventDefault();
                        return false;
                    }
                });

                form = new Global.FormHelper($(this).find("form"), { updateTargetId: "validation-summary" }, function (response) {
                    if (response.isSuccess) {
                        $("#back-validation-summary").html('<div class="alert alert-success alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');
                        $("#modal-view-allowance-individual-delete").modal('hide').data('bs.modal', null);
                        $("#modal-view-allowance-individual-delete").removeData("bs.modal").find(".modal-content").empty();
                        BindAllowedList(response.data.empId);
                    } else {
                        form.find("#validation-summary").html('<div class="alert alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');
                    }
                }, function (response) {
                    if (!response.isSuccess) {
                        form.find("#validation-summary").html('<div class="alert alert-danger alert-dismissable"><button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + response.data.message + '</div>');
                    }
                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
                $(e.target).removeData("bs.modal").find(".modal-content").empty();
            });

        }



        function BindEmpList(designationId, departmentId) {
            Global.ShowLoading();
            var $tbl = $("#emplist tbody");
            $tbl.empty();
            $.ajax('/HREmpAllowance/GetemployeeList', {
                type: "POST",
                data: { designationId: designationId, departmentId: departmentId },
                success: function (result) {
                    if (result.length > 0) {
                        for (var i = 0; i < result.length; i++) {
                            var emp = result[i];
                            $('<tr/>', {
                                html: function () {
                                    $('<td/>', {
                                        html: function () {
                                            $('<span/>', {
                                                html: i + 1
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<lable/>', {
                                                html: emp.employeeName
                                            }).appendTo(this);
                                            $('<input/>', {
                                                'type': 'hidden',
                                                'name': 'entity[' + i + '].employeeId',
                                                'value': emp.employeeId
                                            }).appendTo(this);
                                            $('<input/>', {
                                                'type': 'hidden',
                                                'name': 'entity[' + i + '].id',
                                                'value': emp.id
                                            }).appendTo(this);
                                            $('<input/>', {
                                                'type': 'hidden',
                                                'class': 'leaveTypeId',
                                                'name': 'entity[' + i + '].leaveTypeId',
                                                'value': ''
                                            }).appendTo(this);
                                        }

                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<input/>', {
                                                'type': 'text',
                                                'class': 'form-control allowed',
                                                'name': 'entity[' + i + '].allowed',
                                                'value': emp.allowed
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);
                                }
                            }).appendTo($tbl);
                        }
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                    }
                    Global.HideLoading();

                }, complete: function () {
                    Global.HideLoading();

                }
            });

        }

        function BindAllowedList(employeeId) {
            Global.ShowLoading();
            var $tbl = $("#allowedlist tbody");
            $tbl.empty();
            $.ajax('/HREmpAllowance/GetAllowedList', {
                type: "POST",
                data: { employeeId: employeeId },
                success: function (result) {
                    if (result.length > 0) {
                        for (var i = 0; i < result.length; i++) {
                            var emp = result[i];
                            $('<tr/>', {
                                html: function () {
                                    $('<td/>', {
                                        html: function () {
                                            $('<span/>', {
                                                html: i + 1
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<lable/>', {
                                                html: emp.leaveTypeName
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<lable/>', {
                                                html: emp.allowed
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);

                                    $('<td/>', {
                                        html: function () {
                                            $('<lable/>', {
                                                html: emp.date
                                            }).appendTo(this);
                                        }
                                    }).appendTo(this);
                                    //<a  class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>
                                    $('<td/>', {
                                        html: function () {
                                            if (emp.used == 0) {
                                                $('<a/>', {
                                                    'href': '/HREmpAllowance/Create/' + emp.id,
                                                    'data-backdrop': 'static',
                                                    'data-keyboard': 'false',
                                                    'data-toggle': 'modal',
                                                    'data-target': '#modal-view-allowance-individual-add-edit',
                                                    'title': 'Edit',
                                                    'class': 'badge btn-sm bg-yellow-gradient',
                                                    'html': '<i class="fa fa-pencil"></i>'
                                                }).appendTo(this);
                                                $('<span/>', {
                                                    'html': '&nbsp;&nbsp;'
                                                }).appendTo(this);
                                                $('<a/>', {
                                                    'href': '/HREmpAllowance/Delete/' + emp.id + '?empId=' + employeeId,
                                                    'data-backdrop': 'static',
                                                    'data-keyboard': 'false',
                                                    'data-toggle': 'modal',
                                                    'data-target': '#modal-view-allowance-individual-delete',
                                                    'title': 'Delete',
                                                    'class': 'badge btn-sm bg-red-gradient',
                                                    'html': '<i class="fa fa-trash-o"></i>'
                                                }).appendTo(this);
                                            } else {
                                                $('<span/>', {
                                                    'html': '&nbsp;&nbsp;'
                                                }).appendTo(this);
                                            }
                                            
                                        }
                                    }).appendTo(this);
                                }
                            }).appendTo($tbl);
                        }
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                    }
                    Global.HideLoading();

                }, complete: function () {
                    Global.HideLoading();

                }
            });

        }

        $this.init = function () {
            //initializeGrid();
            initializeGrid1();
            initilizeModel();
        }
    }

    $(function () {
        var self = new AllowanceIndex();
        self.init();
    })
})(jQuery)