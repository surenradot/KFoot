﻿(function ($) {
    function SchoolPaymentAddEdit() {
        var $this = this, form;

       
        function initilizeModel() {
            form = new Global.FormHelper($("#frm-add-edit-schoolpayment form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                $("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
            });
            
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new SchoolPaymentAddEdit();
        self.init();
    })
})(jQuery)