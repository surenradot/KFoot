﻿var host = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
var multiSelectKey = "multidelete-action";

var dtSearchValue = "";
function selectListItem(text, value, checked) {
    this.Text = text;
    this.Value = value;
    this.Checked = checked != undefined && checked;
}
function ServerParams(ctrlname, value, expression) {
    this.CtrlName = name;
    this.Value = value;
    this.Expression = expression;
}

function BindGrid(oSetting) {
    var _columnDataType = { int: "int", decimal: "decimal", date: "date", bool: "bool", custom: "custom" };
    var _filterBy = { Contains: "contains", Equal: "=", LessThan: "<", LessThanOrEqual: "<=", GreaterThan: ">", GreaterThanOrEqual: ">=", NotEqual: "!=" };
    var _fninitDefaultExpression = function () {
        var _self = this;
        if (_self.Expressions && _self.Expressions.length === 0) {
            for (var index in Object.keys(_filterBy)) {
                var key = Object.keys(_filterBy)[index];
                var value = _filterBy[key];
                _self.Expressions.push({ Name: key, Expression: value });
            }
        }
    };
    var _fnExpression = function (dataType) {
        _fninitDefaultExpression();
        var _self = this;
        var exp = [];
        if (dataType) {
            switch (dataType.toLowerCase()) {
                case _columnDataType.int:
                case _columnDataType.decimal:
                    exp = _self.Expressions.filter(function (item) { return item.Expression !== _filterBy.Contains; });
                    break;
                case _columnDataType.bool:
                    break;

                case _columnDataType.date:
                    break;

                default:
                    exp = _self.Expressions.filter(function (item) { return item.Expression === _filterBy.Contains || item.Expression === _filterBy.Equal; });
                    break;
            }
            return exp;
        }

        return arrExpression;
    };
    var _fnEnableExpression = function (dataType) {
        var is = true;
        if (dataType) {
            switch (dataType.toLowerCase()) {
                case _columnDataType.bool:
                case _columnDataType.date:
                case _columnDataType.custom:
                    is = false;
                    break;
                default:
            }
        }

        return is;
    };

    // Handle click on "Select all" control
    window.selectedCheckBoxes = [];
    window.vendorEmail = [];
    window.showemptyemailmodel = false;
    window._fnSelectAll = function (element) {

        
      
    }
  
    
   

    var _fnGetDropdown = function (items, name) {
        var html = '';
        var option = '<option value="">-Select One-</option>';
        for (var index in items) {
            var text = items[index].Text;
            var value = items[index].Value;
            var checked = items[index].Checked;
            option += '<option value="' + value + '" ' + (checked && checked === true ? "checked='checked'" : "") + '>' + text + ' </options>';
        }
        html += '<select name="' + name + '" data-table="filters"  class="no-right-padd form-control ">';

        html += option;
        html += '</select>';
        var selectedValue = "";;
        if (items && items.length > 0) {
            var selected = items.filter(function (item) {
                return item.Selected === true;
            });
            if (selected.length > 0) {
                selectedValue = selected[0].Value;
            }
        }

        html += '<input type="hidden" name="search.' + name + '" value="' + selectedValue + '"  />';
        return html;
    };

    var _fnGetRadio = function (items, name) {
        var radio = '';
        for (var index in items) {
            var text = items[index].Text;
            var value = items[index].Value;
            var checked = items[index].Checked;
            radio += '<div class="icheck-outer">';
            radio += '<input data-table="filters"  type="radio" ' + (checked ? "data-default='" + value + "'" : "") + '  name="' + name + '" value="' + value + '" ' + (checked && checked == true ? "checked='checked'" : "") + '  />' + text;
            radio += '</div>';
        }
        if (items && items.length > 0) {
            var selected = items.filter(function (item) {
                return item.Checked === true;
            });

            if (selected.length > 0) {
                radio += '<input type="hidden" data-type="radio" name="search.' + name + '" value="' + selected[0].Value + '" />';
            }
        }

        return radio;
    };

    var _fnHtmlCtrl = function (column) {
        var html = '';
        if (column && column.data && column.type) {
            var key = column.data;
            var className = "", colmd = "col-xs-12";
            var isExpression = _fnEnableExpression(column.type);

            html += '<div class="col-md-12 no-left-padd">';
            // drpdown expression
            var condition = _fnExpression(column.type);
            if (condition && condition.length && isExpression) {
                var option = '';
                for (var index in condition) {
                    option += '<option value="' + condition[index].Expression + '">' + condition[index].Name + '</option>';
                }
                html += '<div class="col-md-3 no-left-padd"  style="padding-right: 3px;">';
                html += '<select class="form-control col-md-3" data-table="expression" data-key="' + key + '">';
                html += option;
                html += '</select>';
                html += '</div>';
                colmd = " col-md-9 ";
            }

            switch (column.type.toLowerCase()) {
                case _columnDataType.int:
                    className = 'numericvalues';
                    break;
                case _columnDataType.decimal:
                    className = 'decimalvalues';
                    break;
            }

            html += '<div class="no-left-padd ' + colmd + '">';

            switch (column.type.toLowerCase()) {
                case _columnDataType.date:

                    html += '<div class="col-md-6 no-left-padd">';
                    html += '<div class="input-group date">';
                    html += '    <input type="text" data-table="filters"  class="form-control date-range-filter"   data-filter=">="   name="search.' + key + '" placeholder="From Date" >';
                    html += '    <span class="input-group-addon">';
                    html += '        <span class="fa fa-calendar"></span>';
                    html += '    </span>';
                    html += '</div>';
                    html += '</div>';
                    html += '<div class="input-group date">';
                    html += '    <input type="text" data-table="filters"  class="form-control date-range-filter" data-filter="<=" name="search.' + key + '"  placeholder="To Date">';
                    html += '    <span class="input-group-addon">';
                    html += '        <span class="fa fa-calendar"></span>';
                    html += '    </span>';
                    html += '</div>';
                    html += '</div>';

                    break;
                case _columnDataType.custom:
                    if (column.bind && column.type && column.type == "custom" && column.bind.ctrl && column.bind.data) {
                        if (column.bind.ctrl == "radio") {
                            html += _fnGetRadio(column.bind.data, key);
                        }
                        else if (column.bind.ctrl == "selectlist") {
                            html += _fnGetDropdown(column.bind.data, key);
                        }
                    }

                    break;
                case _columnDataType.bool:
                    // simple bool condition
                    if (!column.bind) {
                        var items = [new selectListItem("Yes", "true"), new selectListItem("No", "false"), new selectListItem("Both", "", true)];
                        html += _fnGetRadio(items, key)
                    } else if (column.bind && column.bind.type && column.bind.data) {
                        html += _fnGetRadio(column.bind.data, key)
                    }

                    break;
                default:
                    html += '<input data-table="filters" class="no-right-padd form-control ' + className + '" name="search.' + key + '" type="text" value="" id="search_' + key + '">';
                    break;
            }
            html += '</div>';
            html += '</div>';
        }
        return html;
    };

    var _funResetCtrl = function () {
        $(this.selector.filter).filter(":text").val('');
        $(this.selector.filter).filter("select").each(function () {
            $(this).find("option:first").prop("selected", true);
            $(this).change();
        });
        $(this.selector.filter).filter(":radio[data-default]").each(function () {
            var name = $(this).attr("name");
            var value = $(this).data("default") || "";
            var $radio = $(':radio[name="' + name + '"][data-default="' + value + '"]');
            if ($radio.length > 0) {
                $radio.iCheck("check", true);
                $('[name="search.' + name + '"]').val(value);
            }
        });
    };

    var _fnRandomString = function (length) {
        var chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var result = '';
        for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
        return result;
    }

    var _fnModal = function (isShow) {
        var visible = isShow || 'hide';
        $(this.selector.dvfilterBox).modal(visible);
    };

    var _fnUpdateTitles = function (_self) {
        var oColumns = _self.oSetting.columns;
        var sColumns = _self.DataTable.api().ajax.params().columns;
        for (var index in sColumns) {
            var data = sColumns[index].data;

            var column = oColumns.filter(function (item) {
                return item.data === data;
            });
            if (column && column.length > 0) {
                sColumns[index].name = column[0].sTitle;
            }
        }
    }

    this.Table = [];

    this.Filters = [];

    this.Expressions = [];

    this.oSetting = $.extend(oSetting, {
        export: "",
        pageSize: oSetting.pageSize == undefined ? [10, 25, 50, 100, 500] : oSetting.pageSize,
        filterByCtrls: true,
        ajaxUrl: host + "/gridtable/getdatatablegrid",
        fnCallBack: oSetting.fnCallBack || null,
        dataKeys: oSetting.dataKeys || []
    });

    this.on = { search: '[data-table="search"]', expression: '[data-table="expression"]', reset: '[data-table="reset"]', togglefilter: '[data-table="togglefilter"]', export: { excel: "#excellExport", pdf: '[data-table="export-pdf"]' } };
    this.selector = { dvfilterBox: '[data-table="dvfilterBox"]', dvfilterBody: '[data-table="dvfilterBody"]', table: '[data-table="grid"]', filter: '[data-table="filters"]' };
    this.searchGrid = function (keyword) {
        var $list = $(this.selector.table + ' tbody').find('tr');
        $list.sort(function (a, b) {
            if (keyword == "")
                return $(a).data('index') > $(b).data('index');
            else
                return $(a).text().indexOf(keyword) < $(b).text().indexOf(keyword);
        });
        $list.detach().appendTo($(this.selector.table + ' tbody'));
        $list.each(function () {
            if ($(this).text().indexOf(keyword) != -1 && keyword != "")
                $(this).removeClass('not-found').addClass('found');
            else
                $(this).removeClass('found').addClass('not-found');
        });
        $(this.selector.table + ' tbody tr:odd').removeClass('even').addClass('odd');
        $(this.selector.table + ' tbody tr:even').removeClass('odd').addClass('even');
    };

    this.fnServerParams = function (aoData) {
        var _self = this;

        _self.Filters = [];

        var x = aoData;
        for (var i in aoData.columns) {
            if (aoData.columns[i])
                aoData.columns[i].visible = this.oSetting.columns[i].hasOwnProperty("visible") ? this.oSetting.columns[i].visible : true;
                aoData.columns[i].title = this.oSetting.columns[i].hasOwnProperty("title") && this.oSetting.columns[i].title != null && this.oSetting.columns[i].title.length > 0 ?
                this.oSetting.columns[i].title : this.oSetting.columns[i].data;
                if (aoData.columns[i].searchable) {
                    aoData.columns[i].name ='@#$contains'
                    aoData.columns[i].search.value = aoData.search.value
                }
           
            var ctrlName = '[name="' + aoData.columns[i].data + '"]';
            if ($(ctrlName).length > 0) {
                var search_value = "";
                var search_filter_name = "";
                $(ctrlName).each(function () {
                    var value = $(this).val().trim();

                    var required = $(this).data('required') != undefined;
                    if (value != '') {
                        if ($(this).hasClass("date-range-filter")) {
                            value = value.split('/')[1] + '/' + value.split('/')[0] + '/' + value.split('/')[2];
                        }
                        search_value += "@#$" + value;
                        search_filter_name += "@#$" + ($(this).data('filter') == undefined ? "=" : $(this).data('filter'));
                    } else if (required) {
                        search_value += "@#$" + _self._fnRandomString(10);
                        search_filter_name += "@#$" + ($(this).data('filter') == undefined ? "=" : $(this).data('filter'));
                    }

                    var $element = $("[name='search." + aoData.columns[i].data + "']:hidden");
                    var hiddenType = $element.data("type");

                    var isfxSearch = $element.length > 0 && hiddenType != undefined && hiddenType != "radio";
                    if (value != '' && !isfxSearch) {
                        _self.Filters.push(new ServerParams(aoData.columns[i].data, value, ($(this).data('filter') == undefined ? "=" : $(this).data('filter'))));
                    }
                });
                aoData.columns[i].search.value = search_value;
                aoData.columns[i].name = search_filter_name;
                aoData.columns[i].orderable = false;
            }
        }
       // aoData.search.value = dtSearchValue;

        if (_self.oSetting.dataKeys instanceof Array && _self.oSetting.dataKeys.length > 0) {
            for (var j = 0; j < _self.oSetting.dataKeys.length; j++) {
                $(document).removeData(_self.oSetting.dataKeys[j]);
            }
        }
    };

    this.Bind = (function () {
        var htmlLoading = "<div class=''><i class='fa fa-cog fa-spin site-loader-color'></i></div>";
        var _self = this;

        

        // DataTable pagging info
        $.fn.dataTableExt.oApi.fnPagingInfo = function (oSettings) {
            return {
                "iStart": oSettings._iDisplayStart,
                "iEnd": oSettings.fnDisplayEnd(),
                "iLength": oSettings._iDisplayLength,
                "iTotal": oSettings.fnRecordsTotal(),
                "iFilteredTotal": oSettings.fnRecordsDisplay(),
                "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
            };
        }

        //export grid
        $(document).on("click", _self.on.export.excel, function (e) {
            if ($(document).data("excel-verified") != undefined || isAccountRole == "false") {
                
                $(document).removeData("excel-verified");
                var row = $('#DataTables_Table_0 tbody').find('td');
                if (row.length == 1) {
                    $.notify("There is no data for download", "warn");
                    return false;
                }
                e.preventDefault();
                _fnUpdateTitles(_self);
                var $frm = $("#frmExportExcel");
                var $excelReplaceUrl = $(".replaceurl[data-for='excel']").eq(0);
                if ($excelReplaceUrl.length > 0 && $excelReplaceUrl.data("url")) {
                    $frm.attr("action", $excelReplaceUrl.data("url"));
                }
                _self.fnServerParams(_self.DataTable.api().ajax.params())
                $frm.find(":hidden").val(JSON.stringify(_self.DataTable.api().ajax.params()));
                $frm.submit();
            }
        });

        

        //DataTable Configuratio info
        _self.DataTable = $(_self.selector.table).dataTable({
            "fixedHeader": {
                header: true
            },
            "order": _self.oSetting.order || [],
            "scroll": false,
            "sDom": _self.oSetting.sDom == undefined ? 'Tlfrtip' : _self.oSetting.sDom,
            "stateSave": false,
            "colVis": _self.oSetting.colVis,
            "processing": true,
            "oLoadingSrc": "<img src='/Scripts/Lodingcaptcha.gif' class='vertical-align' />",
            "oRender": _self.oSetting.render || "grid",
            "serverSide": true,
            "oLanguage": { "sProcessing": htmlLoading },
            "bFilter": true,
            "bAutoWidth": false,
            "pagingType": "full_numbers",
            "lengthMenu": _self.oSetting.pageSize,
            "pageLength": _self.oSetting.pageLength == undefined ? _self.oSetting.pageSize[0] : _self.oSetting.pageLength,
            "oActionButtons": '[data-buttons="top"]',
            "ajax": {
                "url": _self.oSetting.ajaxUrl, "type": "POST",
                "data": { 'Route': _self.oSetting.route ? _self.oSetting.route : route,  'ServiceHost': servicehost, 'ControllerName': controllerName, "export": "" },
                error: function (req, xht, response) {
                }
            },
            "columns": _self.oSetting.columns,
            "fnDrawCallback": function (response, json) {
                if (response.nTBody != undefined) {
                    $(response.nTBody).find("tr").each(function (item, index) {
                        var $element = $(this).find("td.column-action").find("[data-row-class]");
                        if ($element.length > 0) {
                            $(this).addClass($element.eq(0).data("row-class"));
                        }
                    })                   
                }
            },
            "initComplete": function (settings, json) {
                $('[data-toggle="tooltip"]').tooltip();
            },
            "fnServerParams": function (aoData) {
                _self.fnServerParams(aoData);
            }
        });
        if ($.isFunction(_self.oSetting.fnCallBack)) {
            _self.DataTable.fnSettings().aoDrawCallback.push({
                "fn": _self.oSetting.fnCallBack, "sName": "fnCallBack"
            });
        }

        // DataTable draw
        _self.DataTable.on('draw.dt', function (response) {
            var $fixedSearch = $('[data-table="fixed-search"]');
            if (dtSearchValue != "") {
                dtSearchValue = "";
            }
            $(_self.on.togglefilter).toggle(_self.oSetting.filterByCtrls);

            $(_self.on.reset).toggle(_self.Filters.length > 0);

            // delete confirmation
           //  deleteConfirmation();
            

            if ($(".resp-tab-content-active .table-responsive").find(".dataTables_empty").length <= 0) {
                $("[data-type-buttons]").each(function () {
                    if ($(this).data("type-buttons").indexOf("'" + $(".resp-tab-active").data("invoice-record") + "'") > -1) {
                        $(this).show();
                    }
                })
            }
                       

            // wrap all buttons
            $(_self.selector.table).find("tbody tr td.column-action").each(function (td, index) {
                var actionButtons = $(this).find(".action-icons");
                if (actionButtons.length > 0) {
                    var isWrap = false;
                    var aliasButtons = $("<div />");
                    var dropDown = "";
                    actionButtons.each(function () {
                        var anchor = $(this).find('a');
                        var title = anchor.data('original-title')
                        var ignore = anchor.data("ignore");
                        if (title != undefined &&
                            (title.toLowerCase() != "edit" && title.toLowerCase() != "delete" && title.toLowerCase() != "cancel" && title.toLowerCase() != "deactivate" && title.toLowerCase() != "share network" && ignore == undefined)) {
                            isWrap = true;
                            var url = anchor.attr("href") == undefined ? "javascript:;" : anchor.attr("href");
                            dropDown += '<li class="">';
                            dropDown += '<span class="action-icons action-icons-2">';
                            dropDown += '<a href="' + url + '"  data-placement="bottom" >' + anchor.data('original-title') + '</a>';
                            dropDown += '</span>';
                            dropDown += '</li>';
                        }
                        else {
                            aliasButtons.append($(this));
                        }
                    });
                    if (isWrap) {
                        $(this).addClass("dropdown");
                        aliasButtons.append($('<ul class="dropdown-menu">' + dropDown + '</ul><button class="form-control btn-form-control btn-form-control-sm dropdown-toggle" data-toggle="dropdown"><i class="fa fa-ellipsis-v all-offset-0"></i></button>'));
                    }

                    $(this).html('')
                    $(this).append(aliasButtons);
                }

                //$(this).html('')
            });

        });

        // record custom search on button search
        $('html').on('click', _self.on.search, function (e) {
            e.preventDefault();
            _fnModal('hide');
            _self.DataTable.fnDraw();
        });
        // hide model
        $('html').on('click', '[data-table="close-filter"]', function (e) {
            e.preventDefault();
            _fnModal('hide');
        });

        // Reset Custom Searching on reset button
        $('html').on('click', _self.on.reset, function (e) {
            e.preventDefault();
            _funResetCtrl();
            _self.DataTable.fnDraw();
        });

        //assign custom expression on search controls
        $(document).on("change", _self.on.expression, function () {
            var key = $(this).data('key');
            if (key) {
                var $ctrl = $('[name="search.' + key + '"]');
                if ($ctrl.length) {
                    $ctrl.data("filter", $(this).val());
                }
            }
        });
        $(_self.on.expression).each(function () {
            $(this).change();
        });

        //Search records in loaded records
        $(document).on('change', ".local-search-grid", function () {
            _self.searchGrid($(this).val());
        });

        //toggle filter
        $(document).on('click', _self.on.togglefilter, function () {
            if ($(_self.selector.dvfilterBox).length == 0) {
                return
            }
            // $(this).toggleClass("btn-default").toggleClass("btn-primary");
            _fnModal('show');
        });

        //assigning radio
        $(document).on('ifChanged', ':radio[data-table="filters"]', function () {
            var name = $(this).attr("name");
            $('[name="search.' + name + '"]').val($(this).val());
            if ($(document).data("report-filter") != undefined) {
                _self.DataTable.fnDraw();
            }
        });
        //assigning dropdown value
        $(document).on('change', '[data-table="filters"]select', function () {
            var name = $(this).attr("name");
            $('[name="search.' + name + '"]').val($(this).val());
        });

        $(document).on("click", '[data-closemodal]', function () {
            var modal = $(this).data('closemodal');
            $(modal).find(".modal-body").html('');
            $(modal).modal('hide');
        });

        // append local search ctrl
        if (_self.oSetting.localSearch) {
            var ca = $('.create-action');
            if (ca.length != 0) {
                ca.prepend('<input type="text" class="local-search-grid form-control" placeholder="search in loaded results" />');
            }
        }
    })();
}

function ReDrawDatatable() {
    var dataTable = $('[data-table="grid"]').dataTable();
    dataTable.fnDraw();
}

function BindGridPartial(ajaxUrl, dtKey, modal, modalTitle) {
    var key = dtKey == undefined ? "xyz" : dtKey;
    if ($(document).data(key) == undefined) {
        $(document).data(key, "value");
        if (modalTitle != undefined) {
            $(modal).find(".box-title").html(modalTitle);
        }

        $(modal).find('.modal-body').html(loadingText);
        $(modal).modal({ keyboard: true }).show();
        $.ajax({
            url: ajaxUrl, success: function (html) {
                if ($(modal).length > 0) {
                    $(modal).find('.modal-body').html(html);
                }
                $(document).removeData(key);
            }
        });
    }
}

function getBoolenListItem() {
    var items = new Array();
    item.push(new selectListItem("Yes", "true"));
    item.push(new selectListItem("No", "true"));
    item.push(new selectListItem("Both", "", true));
    return items;
}

var loadingText = "<div class=''><i class='fa fa-cog fa-spin site-loader-color'></i></div>";