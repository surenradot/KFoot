﻿//$(document).ready(function () {
//    window.datepickerIntialize();
//    setSerialNumber();
//});

//$(function () {
//    $(".rejectconfirmation").click(function (event) {
//        // event.preventDefault();        
//        var $submit = $(this);
//        swal({
//            title: "Are you sure?",
//            type: "warning",
//            showCancelButton: true,
//            confirmButtonColor: "#DD6B55",
//            confirmButtonText: "Yes, reject it!",
//            cancelButtonText: "No, cancel it!",
//            closeOnConfirm: true,
//            closeOnCancel: true
//        },
//            function (isConfirm) {
//                if (isConfirm) {
//                    $submit.parents('form:first').append('<input name="rejectstatus" type="hidden" value="Reject" />');
//                    $submit.attr('type', 'submit');
//                    $submit.click();
//                }
//            });
//    });

//    $("form").bind("submit", function () {
//        var _form = $(this);
//        var id = _form.attr('id');


//        if ($.validator.unobtrusive != undefined) {
//            $.validator.unobtrusive.parse(_form);
//        }
//        var qtyarry = new Array();
//        var itemArry = new Array();
//        if (id != undefined && id == 'conveyNote') {
//            $("#childs tbody tr").each(function () {

//                var item = $(this).find(".itemchange_conveynote");
//                var avqty = item.find(":selected").data("qty");
//                var qty = $(this).find('.quantiy_stockquantity').val();
//                var itemId = item.val();
//                if (itemArry.indexOf(itemId) == -1) {
//                    itemArry.push(itemId);
//                    qtyarry.push({ id: itemId, avqty: avqty, qty: qty });
//                } else {
//                    qtyarry.push({ id: itemId, avqty: avqty, qty: qty });
//                }
//            });
//            for (var i = 0; i < itemArry.length; i++) {

//                var result = $.grep(qtyarry, function (e) { return e.id == itemArry[i]; });
//                var avlQty = result[0].avqty;
//                var totalQty = 0;
//                for (var j = 0; j < result.length; j++) {
//                    totalQty += parseFloat(result[j].qty);
//                }
//                if (parseFloat(avlQty) < totalQty) {
//                    ShowNotification('Please enter valid qty. ', 'error');
//                    return false;
//                }
//            }
//        }

//        if ($(_form).valid() && $(_form).find('.field-validation-error').length == 0) {
//            showLoading();
//        }
//    });

//    $('.qty').each(function () {
//        AllowDecimalPlace($(this));
//    });


//});


//function StoreStockRepairableQtyCheck() {
//    $(document).on('change', ".StoreStockRepairableQty", function () {
//        var $parent = $(this).closest('tr');
//        var ResQty = parseFloat($parent.find(".itemqty").val());
//        var SerQty = $parent.find(".StoreStockServisableQty ").val();
//        var RepQty = $(this).val();

//        if (SerQty == null || SerQty == '') {
//            SerQty = 0;
//        }
//        if (RepQty == null || RepQty == '') {
//            RepQty = 0;
//        }
//        if (ResQty < (parseFloat(SerQty) + parseFloat(RepQty))) {
//            var $span = $(this).parent().find('span');
//            $span.addClass('field-validation-error');
//            $span.html('<span id="HeldByOrgnaizationId-error" class="">Qty should be less then Part Res Qty.</span>')
//            $(this).val(0);
//        }
//        else {
//            var $span = $(this).parent().find('span');
//            $span.removeClass('field-validation-error');
//            $span.html('')
//        }
//    })
//}

//function StoreStockServisableQtyCheck() {
//    $(document).on('change', ".StoreStockServisableQty", function () {
//        var $parent = $(this).closest('tr');
//        var ResQty = parseFloat($parent.find(".itemqty").val());
//        var SerQty = $(this).val();
//        var RepQty = $parent.find(".StoreStockRepairableQty ").val();

//        if (SerQty == null || SerQty == '') {
//            SerQty = 0;
//        }
//        if (RepQty == null || RepQty == '') {
//            RepQty = 0;
//        }

//        if (ResQty < (parseFloat(SerQty) + parseFloat(RepQty))) {
//            var $span = $(this).parent().find('span');
//            $span.addClass('field-validation-error');
//            $span.html('<span id="HeldByOrgnaizationId-error" class="">Qty should be less then Part Res Qty.</span>')
//            $(this).val(0);
//        } else {
//            var $span = $(this).parent().find('span');
//            $span.removeClass('field-validation-error');
//            $span.html('')
//        }

//    })
//}

//function AvlbCertRequestChange(basiccatid, catid) {
//    //debugger
//    var url = "/AvailabilityCertRequest/AvlbFilterItemList";

//    var $parent = $("#GroupItemId").parents().eq(3);
//    $("#itemUom").val('');
//    $parent.find('.groupitem').empty();
//    $parent.find('.groupitem').append('<option value=""></option>');

//    var $parent = $("#ItemId").parents().eq(4);
//    $("#pitemUom").val('');
//    $parent.find('.itemparts').empty();
//    $parent.find('.itemparts').append('<option value=""></option>');

//    $.ajax({
//        type: "POST", url: url, data: { basiccategoryid: basiccatid, categoryid: catid }, success: function (response) {
//            var item = response.groupitem;
//            var parts = response.item;

//            if (item != null && item != undefined) {
//                if (item != null && item.length > 0) {
//                    for (var i = 0; i < item.length; i++) {
//                        $parent.find('.groupitem').append('<option value="' + item[i].id + '">' + item[i].name + '</option>');
//                    }
//                }
//            }

//            if (parts != null && parts != undefined) {
//                if (parts != null && parts.length > 0) {
//                    for (var i = 0; i < parts.length; i++) {
//                        $parent.find('.itemparts').append('<option value="' + parts[i].id + '">' + parts[i].name + '</option>');
//                    }
//                }
//            }
//        }
//    });
//}


//window.ShowNotification = function (message, messageType) {
//    var _icon = '';
//    if (messageType) {
//        switch (messageType) {
//            case 'success': _icon = 'fa fa-check'; break;
//            case 'error': _icon = 'fa fa-ban'; break;
//            case 'warning': _icon = 'fa fa-warning'; break;
//            case 'info': _icon = 'fa fa fa-bullhorn'; break;
//            default: _icon = 'fa fa-check'; break;
//        }
//    }

//    $.notify({
//        icon: _icon,
//        title: '',
//        message: message
//    }, {
//            type: messageType,//'minimalist',// type: "info",
//            delay: 5000,
//            icon_type: 'class',
//            allow_dismiss: true,
//            newest_on_top: true,
//            offset: 20,
//            timer: 1000,
//            spacing: 10,
//            animate: {
//                enter: 'animated fadeInDown',
//                exit: 'animated fadeOutUp'
//            },
//            template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
//                '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">&times;</button>' +
//                '<i data-notify="icon" class="img-circle pull-left">' +
//                //'<span data-notify="title"> {1}</span>' +
//                '<span data-notify="message"> {2}</span>' +
//                '</div>'
//        });
//}

////Date picker
//window.datepickerIntialize =
//    (function () {

//        $('#itemsettemplate').hide();

//        $("select").select2({
//            placeholder: 'select an option',
//            allowClear: true
//        }).on("change", function () {
//            var drp = $(this);
//            if (drp.hasClass("itemchange") && drp.data("controller") != undefined) {
//                drp.siblings("input").val('');

//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                if (drp.hasClass("parents"))
//                    $parent = $(this).parents();

//                $parent.find('select.basiccategory').empty();
//                $parent.find('select.equipment').empty();
//                $parent.find('select.equipmenttype').empty();
//                $parent.find('select.basiccategory').append('<option value=""></option>');
//                $parent.find('select.equipment').append('<option value=""></option>');
//                $parent.find('select.equipmenttype').append('<option value=""></option>');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response.catPtNo != null) {
//                                $parent.find('.catpartno').val(response.catPtNo);
//                            }

//                            $parent.find('.ItemUom').val(response.itemUom);
//                            $parent.find('.place').val(response.place);
//                            $parent.find('.qty').attr("data-place", response.place);
//                            $parent.find('.ItemUomId').val(response.itemUomId);
//                            if (response.basicCategoryList != null && response.basicCategoryList.length > 0) {
//                                for (var i = 0; i < response.basicCategoryList.length; i++) {
//                                    $parent.find('select.basiccategory').append('<option value="' + response.basicCategoryList[i].id + '">' + response.basicCategoryList[i].name + '</option>');
//                                }
//                            }

//                            if (response.equipmentList != null && response.equipmentList.length > 0) {
//                                for (var i = 0; i < response.equipmentList.length; i++) {
//                                    $parent.find('select.equipment').append('<option value="' + response.equipmentList[i].id + '">' + response.equipmentList[i].name + '</option>');
//                                }
//                            }



//                            if (response.equipmentTypeList != null && response.equipmentTypeList.length > 0) {
//                                for (var i = 0; i < response.basicCategoryList.length; i++) {
//                                    $parent.find('select.equipmenttype').append('<option value="' + response.equipmentTypeList[i].id + '">' + response.equipmentTypeList[i].name + '</option>');
//                                }
//                            }

//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });

//                        }


//                    }
//                });
//            }

//            if (drp.hasClass("itemchange_conveynote") && drp.data("controller") != undefined) {
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                $parent.find('itembasiccategory_conveynote').val(' ');
//                $parent.find('itemequipment_conveynote').val(' ');
//                $parent.find('itemequipmenttype_conveynote').val(' ');
//                $parent.find('itembasiccategoryid_conveynote').val(' ');
//                $parent.find('itemequipmentid_conveynote').val(' ');
//                $parent.find('itemequipmenttypeid_conveynote').val(' ');
//                $parent.find('select.groupitemchange_conveynote').empty();
//                $parent.find('select.groupitemchange_conveynote').append('<option value=""></option>')
//                var qty = drp.find(":selected").data("qty");
//                $parent.find('.quantiy_stockquantity').attr("max", qty);
//                $parent.find('.setnoe_availablequantity').val(qty);
//                $.ajax({
//                    type: "POST", url: url, data: { itemId: drp.val(), authorityLetterId: $('.authorityletterid_conveynote').val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response.basicCategoryList != null && response.basicCategoryList.length > 0) {
//                                $parent.find('.itembasiccategory_conveynote').val(response.basicCategoryList[0].name);
//                                $parent.find('.itembasiccategoryid_conveynote').val(response.basicCategoryList[0].id);
//                                $parent.find('.itemuomid_conveynote').val(response.basicCategoryList[0].additionalValue);
//                            }
//                            if (response.equipmentList != null && response.equipmentList.length > 0) {
//                                $parent.find('.itemequipment_conveynote').val(response.equipmentList[0].name);
//                                $parent.find('.itemequipmentid_conveynote').val(response.equipmentList[0].id);
//                            }
//                            if (response.equipmentTypeList != null && response.equipmentTypeList.length > 0) {

//                                $parent.find('.itemequipmenttype_conveynote').val(response.equipmentTypeList[0].name);
//                                $parent.find('.itemequipmenttypeid_conveynote').val(response.equipmentTypeList[0].id);

//                            }
//                            if (response.groupItemList != null && response.groupItemList.length > 0) {
//                                for (var i = 0; i < response.groupItemList.length; i++) {
//                                    $parent.find('select.groupitemchange_conveynote').append('<option value="' + response.groupItemList[i].id + '">' + response.groupItemList[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("groupitemchange_conveynote") && drp.data("controller") != undefined) {
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                $parent.find('select.stockshedchange_conveynote').empty();
//                $parent.find('select.stockshedchange_conveynote').append('<option value=""></option>')
//                $.ajax({
//                    type: "POST", url: url, data: { itemId: $parent.find('.itemchange_conveynote').val(), groupItemId: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {

//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('select.stockshedchange_conveynote').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("stockshedchange_conveynote") && drp.data("controller") != undefined) {
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                $parent.find('select.setnochange_conveynote').empty();
//                $parent.find('select.setnochange_conveynote').append('<option value=""></option>')
//                $.ajax({
//                    type: "POST", url: url, data: { itemId: $parent.find('.itemchange_conveynote').val(), groupItemId: $parent.find('.groupitemchange_conveynote').val(), stockShedId: drp.val(), storeId: $("#StoreId").val(), authorityLetterId: $('.authorityletterid_conveynote').val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('select.setnochange_conveynote').append('<option data-qty=' + response[i].additionalValue + ' value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass('setnochange_conveynote')) {
//                var $parent = $(this).parent().parent();
//                var qty = drp.find(":selected").data("qty");
//                $parent.find('.setnoe_stockquantity').val(qty);
//                //if (parseFloat($parent.find('.setnoe_availablequantity').val()) > parseFloat(qty))
//                //    $parent.find('.quantiy_stockquantity').attr("max", qty);
//            }

//            if (drp.hasClass("groupitemchange_conveningorderitem") && drp.data("controller") != undefined) {
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                $parent.find('select.stockshedchange_conveningorderitem').empty();
//                $parent.find('select.stockshedchange_conveningorderitem').append('<option value=""></option>')
//                $.ajax({
//                    type: "POST", url: url, data: { itemId: $parent.find('.itemid_conveningorderitem').val(), groupItemId: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {

//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('select.stockshedchange_conveningorderitem').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("stockshedchange_conveningorderitem") && drp.data("controller") != undefined) {
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                $parent.find('select.setnochange_conveningorderitem').empty();
//                $parent.find('select.setnochange_conveningorderitem').append('<option value=""></option>')
//                $.ajax({
//                    type: "POST", url: url, data: { itemId: $parent.find('.itemid_conveningorderitem').val(), groupItemId: $parent.find('.groupitemchange_conveningorderitem').val(), stockShedId: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('select.setnochange_conveningorderitem').append('<option data-qty=' + response[i].additionalValue + ' value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            // 
//            if (drp.hasClass("organization")) {

//                var url = "/taskwork/designation";

//                var $parent = $(this).parent().parent();
//                if (drp.hasClass("parents"))
//                    $parent = $(this).parents();
//                $parent.find('select.designation').empty();
//                $parent.find('select.designation').append('<option value=""></option>');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('select.designation').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("organization-task")) {

//                var url = "/taskwork/designation";
//                $('select.designation-task').empty();
//                $('select.designation-task').append('<option value=""></option>');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $('select.designation-task').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                            $("select-task").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("itemcategorychange") && drp.attr('Id') == 'CategoryId') {

//                if (drp.val() != undefined && drp.val() != null && parseInt(drp.val()) > 0) {
//                    $("#addrow").removeClass('hide');
//                    $('#addrow').attr("data-parentId", drp.val());
//                } else {
//                    $("#addrow").addClass('hide');
//                }
//                var url = "/groupitem/item";
//                var $parent = $("#childs");
//                $('#childs > tbody').html(''); //For Blanck grid
//                $parent.find('.groupitemchange').empty();
//                $parent.find('.groupitemchange').append('<option value=""></option>');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response != null && response.length > 0) {
//                                for (var i = 0; i < response.length; i++) {
//                                    $parent.find('.groupitemchange').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                                }
//                            }
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("groupitemchange") && drp.data("controller") != undefined) {
//                drp.siblings("input").val('');
//                var url = "/" + drp.data("controller") + "/" + drp.data("action");
//                var $parent = $(this).parent().parent();
//                if (drp.hasClass("parents"))
//                    $parent = $(this).parents();

//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response.category != null) {
//                                $parent.find('.category').val(response.category.name);
//                            }
//                            if (response.itemUom != null) {
//                                $parent.find('.itemUom').val(response.itemUom.name);
//                            }
//                            if (response.itemUom != null) {
//                                $parent.find('.ItemUomN').val(response.itemUom);
//                            }
//                            $parent.find("select").select2({
//                                placeholder: 'select an option',
//                                allowClear: true
//                            });
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("StoreStockGroupItemChange") && drp.attr('Id') == 'GroupItemId') {
//                var url = "/storestock/groupitemdetails";
//                var $parent = $("#childs");
//                $("#ItemSetNoId").val('').trigger('change');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response.qty != null) {
//                                $parent.find('.qty').val(response.qty);
//                            }
//                            $('#childs > tbody').html(response);
//                            setSerialNumber();
//                        }
//                    }


//                });

//            }

//            if (drp.hasClass("AvlbCertReqCategoryIDCheck")) {
//                if (drp.val() != undefined && drp.val() != null && parseInt($("#BasicCategoryId").val()) > 0 && parseInt(drp.val()) > 0) {
//                    AvlbCertRequestChange($("#BasicCategoryId").val(), drp.val());
//                }
//            }

//            if (drp.hasClass("AvlbCertReqBasicCategoryIDCheck")) {
//                if (drp.val() != undefined && drp.val() != null && parseInt($("#CategoryId").val()) > 0 && parseInt(drp.val()) > 0) {
//                    AvlbCertRequestChange(drp.val(), $("#CategoryId").val());
//                }
//            }

//            if (drp.hasClass("CategoryPartsChange") && drp.attr('Id') == 'ItemId') {
//                drp.siblings("input").val('');
//                var url = "/item/detail";
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        if (response != null && response != undefined) {
//                            if (response.itemUom != null) {
//                                $("#pitemUom").val(response.itemUom);
//                            }

//                        }


//                    }
//                });
//            }

//            if (drp.hasClass("AvlbCertReqItemChange") && drp.attr('Id') == 'GroupItemId') {

//                var url = "/GroupItem/GetdetailWithAU";
//                var $parent = $("#GroupItemId").parents().eq(3);
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {

//                        if (response != null && response != undefined) {
//                            if (response.itemUom != null) {
//                                $("#itemUom").val(response.itemUom.name);
//                            }
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass("ItemSetNumberIdChange")) {
//                var itemno = drp.val();
//                drp.parent().parent().parent().find("table tbody tr").each(function () {
//                    if (itemno != null) {
//                        $(this).find('.itemsetno').val(itemno);
//                    }
//                });

//            }

//            if (drp.hasClass('bd_Organization')) {
//                var url = "/abstconveningorder/getdesignation";
//                var $parent = $(this).closest('tr');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        $parent.find('.bd_Designation').empty();
//                        //$parent.find('.bd_Designation').append('<option>Select an Option</option>');
//                        if (response != null && response != undefined) {
//                            for (var i = 0; i < response.length; i++) {
//                                $parent.find('.bd_Designation').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                            }
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass('Periodicity_CategoryId')) {
//                var url = "/Periodicity/GetItemList";
//                var $parent = $(this).closest('.Periodicity_');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        $parent.find('#Periodicity_ItemGroup').empty();
//                        //$parent.find('.bd_Designation').append('<option>Select an Option</option>');
//                        if (response != null && response != undefined) {
//                            for (var i = 0; i < response.length; i++) {
//                                $parent.find('#Periodicity_ItemGroup').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                            }
//                        }
//                    }
//                });
//            }

//            if (drp.hasClass('maintenancePlan')) {
//                var url = "/JobOrder/GetQuaterPlan";
//                var $parent = $(this).closest('.Periodicity_');
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        $('#QuarterlyMaintenancePlanId').empty();
//                        if (response != null && response != undefined) {
//                            for (var i = 0; i < response.length; i++) {
//                                $('#QuarterlyMaintenancePlanId').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
//                            }
//                        }
//                    }
//                });
//            }


//            if (drp.hasClass('salvageout')) {
//                var url = "/SalvageOut/GetAvailableQty";
//                $.ajax({
//                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
//                        $('#Weight').attr("max", response);
//                    }
//                });
//            }
//        });



//        // $("select.readonly").select2('destroy')

//        $('.datepicker').datepicker({
//            autoclose: true,
//            format: 'dd/mm/yyyy',
//            disableTouchKeyboard: true
//        }).on('changeDate', function (e) {
//            if ($(this).hasClass("input-group")) {
//                //$(this).parent().find(":text").blur()
//            }
//        });


//        $('.qty').on('change', function () {
//            AllowDecimalPlace($(this));
//        });


//    });
//StoreStockRepairableQtyCheck();
//StoreStockServisableQtyCheck();

//var oSettingSwalConfim = { title: "Are you sure?", type: "warning", showCancelButton: true, confirmButtonColor: "#DD6B55", confirmButtonText: "Yes", cancelButtonText: "No", closeOnConfirm: true, closeOnCancel: true };


//$(document).on('click', '#addrow', function () {
//    var url = $(this).attr('data-url');
//    var parentId = $(this).attr('data-parentId');
//    url += "?id=" + parentId;
//    if (url)
//        addnewrow(url);
//});

//$(document).on('click', '.deleterow', function () {
//    var ele = $(this);
//    if (ele.hasClass('hasone') && $('.deleterow').length > 1) {
//        swal(oSettingSwalConfim, function (isConfirm) {
//            if (isConfirm) {
//                $container = ele.parents("tr.item-row");
//                $container.remove();
//                setSerialNumber();

//            }
//        });
//    }
//    if (!ele.hasClass('hasone')) {
//        swal(oSettingSwalConfim, function (isConfirm) {
//            if (isConfirm) {
//                $container = ele.parents("tr.item-row");
//                $container.remove();
//                setSerialNumber();

//            }
//        });
//    }

//    return false;
//});

//$(document).on('click', "#additemrequest", function () {

//    var qty = $("#IQuantiy").val();
//    if (qty != undefined && parseFloat(qty) > 0) {
//        showLoading();
//        var itemVal = $("#GroupItemId").val();
//        var url = "/AvailabilityCertRequest/additem";
//        $parent = $("#childs");
//        $.ajax({
//            type: "POST", url: url, data: { id: itemVal, qty: qty }, success: function (response) {
//                if (response != null && response != undefined) {
//                    if (response.qty != null) {
//                        $parent.find('.qty').val(response.qty);
//                    }
//                    if (response.itemUom != null) {
//                        $parent.find('.itemUom').val(response.itemUom);
//                    }
//                    $('#childs > tbody').append(response);
//                    setSerialNumber();
//                    $parent.find("select").select2({
//                        placeholder: 'select an option',
//                        allowClear: true
//                    });
//                }

//                hideLoading();
//            }
//        });
//    } else {
//        ShowNotification("Please Enter Valid Quantity", 'error');

//    }
//});

//$(document).on('click', "#addpartsrequest", function () {
//    var pqty = $("#PQuantiy").val();
//    var justification = $("#Justification").val();
//    var pitemUom = $("#pitemUom").val();
//    var itemVal = $("#ItemId").val();

//    if (itemVal == undefined || itemVal == null || itemVal == "") {
//        ShowNotification("Please Select part Name", 'error');
//        $("#ItemId").focus();
//        return;
//    }
//    if (pqty == undefined || pqty == null || parseInt(pqty) == 0) {
//        ShowNotification("Please Enter Parts Quantity", 'error');

//        $("#PQuantiy").focus();
//        return;
//    }
//    if (justification == undefined || justification == null || justification == "") {
//        ShowNotification("Please Enter Justification", 'error');

//        $("#Justification").focus();
//        return;
//    }

//    if (justification != undefined && justification != null && pqty != undefined && parseInt(pqty) > 0) {
//        var itemVal = $("#ItemId").val();
//        var url = "/AvailabilityCertRequest/addpart";
//        $parent = $("#childs");
//        $.ajax({
//            type: "POST", url: url, data: { id: itemVal, qty: pqty, justification: justification, uomname: pitemUom }, success: function (response) {
//                if (response != null && response != undefined) {
//                    //if (response.pqty != null) {
//                    //    $parent.find('.pqty').val(response.pqty);
//                    //}
//                    //if (response.pitemUom != null) {
//                    //    $parent.find('.pitemUom').val(response.pitemUom);
//                    //}
//                    //if (response.justification != null) {
//                    //    $parent.find('.justification').val(response.justification);
//                    //}
//                    $('#childs > tbody').append(response);
//                    setSerialNumber();
//                }
//            }
//        });
//    }
//});

//$(document).on('click', "#resetitem", function () {
//    $('#childs > tbody').html('');
//});

//$(document).on('click', '#addSet', function () {
//    addSet();
//});

//$(document).on('click', '#addmoreset', function () {
//    generateSet();

//});


//$(document).on('click', '#displayRecord', function () {
//    var catId = $("#Periodicity_CategoryId").val();
//    var itemId = $("#Periodicity_ItemGroup").val();
//    if (parseInt(catId) > 0) {
//        window.location.href = '/Periodicity/index?catId=' + catId + '&groupitemId=' + itemId;
//    }

//});

//$(document).on('click', '#displayRecordYear', function () {
//    var catId = $("#Periodicity_CategoryId").val();
//    var itemId = $("#Periodicity_ItemGroup").val();
//    var year = $("#Periodicity_year").val();
//    if (parseInt(catId) > 0) {
//        window.location.href = '/ChangePrice/index?catId=' + catId + '&groupitemId=' + itemId + '&year=' + year;
//    }

//});


//function addnewrow(url) {
//    showLoading();
//    $.ajax({ url: url }).success(function (response) {
//        $('#childs > tbody').append(response);
//        $("form").removeData("validator");
//        $("form").removeData("unobtrusiveValidation");
//        $.validator.unobtrusive.parse("form");
//        setSerialNumber();
//        hideLoading();
//        window.datepickerIntialize();
//    });

//}

//function setSerialNumber() {
//    var i = 1;
//    $("#childs > tbody > tr").each(function () {
//        var parent = $(this);
//        var serialnumber = parent.find(".serialnumber");

//        if (serialnumber.val() != undefined) {
//            serialnumber.val(i);
//            i++;
//        }
//    })

//    var j = 1;
//    $("#childs-member > tbody > tr").each(function () {
//        var parent = $(this);
//        var serialnumber = parent.find(".serialnumber");

//        if (serialnumber.val() != undefined) {
//            serialnumber.val(j);
//            j++;
//        }
//    })

//}

//function returnDrodownArr($element) {
//    var droparr = Array();
//    $element.each(function () {
//        droparr.push({
//            value: $(this).val(),
//            text: $(this).text(),
//            isSelected: $(this).is(':selected')
//        });
//    });
//    return droparr;
//}

//function generateSet() {

//    var $table = $('#childs tbody tr');
//    var mainArry = Array();

//    $table.each(function () {
//        mainArry.push({
//            itemsetno: $(this).find('.itemsetno').val(),
//            storeStockId: $(this).find('.StoreStockId').val(),
//            itemName: $(this).find('.itemName').val(),
//            ItemId: $(this).find('.itemId option:selected').val(),
//            item: $(this).find('.itemId option'),
//            itemqty: $(this).find('.itemqty').val(),
//            itemUom: $(this).find('.ItemUom').val(),
//            ItemUomId: $(this).find('.ItemUomId').val(),
//            primaryLedgerNo: $(this).find('.PrimaryLedgerNo').val(),
//            secondaryLedgerNo: $(this).find('.SecondaryLedgerNo').val(),
//            pageNo: $(this).find('.PageNo').val(),
//            stockShed: $(this).find('.StockShed option:selected').text(),
//            Origin: $(this).find('.Origin option'),
//            OriginId: $(this).find('.Origin option:selected').val(),
//            StockShedId: $(this).find('.StockShed option:selected').val(),
//            StockShed: $(this).find('.StockShed option'),
//            HeldByOrgnaizationId: $(this).find('.Origin option:selected').val(),
//            StoreStockId: $(this).find('.StoreStockId').val(),
//            remark: $(this).find('.Remark').val(),
//            storeStockServisableQty: $(this).find('.StoreStockServisableQty').val(),
//            storeStockRepairableQty: $(this).find('.StoreStockRepairableQty').val()
//        });

//    });
//    GenerateItemSetHtml(mainArry);
//}

//function GenerateItemSetHtml(dataArray) {
//    var $htmlTemplate = $('#itemsettemplate').html();
//    var srNo = 0;
//    var $parentDiv = $('#addmoreitemsetdiv');
//    var templateHtml = '';
//    for (var i = 0; i < dataArray.length; i++) {
//        var value = dataArray[i];
//        srNo++;
//        templateHtml += addSet((i + 1), dataArray[i]);
//    }
//    var selectedSetNo = $("#ItemSetNoId").val();
//    var $setNodr = '<select class="form-control  ItemSetNumberIdChange"> <option value="">Please select one</option>';
//    for (var i = 0; i < itemSetNoList.length; i++) {
//        if (selectedSetNo == itemSetNoList[i].Id) {
//            $setNodr += "<option value='" + itemSetNoList[i].Id + "' selected>" + itemSetNoList[i].Name + "</option>";
//        }
//        else {
//            $setNodr += "<option value='" + itemSetNoList[i].Id + "'>" + itemSetNoList[i].Name + "</option>";
//        }
//    }
//    $setNodr += "</select>";
//    $parentDiv.append($htmlTemplate.replace('####', $setNodr).replace('<tbody></tbody>', '<tbody>' + templateHtml) + '</tbody>');
//    window.datepickerIntialize();

//}

//function addSet(srNo, dataObj) {

//    var $itemSelectHtml = '';
//    var $itemSelectOrignHtml = '';
//    var $itemSelectShedHtml = '';
//    for (var i = 0; i < dataObj.item.length; i++) {

//        var selected = dataObj.item[i].selected ? ' selected="selected"' : '';
//        $itemSelectHtml += '<option' + selected + '  value="' + dataObj.item[i].value + '">' + dataObj.item[i].text + '</option>';
//    }

//    for (var i = 0; i < dataObj.Origin.length; i++) {
//        var selected = dataObj.Origin[i].selected ? ' selected="selected"' : '';
//        $itemSelectOrignHtml += '<option' + selected + '  value="' + dataObj.Origin[i].value + '">' + dataObj.Origin[i].text + '</option>';
//    }

//    for (var i = 0; i < dataObj.StockShed.length; i++) {
//        var selected = dataObj.StockShed[i].selected ? ' selected="selected"' : '';
//        $itemSelectShedHtml += '<option' + selected + '  value="' + dataObj.StockShed[i].value + '">' + dataObj.StockShed[i].text + '</option>';
//    }

//    var i = generateUUID();

//    return '<tr><input type="hidden" name="StoreStockTransaction.index" autocomplete="off" value="' + i + '">' +
//        '<td><input type="text" value="' + srNo + '"  class="serialnumber numeric" readonly="readonly" style="width:35px;" />' +
//        '<input type="hidden" name="StoreStockTransaction[' + i + '].StoreStockId" value="' + dataObj.storeStockId + '" /> ' +
//        '<input type="hidden" name="StoreStockTransaction[' + i + '].ItemSetNumberId" value="' + dataObj.itemsetno + '" class="itemsetno" /></td > ' +
//        '<td> <select  name= "StoreStockTransaction[' + i + '].ItemId"  class="form-control">' + $itemSelectHtml + '</select></td > ' +
//        '<td>  <input type="text" value="' + dataObj.itemqty + '" name="StoreStockTransaction[' + i + '].ItemQuantity" readonly="readonly" class="form-control itemqty" /></td>' +
//        '<td><input type="hidden" value="' + dataObj.ItemUomId + '" name="StoreStockTransaction[' + i + '].ItemUomId" class="form-control" />' +
//        '<input type="text" value="' + dataObj.itemUom + '" name="StoreStockTransaction[' + i + '].ItemUomName" readonly="readonly" class="form-control" /></td > ' +
//        '<td><input type="text" value="' + dataObj.primaryLedgerNo + '" name="StoreStockTransaction[' + i + '].PrimaryLedgerNo" class="form-control" /></td>' +
//        '<td><input type="text" value="' + dataObj.secondaryLedgerNo + '" name="StoreStockTransaction[' + i + '].SecondaryLedgerNo" class="form-control" /></td>' +
//        '<td><input type="text" value="' + dataObj.pageNo + '" name="StoreStockTransaction[' + i + '].PageNo" class="form-control" /></td>' +
//        '<td> <select asp-for="StockShedId" name= "StoreStockTransaction[' + i + '].StockShedId"  class="form-control">' + $itemSelectShedHtml + '</select></td > ' +
//        '<td> <select asp-for="OriginId" name= "StoreStockTransaction[' + i + '].OriginId"  class="form-control">' + $itemSelectOrignHtml + '</select></td > ' +
//        '<td><input type="text" value="' + dataObj.remark + '" name="StoreStockTransaction[' + i + '].Remark" class="form-control" /></td>' +
//        '<td><input type="text" value="' + dataObj.storeStockServisableQty + '" name="StoreStockTransaction[' + i + '].SQuantiy" class="form-control StoreStockServisableQty" /><span class="text-danger field-validation-valid" data-valmsg-for="StoreStockTransaction[' + i + '].SQuantiy" data-valmsg-replace="true"></span></td>' +
//        '<td><input type="text" value="' + dataObj.storeStockRepairableQty + '" name="StoreStockTransaction[' + i + '].RQuantiy" class="form-control StoreStockRepairableQty" /><span class="text-danger field-validation-valid" data-valmsg-for="StoreStockTransaction[' + i + '].RQuantiy" data-valmsg-replace="true"></span></td>' +
//        '</tr>';

//}

//function generateUUID() {
//    var d = new Date().getTime();
//    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
//        var r = (d + Math.random() * 16) % 16 | 0;
//        d = Math.floor(d / 16);
//        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
//    });
//    return uuid;
//};

//function RemoveSet() {
//    $('.removeset').on('click', function () {
//        var $row = $(this).closest('.row');
//        swal({
//            title: "Are you sure?",
//            type: "warning",
//            showCancelButton: true,
//            confirmButtonColor: "#DD6B55",
//            confirmButtonText: "Yes, delete it!",
//            cancelButtonText: "No, cancel it!",
//            closeOnConfirm: true,
//            closeOnCancel: true
//        },
//            function (isConfirm) {
//                if (isConfirm) {
//                    $row.remove();
//                    ReCalculareSetNumber();
//                }
//            });
//    });
//}

//function AllowDecimalPlace(element) {
//    var place = parseInt(element.attr('data-place'));
//    element.val(parseFloat(element.val()).toFixed(place));
//}

//var showLoading = function (setting) {
//    setting = jQuery.extend({ Text: 'Please Wait...', Effect: 'ios', background: 'rgba(160, 160, 160, 0.48)', ColorCode: '#000', SizeW: '', SizeH: '', dvContent: 'dvWaitMe' }, setting);

//    var $container = $('#' + setting.dvContent);
//    if ($container.length) {
//        //clear if already opened.
//        $container.removeAttr('class').hide().children().remove();
//        $container.css({
//            'width': '100%',
//            'height': '100%',
//            'position': 'fixed',
//            'top': '0',
//            'left': '0',
//            'z-index': '99999',
//            'display': 'none'
//        });
//        $('body').addClass('ajax-waitme');
//        $container.waitMe({
//            effect: setting.Effect,
//            text: setting.Text,
//            bg: setting.background,
//            color: setting.ColorCode,
//            sizeW: setting.SizeW,
//            sizeH: setting.SizeH
//        });
//        $container.show();
//    }
//};

//var hideLoading = function (setting) {
//    setting = jQuery.extend({ dvContent: 'dvWaitMe' }, setting);
//    var $container = $('#' + setting.dvContent);
//    $container.removeAttr('class').hide().children().remove();
//    $('body').removeClass('ajax-waitme');
//};
