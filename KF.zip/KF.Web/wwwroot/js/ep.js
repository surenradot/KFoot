﻿$(document).ready(function () {
    window.datepickerIntialize();
    setSerialNumber();


    $('.ColUpDwn').on('keyup', function (e) {
        var ClassName = "";
        if ($(this).hasClass("C1")) { ClassName = "C1"; }
        if ($(this).hasClass("C2")) { ClassName = "C2"; }
        if ($(this).hasClass("C3")) { ClassName = "C3"; }
        if ($(this).hasClass("C4")) { ClassName = "C4"; }
        if ($(this).hasClass("C5")) { ClassName = "C5"; }
        if ($(this).hasClass("C6")) { ClassName = "C6"; }
        if ($(this).hasClass("C7")) { ClassName = "C7"; }
        if ($(this).hasClass("C8")) { ClassName = "C8"; }
        if ($(this).hasClass("C9")) { ClassName = "C9"; }
        if ($(this).hasClass("C10")) { ClassName = "C10"; }
        if (ClassName !== "") {
            RunAction(this, e.which, ClassName);
        }
    });

    //Move Rows
    //var fixHelperModified = function (e, tr) {
    //    var $originals = tr.children();
    //    var $helper = tr.clone();
    //    $helper.children().each(function (index) {
    //        $(this).width($originals.eq(index).width());
    //    });
    //    return $helper;
    //};
    //updateIndex = function (e, ui) {
    //    $('td.index', ui.item.parent()).each(function (i) {
    //        $(this).html(i + 1);
    //    });
    //    $('input[type=text]', ui.item.parent()).each(function (i) {
    //        $(this).val(i + 1);
    //    });
    //};

    //$("#MoveRows tbody").sortable({
    //    helper: fixHelperModified,
    //    stop: updateIndex
    //}).disableSelection();

    //$("tbody").sortable({
    //    distance: 5,
    //    delay: 100,
    //    opacity: 0.6,
    //    cursor: 'move',
    //    update: function () { }
    //});
    // End Move Row
});
function RunAction(obj, val1, val2) {
    switch (val1) {
        case 38:
            $(obj).closest('tr').prev().find('.' + val2).select();
            break;
        case 40:
            $(obj).closest('tr').next().find('.' + val2).select();
            break;
    }
}


$(function () {
    $("form").bind("submit", function () {
        var _form = $(this);

        if ($.validator.unobtrusive != undefined) {
            $.validator.unobtrusive.parse(_form);
        }
        if ($(_form).valid() && $(_form).find('.field-validation-error').length == 0) {
            if (!_form.hasClass('notshow')) {
                showLoading();
            }
        } else {
            return false;
        }
    });
});

//Date picker
window.datepickerIntialize =
    (function () {
        $("select").not('.notselect2').select2({
            placeholder: 'select an option',
            allowClear: true
        }).on("change", function () {
            var drp = $(this);

            if (drp.hasClass("itemchange") && drp.data("controller") != undefined) {
                drp.siblings("input").val('');
                var url = "/" + drp.data("controller") + "/" + drp.data("action");
                var $parent = $(this).parent().parent();
                if (drp.hasClass("parents"))
                    $parent = $(this).parents();

                $parent.find('select.basiccategory').empty();
                $parent.find('select.equipment').empty();
                $parent.find('select.equipmenttype').empty();
                $parent.find('select.basiccategory').append('<option value=""></option>');
                $parent.find('select.equipment').append('<option value=""></option>');
                $parent.find('select.equipmenttype').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {

                            if (response.catPtNo != null) {
                                $parent.find('.catpartno').val(response.catPtNo);
                            }

                            if (response.basicCategoryList != null && response.basicCategoryList.length > 0) {
                                for (var i = 0; i < response.basicCategoryList.length; i++) {
                                    $parent.find('select.basiccategory').append('<option value="' + response.basicCategoryList[i].id + '">' + response.basicCategoryList[i].name + '</option>');
                                }
                            }

                            if (response.equipmentList != null && response.equipmentList.length > 0) {
                                for (var i = 0; i < response.equipmentList.length; i++) {
                                    $parent.find('select.equipment').append('<option value="' + response.equipmentList[i].id + '">' + response.equipmentList[i].name + '</option>');
                                }
                            }


                            if (response.equipmentTypeList != null && response.equipmentTypeList.length > 0) {
                                for (var i = 0; i < response.basicCategoryList.length; i++) {
                                    $parent.find('select.equipmenttype').append('<option value="' + response.equipmentTypeList[i].id + '">' + response.equipmentTypeList[i].name + '</option>');
                                }
                            }

                            $parent.find("select").select2({
                                placeholder: 'select an option'
                            });

                        }


                    }
                });
            }

            if (drp.hasClass("organization")) {

                var url = "/taskwork/designation";
                var $parent = $(this).parent().parent();
                if (drp.hasClass("parents"))
                    $parent = $(this).parents();


                $parent.find('select.designation').empty();
                $parent.find('select.designation').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {

                            if (response != null && response.length > 0) {
                                for (var i = 0; i < response.length; i++) {
                                    $parent.find('select.designation').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
                                }
                            }
                            $parent.find("select").select2({
                                placeholder: 'select an option'
                            });

                        }


                    }
                });
            }


            if (drp.hasClass("ExaminationNameMaster")) {
                var $parent = $(this).parent().parent();                
                var url = "/ResultMasterSetting/ExamList";
                if (drp.hasClass("parents"))
                    $parent = $(this).parents();
                var a = drp.val();
                var Rowindex = $parent.find('.serialnumber');
                var drDisolay = $parent.find('.DisplayFormat');
                if (drp.val() == ("0E6FB3E0-0D9B-4D51-A8ED-9F4669850B71").toLowerCase()) {
                    drDisolay.prop("disabled", false);
                    // $('#MyModel').modal('show');
                    var indexId = $(this).closest('tr').find('[name="ResultMaster.index"]').val();
                    $("#selectedindex").val(indexId);
                    var selectedId = $(this).closest('tr').find(".CustomExamIdfield").val();
                    $.ajax({
                        type: "POST", url: url, data: { id: drp.val(), RI: Rowindex.val(), selectedId: selectedId }, success: function (response) {                            
                            if (response != null && response != undefined) {
                                $('#CustumTable').html(response);
                                $('#MyModel').modal('show');
                            }
                        }
                    });

                }
                else {
                    drDisolay.prop("disabled", true);
                    drDisolay.val(null).trigger('change');
                }




            }


            //For Route Change In Transport History Grid
            if (drp.hasClass("RouteChangeGrid") && drp.attr('Id') == 'VehicleRouteIdGrid') {
                if (drp.val() != undefined && drp.val() != null) {

                    var url = "/BusFee/FillStoppageList";
                    // var $parent = $("#VehicleRouteId").parents().eq(6);

                    var drp = $(this);
                    var $parent = drp.parent().parent();
                    if (drp.hasClass("parents"))
                        $parent = drp.parents();

                    showLoading();
                    $parent.find('.stoppageGrid').empty();
                    $parent.find('.stoppageGrid').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { VehicleRouteId: drp.val() }, success: function (response) {
                            var stoppageList = response.stoppagelist;
                            //// debugger;
                            if (stoppageList != null && stoppageList != undefined) {
                                // debugger;
                                if (stoppageList != null && stoppageList.length > 0) {
                                    for (var i = 0; i < stoppageList.length; i++) {
                                        $parent.find('.stoppageGrid').append('<option value="' + stoppageList[i].id + '">' + stoppageList[i].name + '</option>');
                                        hideLoading();
                                    }
                                }
                            }
                        }
                    });
                }
            }

            //For Route Change 
            if (drp.hasClass("Route") && drp.attr('Id') == 'RouteId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //get Stoppage List
                    {
                        var url = "/TransportReport/FillStoppageList";
                        // var $parent = $("#VehicleRouteId").parents().eq(6);

                        var drp = $(this);
                        var $parent = drp.parent().parent();
                        if (drp.hasClass("parents"))
                            $parent = drp.parents();

                        showLoading();
                        $parent.find('.Stoppage').empty();
                        $parent.find('.Stoppage').append('<option value=""></option>');
                        $.ajax({
                            type: "POST", url: url, data: { VehicleRouteId: drp.val() }, success: function (response) {
                                var stoppageList = response.stoppagelist;
                                // debugger;
                                if (stoppageList != null && stoppageList != undefined) {
                                    // debugger;
                                    if (stoppageList != null && stoppageList.length > 0) {
                                        for (var i = 0; i < stoppageList.length; i++) {
                                            $parent.find('.Stoppage').append('<option value="' + stoppageList[i].id + '">' + stoppageList[i].name + '</option>');
                                            hideLoading();
                                        }
                                    }
                                }
                            }
                        });
                    }
                    //Get Vehicle List
                    {
                        var url = "/TransportReport/FillVehicleList";
                        // var $parent = $("#VehicleRouteId").parents().eq(6);

                        var drp = $(this);
                        var $parent = drp.parent().parent();
                        if (drp.hasClass("parents"))
                            $parent = drp.parents();

                        showLoading();
                        $parent.find('.Vehicle').empty();
                        $parent.find('.Vehicle').append('<option value=""></option>');
                        $.ajax({
                            type: "POST", url: url, data: { VehicleRouteId: drp.val() }, success: function (response) {
                                var vehicleList = response.vehiclelist;
                                // debugger;
                                if (vehicleList != null && vehicleList != undefined) {
                                    // debugger;
                                    if (vehicleList != null && vehicleList.length > 0) {
                                        for (var i = 0; i < vehicleList.length; i++) {
                                            $parent.find('.Vehicle').append('<option value="' + vehicleList[i].id + '">' + vehicleList[i].name + '</option>');
                                            hideLoading();
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
            }


            if (drp.hasClass("RoomMasterChange") && drp.attr('Id') == 'RoomCatId') {
              //  debugger;
                var url = "/HostelFee/FillRoomMasterComboList";
                var drp = $(this);
                var $parent = drp.parent().parent();
                if (drp.hasClass("parents"))
                    $parent = drp.parents();
                var buildingid = $parent.find('.buildingid').val();
                var floorid = $parent.find('.floorid').val();
                var roomcatid = drp.val();
                showLoading();
                $parent.find('select.roommasterlist').empty();
                $parent.find('select.roommasterlist').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { RoomCatId: roomcatid, BuildingId: buildingid, FloorId: floorid }, success: function (response) {
                        if (response != null && response != undefined) {
                            if (response.roomlist != null && response.roomlist.length > 0) {
                                for (var i = 0; i < response.roomlist.length; i++) {
                                    $parent.find('select.roommasterlist').append('<option value="' + response.roomlist[i].id + '">' + response.roomlist[i].name + '</option>');
                                }
                                hideLoading();
                            }
                        }
                    }
                });
            }


            if (drp.hasClass("groupitem") && drp.attr('Id') == 'StockItemId') {

                var url = "/StockSale/GetItemRate";
                var $parent = $(this).parent().parent();
                if (drp.hasClass("parents"))
                    $parent = $(this).parents();

                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        //  debugger;
                        if (response != null && response != undefined) {
                            if (response != null) {
                                $parent.find(".Qty").val(1);
                                $parent.find(".Rate").val(response.saleRate);
                                $parent.find(".CgstRate").val(response.cgstSale);
                                $parent.find(".SgstRate").val(response.sgstSale);
                                $parent.find(".DiscountP").val(response.discountPer);
                                Stockcalculation($parent.closest('tr'));

                            }


                        }


                    }
                });
            }

            if (drp.hasClass("StudentChange") && drp.attr('Id') == 'StudId') {

                var url = "/StockSale/FillStudentDetail";
                var $parent = $('#StudId').parents().eq(3);
                if (drp.hasClass("parents"))
                    $parent = $(this).parents();

                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        // debugger;
                        if (response != null && response != undefined) {
                            if (response != null) {
                                $parent.find(".Student").val(response.studentFullName);
                                $parent.find(".FName").val(response.fatherName);
                                $parent.find(".clsName").val(response.class);
                            }


                        }


                    }
                });
            }

            if (drp.hasClass("itemcategorychange") && drp.attr('Id') == 'StockCategoryId') {

                var url = "/groupitem/item";
                var $parent = $("#childs");

                $parent.find('.groupitem').empty();
                $parent.find('.groupitem').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {

                            if (response != null && response.length > 0) {
                                for (var i = 0; i < response.length; i++) {
                                    $parent.find('.groupitem').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
                                }
                            }
                        }

                    }
                });
            }


            //vbg==================            
            if (drp.hasClass("ClassMasterTeacherChange") && drp.attr('Id') == 'ClassMasterId') {
               // debugger;
                
                var url = "/ClassSubTeacher/FillSubjectList";
                var $parent = $(this).closest('tr');

                $parent.find('.SubjectList').empty();
                $parent.find('.SubjectList').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                       // debugger;
                        if (response != null && response != undefined) {
                            if (response.subjectList != null && response.subjectList.length > 0) {
                                for (var i = 0; i < response.subjectList.length; i++) {
                                    //$parent.find('.SubjectList').append('<option value="' + response.subjectList[i].subjectId + '">' + response.subjectList[i].subjectName + '</option>');
                                    $parent.find('.SubjectList').append('<option value="' + response.subjectList[i].id + '">' + response.subjectList[i].subjectName + '</option>');
                                }
                            }
                            $parent.find("select").select2({
                                placeholder: 'select an option'
                            });
                        }


                    }
                });
            }

            if (drp.hasClass("ExamType") && drp.attr('Id') == 'IdExamType') {
                // debugger;
                var url = "/PublishResult/FillExamList";
                //var $parent = $(this).closest('tr');
                var drp = $(this);
                var $parent = drp.parent().parent();
                if (drp.hasClass("parents"))
                    $parent = drp.parents();

                $parent.find('.Examlist').empty();
                $parent.find('.Examlist').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { ExamType: drp.val() }, success: function (response1) {
                      //  debugger;
                        var response = response1.data;
                        if (response != null && response != undefined) {
                            if (response != null && response.length > 0) {
                                for (var i = 0; i < response.length; i++) {
                                    $parent.find('.Examlist').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
                                }
                            }
                            $parent.find("select").select2({
                                placeholder: 'select an option',
                                allowClear:true
                            });
                        }


                    }
                });
            }

            //=====================

            if (drp.hasClass("itemcategorychange1") && drp.attr('Id') == 'StockCategoryId') {
                //debugger;
                var url = "/StockEntry/item";
                //var $parent = $("#childs");
                //  var $parent = $(this).parents();

                //var $parent = $(this).parent().parent();
                //if (drp.hasClass("parents"))
                //    $parent = $(this).parents();

                var $parent = $(this).closest('tr');

                $parent.find('.groupitem').empty();
                $parent.find('.groupitem').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {

                            if (response != null && response.length > 0) {
                                for (var i = 0; i < response.length; i++) {
                                    $parent.find('.groupitem').append('<option value="' + response[i].id + '">' + response[i].name + '</option>');
                                }
                            }
                            $parent.find("select").select2({
                                placeholder: 'select an option'
                            });
                        }


                    }
                });
            }

            if (drp.hasClass("StockGroupItemChange") && drp.attr('Id') == 'StockGroupItemId') {
                //  debugger;
                var url = "/StockSale/LoadSetData";
                var $parent = $("#childs");

                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {
                            $('#childs > tbody').html(response);
                            setSerialNumber();
                            SetBillTotal();
                        }

                    }
                });
            }


            if (drp.hasClass("FacultyMasterSetting") || (drp.hasClass("CategorySetting"))) {
              //  debugger;
                var url = "/ResultAdvanceSetting/LoadData";
                var $parent = $("#childs");
                var FacultyId = $("#FacultyMasterId").val();
                var CategoryId = $("#CategoryId").val();

                $.ajax({
                    type: "POST", url: url, data: { fid: FacultyId, catid: CategoryId }, success: function (response) {
                        if (response != null && response != undefined) {
                            $('#childs > tbody').html(response);
                            setSerialNumber();
                        }

                    }
                });
            }




            if (drp.hasClass("classfeestructure")) {

                ClassStructru();
            }

            if (drp.hasClass("FillData")) {
                //debugger;
                showLoading();
                FillNonScholasticSubSubject();
                hideLoading();
            }
            if (drp.hasClass("FillGrade")) {
                //debugger;
                showLoading();
                FillNonScholasticGrade();
                hideLoading();
            }

            //if (drp.hasClass("DayId")) {
            //    //alert('Hi vishwa');
            //    DaywiseTimeTable();
            //}


            if (drp.hasClass("NonScholasticSubject")) {
                var url = "/NonScholasticSubjectMaster/Modify";
                var $parent = $("#childs");
                showLoading();
                var ClassMasterId = $("#ClassMasterId").val();
                $.ajax({
                    type: "POST", url: url, data: { cmid: ClassMasterId }, success: function (response) {
                        if (response != null && response != undefined) {
                            $('#childs > tbody').html(response);
                            setSerialNumber();
                            hideLoading();
                        }

                    }
                });
            }
            /*=================================================Fees Module Valiation=========================================*/
            if (drp.hasClass("InstallmentDueDate") && drp.attr('Id') == 'InstallmentDue') {
                FeeCalculation(drp.val());
            }
            /*===============================================================================================================*/

            if (drp.hasClass("classmasterchange") && drp.attr('Id') == 'Classid') {
                //  debugger;
                var url = "/Student/AddClassDocument";
                var $parent = $("#childs");

                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response != null && response != undefined) {
                            $('#childs > tbody').html(response);
                            setSerialNumber();
                        }

                    }
                });

            }

            if (drp.hasClass("sessionchange") && drp.attr('Id') == 'SessionId') {
                var url = "/" + drp.data("controller") + "/" + drp.data("action");
                var $parent = $(this).closest('tr');
                $parent.find('.classmaster').empty();
                $parent.find('.classmaster').append('<option value=""></option>');
                $parent.find('.section').empty();
                $parent.find('.section').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response.classList != null && response.classList != undefined) {
                            if (response.classList != null && response.classList.length > 0) {
                                for (var i = 0; i < response.classList.length; i++) {
                                    $parent.find('.classmaster').append('<option value="' + response.classList[i].id + '">' + response.classList[i].name + '</option>');
                                }
                            }
                        }
                        if (response.sectionList != null && response.sectionList != undefined) {
                            if (response.sectionList != null && response.sectionList.length > 0) {
                                for (var j = 0; j < response.sectionList.length; j++) {
                                    $parent.find('.section').append('<option value="' + response.sectionList[j].id + '">' + response.sectionList[j].name + '</option>');
                                }
                            }
                        }

                    }
                });
            }
            //======================================Sessionwise Class and Section==================================================
            if (drp.hasClass("StudentSession") && drp.attr('Id') == 'StudentSessionId') {
              //  debugger;
                var url = "/student/ClassSectionList";
                var $parent = $(this).closest('tr');
                $('#Classid').empty();
                $('#Classid').append('<option value=""></option>');
                $('#SectionId').empty();
                $('#SectionId').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { id: drp.val() }, success: function (response) {
                        if (response.classList != null && response.classList != undefined) {
                            if (response.classList != null && response.classList.length > 0) {
                                for (var i = 0; i < response.classList.length; i++) {
                                    $('#Classid').append('<option value="' + response.classList[i].id + '">' + response.classList[i].name + '</option>');
                                }
                            }
                        }
                        if (response.sectionList != null && response.sectionList != undefined) {
                            if (response.sectionList != null && response.sectionList.length > 0) {
                                for (var j = 0; j < response.sectionList.length; j++) {
                                    $('#SectionId').append('<option value="' + response.sectionList[j].id + '">' + response.sectionList[j].name + '</option>');
                                }
                            }
                        }

                    }
                });
            }
            //======================================================================================
            if (drp.hasClass("StudentSubjectClassIdCheck") && drp.attr('Id') == 'ClassMasterId') {
               // debugger;
                if (drp.val() != undefined && drp.val() != null) {
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#sectionid").parents().eq(4);
                    $parent.find('.section').empty();
                    $parent.find('.section').append('<option value=""></option>');
                    //var $parent = $("#classsubjectid").parents().eq(4);
                    $parent.find('.subject').empty();
                    $parent.find('.Chapter').empty();
                    $parent.find('.Employee').empty();
                    $parent.find('.subject').append('<option value=""></option>');
                    $('#Save').prop('disabled', true);
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;
                            var subjectList = response.subject;
                            //debugger;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.section').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }

                            if (subjectList != null && subjectList != undefined) {
                                if (subjectList != null && subjectList.length > 0) {
                                    for (var i = 0; i < subjectList.length; i++) {
                                        $parent.find('.subject').append('<option value="' + subjectList[i].id + '">' + subjectList[i].name + '</option>');
                                    }
                                }
                            }

                           //// Used in ResultWhiteSheet to fill checklist only
                            var $subject = $("#ResultWhiteSheetSubject");
                            $subject.empty();
                            $subject.append('<tr class="item-row"><td style="padding-top:10px"><b>Subject</b></td> </tr>');
                            //debugger;
                            for (var i = 0; i < subjectList.length; i++) {
                               // $subject.append('<tr><td width="3%" style="text-align:left; background-color:white;">  <label style="font-weight:normal"> <input type = "checkbox" value="' + subjectList[i].id + '" class= "minimal" name="SubjectList[' + i + '].id">' + subjectList[i].name + '</label ></td></tr>');
                               // $subject.append('<tr><td width="3%" style="text-align:left; background-color:white;"><input type="hidden" asp-for="' + subjectList[i].id + '" name="' + subjectList[i].id + '" class="form-control" /><input type="checkbox" style="width:100%" asp-for="' + subjectList[i].isCheck + '" name="' + subjectList[i].id + '" class="checkbox" /></td><td width="25%" style="text-align:left; background-color:white;padding:1px">' + subjectList[i].name +'</td> </tr>');
                                $subject.append('<tr><td width = "3%" style = "text-align:left; background-color:white;" > <input type="hidden" name="subjectList[' + i + '].Id" class="form-control" id="Item1_Id" value="' + subjectList[i].id + '"> <input type="checkbox" style="width:100%" name="subjectList[' + i + '].IsCheck" class="checkbox" id="Item1_IsCheck" value="true"> </td><td width="25%" style="text-align:left; background-color:white;padding:1px">' + subjectList[i].name + '</td></tr >');
                            }


                        }
                    });
                }
            }
            //=====================================Used in ExamTimeTable=================================================
            if (drp.hasClass("ClassExamTimeTable") && drp.attr('Id') == 'ClassMasterId') {
                debugger;
                if (drp.val() != undefined && drp.val() != null) {
                    var $parent2 = $("#childs");
                    $parent2.find('.subject').empty();
                    var response = "";
                    $('#childs > tbody').html(response);
                    $parent2.find('.subject').append('<option value=""></option>');
                    $("#addrow").attr('data-parentId', drp.val());
                   
                   
                }
            }

            //=====================================Used in TimeTable=================================================
            if (drp.hasClass("SectionSubjectTimeTable") && drp.attr('Id') == 'ClassMasterId') {
                //debugger;
                if (drp.val() != undefined && drp.val() != null) {
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#sectionid").parents().eq(4);
                    $parent.find('.section').empty();
                    $parent.find('.section').append('<option value=""></option>');

                    var $parent2 = $("#childs");
                    $parent2.find('.subject').empty();
                    $parent2.find('.subject').append('<option value=""></option>');

                    $parent2.find('.EmpList').empty();
                    $parent2.find('.EmpList').append('<option value=""></option>');
                    
                    $("#addrow").attr('data-parentId', drp.val());

                    $('#Save').prop('disabled', true);
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;
                            var subjectList = response.subject;
                            //debugger;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.section').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }

                            if (subjectList != null && subjectList != undefined) {
                                if (subjectList != null && subjectList.length > 0) {
                                   // debugger;
                                    for (var i = 0; i < subjectList.length; i++) {
                                        $parent2.find('.subject').append('<option value="' + subjectList[i].id + '">' + subjectList[i].name + '</option>');
                                    }
                                    $parent2.find('.subject').append('<option value="AAEB7A16-59F5-4818-89DC-E60EE13E529D">' + "Assembly" + '</option>');
                                    $parent2.find('.subject').append('<option value="82C72EF6-5C9E-4BCE-B21B-80FA313AD149">' + "Interval" + '</option>');
                                }
                            }
                        }
                    });
                }
            }

            //========Time Table Grid To Fill teacher list dependent on ClassMasterId and Subject Id=============            
            if (drp.hasClass("TimeTableSubject") && drp.attr('Id') == 'SubjectId') {
                
                var url = "/TimeTable/FillEmpList";
                var $parent = $(this).closest('tr');
                var ClassId = $("#ClassMasterId").val();
                
                $parent.find('.EmpList').empty();
                $parent.find('.EmpList').append('<option value=""></option>');
                $.ajax({
                    type: "POST", url: url, data: { ClassMasterId: ClassId, SubjectId: drp.val() }, success: function (response) {
                        
                        var teacherList = response.teacherList;
                        if (teacherList != null && teacherList != undefined) {
                            if (teacherList != null && teacherList.length > 0) {
                                for (var i = 0; i < teacherList.length; i++) {
                                    $parent.find('.EmpList').append('<option value="' + teacherList[i].id + '">' + teacherList[i].name + '</option>');
                                }
                            }
                            $parent.find("select").select2({
                                placeholder: 'select an option',
                                allowClear: true
                            });
                        }


                    }
                });
            }


            //===========================================================================================

            //Fee Head wise Due Date
            if (drp.hasClass("FeeHead") && drp.attr('Id') == 'FeesHeadId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //  debugger;
                    var url = "/Discount/FillDuedate";
                    var $parent = $("#InstallmentDate").parents().eq(4);
                    $parent.find('.InstallmentDate').empty();
                    var StudId = $("#StudentId").val();
                    $parent.find('.InstallmentDate').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { FeeHeadId: drp.val(), StudentId: StudId }, success: function (response) {
                            var sectionList = response.dueDateList;
                            // debugger;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('#InstallmentDate').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                }
            }

            //Subject wise Chapter and Teacher List========================================
            if (drp.hasClass("subject") && drp.attr('Id') == 'Subjectid') {
                if (drp.val() != undefined && drp.val() != null) {
                    //debugger;
                    var url = "/Progress/FillChapterList";
                    var $parent = $("#ClassMasterId").parents().eq(4);
                    $parent.find('.Chapter').empty();
                    $parent.find('.Employee').empty();
                    var ClassId = $("#ClassMasterId").val();
                    $parent.find('.Chapter').append('<option value=""></option>');
                    $parent.find('.Employee').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { SubjectId: drp.val(), ClassMasterId: ClassId }, success: function (response) {
                            var chapterList = response.chapterList;
                            // debugger;
                            if (chapterList != null && chapterList != undefined) {
                                if (chapterList != null && chapterList.length > 0) {
                                    for (var i = 0; i < chapterList.length; i++) {
                                        $parent.find('#ChapterId').append('<option value="' + chapterList[i].id + '">' + chapterList[i].name + '</option>');
                                    }
                                }
                            }
                            var teacherList = response.teacherList;
                            // debugger;
                            if (teacherList != null && teacherList != undefined) {
                                if (teacherList != null && teacherList.length > 0) {
                                    for (var i = 0; i < teacherList.length; i++) {
                                        $parent.find('#EmployeeId').append('<option value="' + teacherList[i].id + '">' + teacherList[i].name + '</option>');
                                    }
                                }
                            }

                        }
                    });

                }
            }


            //following --vishwa-- function is being used to Fill Class and Dependent Section in Grid (ClassTeacherAssign)
            if (drp.hasClass("classmasterCT") && drp.attr('Id') == 'ClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    showLoading();
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    //var $parent = $("#Fromsectionid").parents().eq(4);
                    //debugger;
                    var $parent = $(this).closest('tr');
                    $parent.find('.sectionCT').empty();
                    $parent.find('.sectionCT').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;

                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.sectionCT').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });

                    hideLoading();
                }
            }

            //Class and Dependent Section  ex PublishResult
            if (drp.hasClass("FromclassmasterAttendance") && drp.attr('Id') == 'FromClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //alert('hello');
                    showLoading();
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#Fromsectionid").parents().eq(4);
                    $parent.find('.Fromsection').empty();
                    $parent.find('.Fromsection').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;

                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.Fromsection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                    hideLoading();
                }
            }

            //Class and Dependent Section  and Result dropdown ReportCard
            if (drp.hasClass("ClassmasterReportCard") && drp.attr('Id') == 'ClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    showLoading();
                   
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#Fromsectionid").parents().eq(4);
                    $parent.find('.Fromsection').empty();
                    $parent.find('.Fromsection').append('<option value=""></option>');
                    $parent.find('.ResultMasterSetting').empty();
                    $parent.find('.ResultMasterSetting').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.Fromsection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }

                            var resultlist = response.resultlist;
                            if (resultlist != null && resultlist != undefined) {
                                if (resultlist != null && resultlist.length > 0) {
                                    for (var i = 0; i < resultlist.length; i++) {
                                        $parent.find('.ResultMasterSetting').append('<option value="' + resultlist[i].id + '">' + resultlist[i].name + '</option>');
                                    }
                                }
                            }

                        }
                    });
                    hideLoading();
                }
            }


            //Used in Attendance only
            if (drp.hasClass("FromclassmasterAttendanceOnly") && drp.attr('Id') == 'FromClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    showLoading();
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#Fromsectionid").parents().eq(4);
                    $parent.find('.Fromsection').empty();
                    $parent.find('.Fromsection').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;

                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.Fromsection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });


                    var urlN = "/Attendance/FillInningList";
                    $parent.find('.Innings').empty();
                    $parent.find('.Innings').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: urlN, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var InningList = response.inningListN;

                            if (InningList != null && InningList != undefined) {
                                if (InningList != null && InningList.length > 0) {
                                    for (var i = 0; i < InningList.length; i++) {
                                        $parent.find('.Innings').append('<option value="' + InningList[i].id + '">' + InningList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                    hideLoading();


                }
            }

            //to fill Subject List In class combo used on MarksEntryController
            if (drp.hasClass("ClassMasterMarks") && drp.attr('Id') == 'ClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    showLoading();
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#SubjectId").parents().eq(4);
                    $parent.find('.Subjectlist').empty();
                    $parent.find('.Subjectlist').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var SubjectList = response.subjectList;
                            if (SubjectList != null && SubjectList != undefined) {
                                if (SubjectList != null && SubjectList.length > 0) {
                                    for (var i = 0; i < SubjectList.length; i++) {
                                        $parent.find('.Subjectlist').append('<option value="' + SubjectList[i].id + '">' + SubjectList[i].subjectName + '</option>');
                                    }
                                }
                            }
                        }
                    });
                    hideLoading();

                }
            }


            // To fill NonScholasticSubSubjectMaster
            if (drp.hasClass("ClassNonScholasticSubject") && drp.attr('Id') == 'ClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {

                    showLoading();
                    var urlN = "/NonScholasticSubSubjectMaster/FillNonScholasticSubjectList";
                    var $parent = $("#ClassMasterId").parents().eq(4);
                    $parent.find('.NonScholasticSubSubject').empty();
                    $parent.find('.subsubject').empty();
                    $parent.find('.NonScholasticSubSubject').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: urlN, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var InningList = response.inningListN;

                            if (InningList != null && InningList != undefined) {
                                if (InningList != null && InningList.length > 0) {
                                    for (var i = 0; i < InningList.length; i++) {
                                        $parent.find('.NonScholasticSubSubject').append('<option value="' + InningList[i].id + '">' + InningList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });


                    var url1 = "/Attendance/FillSectionListFROM";
                    var $parent1 = $("#Fromsectionid").parents().eq(4);
                    $parent1.find('.Fromsection').empty();
                    $parent1.find('.Fromsection').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url1, data: { ClassMasterId: drp.val() }, success: function (response) {
                            var sectionList = response.section;

                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent1.find('.Fromsection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });


                    hideLoading();


                }
            }

            // To fill NonScholastic Sub SubjectMaster dheck this function 05-12-2018
            if (drp.hasClass("NonScholasticSubSubject") && drp.attr('Id') == 'SubjectId') {
                if (drp.val() != undefined && drp.val() != null) {
                   // debugger;
                    showLoading();
                    var url = "/NonScholasticSubSubjectMaster/SubSbjectList";
                    var $parent = $("#SubjectId").parents().eq(4);
                    var ClassMasterId = $("#ClassMasterId").val();
                    var NonScholasticSubjectMasterID = $("#SubjectId").val();

                    $parent.find('.subsubject').empty();
                    $parent.find('.subsubject').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { cmid: ClassMasterId, insid: NonScholasticSubjectMasterID }, success: function (response) {
                            var InningList = response.subsubjectlist;
                          //  debugger;
                            if (InningList != null && InningList != undefined) {
                                if (InningList != null && InningList.length > 0) {
                                    for (var i = 0; i < InningList.length; i++) {
                                        $parent.find('.subsubject').append('<option value="' + InningList[i].id + '">' + InningList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                    hideLoading();

                }
            }

            if (drp.has("subject") || drp.has("section") || drp.has("classmaster")) {
                if (drp.val() != undefined && drp.val() != null) {
                    // $('#Save').prop('disabled', true);//commented on 01/01/2018
                }
            }

            //if (drp.hasClass("CheckDuplicateSession") && drp.attr('Id') == 'FromSessionId' || drp.attr('Id') == 'ToSessionId') {                
            //    var url = "/" + drp.data("controller") + "/" + drp.data("action");ToSessionId
            //    var fromsessionid = $("#FromSessionId").val();
            //    var tosessionid = $("#ToSessionId").val();
            //    //debugger;
            //    if (fromsessionid == tosessionid) {
            //        alert("Warning! Session(From) and Session(To) cannot be same value.");
            //        drp.val("");
            //    }
            //}

            if (drp.hasClass("CheckClassIdforChangeSectionFrom") && drp.attr('Id') == 'FromClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {

                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#Fromsectionid").parents().eq(4);
                    var fromsession = $("#FromSessionId").val();
                    $parent.find('.Fromsection').empty();
                    $parent.find('.Fromsection').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val(), FromSessionId: fromsession }, success: function (response) {
                            var sectionList = response.section;
                            //debugger;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.Fromsection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                }
            }

            if (drp.hasClass("CheckClassIdforChangeSectionTo") && drp.attr('Id') == 'ToClassMasterId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //debugger;
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#Tosectionid").parents().eq(4);
                    var tosession = $("#ToSessionId").val();

                    $parent.find('.Tosection').empty();
                    $parent.find('.Tosection').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ClassMasterId: drp.val(), ToSessionId: tosession }, success: function (response) {
                            var sectionList = response.section;
                            //debugger;
                            if (sectionList != null && sectionList != undefined) {
                                if (sectionList != null && sectionList.length > 0) {
                                    for (var i = 0; i < sectionList.length; i++) {
                                        $parent.find('.Tosection').append('<option value="' + sectionList[i].id + '">' + sectionList[i].name + '</option>');
                                    }
                                }
                            }
                        }
                    });
                }
            }

            if (drp.hasClass("CheckSessionIdforChangeClassFrom") && drp.attr('Id') == 'FromSessionId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //debugger;
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#FromSessionId").parents().eq(4);
                    $parent.find('.Fromclassmaster').empty();
                    $parent.find('.Fromclassmaster').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { FromSessionId: drp.val() }, success: function (response) {
                            var ClassList = response.fromclass;
                            //debugger;
                            if (ClassList != null && ClassList != undefined) {
                                if (ClassList != null && ClassList.length > 0) {
                                    for (var i = 0; i < ClassList.length; i++) {
                                        $parent.find('.Fromclassmaster').append('<option value="' + ClassList[i].id + '">' + ClassList[i].name + '</option>');
                                    }
                                }
                                else {
                                    alert("Warning! Class not found for Session(From).");
                                }
                            }
                        }
                    });
                }
            }

            if (drp.hasClass("CheckSessionIdforChangeClassTo") && drp.attr('Id') == 'ToSessionId') {
                if (drp.val() != undefined && drp.val() != null) {
                    //debugger;
                    var url = "/" + drp.data("controller") + "/" + drp.data("action");
                    var $parent = $("#ToSessionId").parents().eq(4);
                    $parent.find('.Toclassmaster').empty();
                    $parent.find('.Toclassmaster').append('<option value=""></option>');
                    $.ajax({
                        type: "POST", url: url, data: { ToSessionId: drp.val() }, success: function (response) {
                            var ClassList = response.toclass;
                            //debugger;
                            if (ClassList != null && ClassList != undefined) {
                                if (ClassList != null && ClassList.length > 0) {
                                    for (var i = 0; i < ClassList.length; i++) {
                                        $parent.find('.Toclassmaster').append('<option value="' + ClassList[i].id + '">' + ClassList[i].name + '</option>');
                                    }
                                }
                                else {
                                    alert("Warning! Class not found for Session(To).");
                                }
                            }
                        }
                    });
                }
            }

            if (drp.hasClass("attcmb")) {
                if (drp.val() != undefined && drp.val() != null) {
                    $("#studentAttendance > tbody > tr").each(function () {
                        var drpval = drp.val();
                        var parent = $(this);
                        var rowid = parent.find(".attone");
                        if (rowid.val() != undefined) {
                            rowid.val(drpval).trigger('change');
                        }
                    });
                }
            }


            if (drp.hasClass("atttwocmb")) {
                if (drp.val() != undefined && drp.val() != null) {
                    $("#studentAttendance > tbody > tr").each(function () {
                        var drpval = drp.val();
                        var parent = $(this);
                        var rowid = parent.find(".atttwo");
                        if (rowid.val() != undefined) {
                            rowid.val(drpval).trigger('change');
                        }
                    });
                }
            }




            //To check duplicate
            //if (drp.has("freeheadd")) {               
            //    var selectedId = drp;
            //    var serialnumber = $(this).closest('tr').find('.serialnumber').val();
            //    var dd = $(".freeheadd").each(function () {
            //        var serialnumber1 = $(this).closest('tr').find('.serialnumber').val();
            //        if ($(this).val() == selectedId.val() && serialnumber != serialnumber1) {
            //            alert("Selected");
            //           // drp.val("");
            //            //$('.select2-container').select2('val', '');
            //            //selectedId.index = -1;

            //        }
            //    });
            //}




            ////if (drp.has("subject") && drp.attr('Id') == 'ClassSubjectId') {
            ////    //debugger;
            ////    if (drp.val() != undefined && drp.val() != null) {
            ////        var classID = $("#ClassMasterId").val();
            ////        var sectionID = $("#sectionid").val();
            ////        debugger;
            ////        var url = "/StudentSubjectAssign/FillGridOnSubjectChangeID";
            ////        var $parent = $("#childs");

            ////        $.ajax({
            ////            type: "POST", url: url, data: { Id: drp.val(), classid: classID, sectionid: sectionID }, success: function (response) {
            ////                if (response != null && response != undefined) {
            ////                    $('#childs > tbody').html(response);
            ////                }

            ////            }
            ////        });
            ////    }
            ////}





        });


        $("select.readonly").select2('destroy')


        $('.datepicker').datepicker({
            autoclose: true,
            format: 'dd/mm/yyyy',
            disableTouchKeyboard: true
        }).on('changeDate', function (e) {
            if ($(this).hasClass("input-group")) {
                $(this).parent().find(":text").blur()
            }
        });



        $(document).on("change", '.Qty', function () {
            Stockcalculation($(this).closest('tr'));
        });
        $(document).on("change", '.Rate', function () {
            Stockcalculation($(this).closest('tr'));
        });
        $(document).on("change", '.CgstRate', function () {
            Stockcalculation($(this).closest('tr'));
        });
        $(document).on("change", '.SgstRate', function () {
            Stockcalculation($(this).closest('tr'));
        });
        $(document).on("change", '.DiscountP', function () {
            Stockcalculation($(this).closest('tr'));
        });




    });




var oSettingSwalConfim = { title: "Are you sure?", type: "warning", showCancelButton: true, confirmButtonColor: "#DD6B55", confirmButtonText: "Yes", cancelButtonText: "No", closeOnConfirm: true, closeOnCancel: true };


$(document).on('click', '#addrow', function () {
   /// debugger;
    var url = $(this).attr('data-url');
    var parentId = $(this).attr('data-parentId');
    url += "?id=" + parentId;
    if (url)
        addnewrow(url);
});

$(document).on('click', '.deleterow', function () {
    var ele = $(this);
    if (ele.hasClass('hasone') && $('.deleterow').length > 1) {
        swal(oSettingSwalConfim, function (isConfirm) {
            if (isConfirm) {
                $container = ele.parents("tr.item-row");
                $container.remove();
                setSerialNumber();

            }
        });
    }

    if (!ele.hasClass('hasone')) {
        swal(oSettingSwalConfim, function (isConfirm) {
            if (isConfirm) {
                $container = ele.parents("tr.item-row");
                $container.remove();
                setSerialNumber();

            }
        });
    }

    return false;
});

//debugger xyz;
$(document).on("change", '#RoundOff', function () {
    setRoundoff($(this));
});

$(document).on("change", '#DayId', function () {
    DaywiseTimeTable();
    $('#DayId').off('change');
});




function ClassStructru() {
    var url = "/ClassFeeStructure/Modify";
    var $parent = $("#childs");
    // showLoading();
    var ClassMasterId = $("#ClassMasterId").val();
    var InstallmentModeId = $("#InstallmentModeId").val();
    $.ajax({
        type: "POST", url: url, data: { cmid: ClassMasterId, insid: InstallmentModeId }, success: function (response) {
            if (response != null && response != undefined) {
                $('#childs > tbody').html(response);
                setSerialNumber();
            }

        }
    });
}

function DaywiseTimeTable() {
    var url = "/TimeTable/DayWiseTimeTable";
    var $parent = $("#childs");
    showLoading();
    var ClassMasterId = $("#ClassMasterId").val();
    var TimeTableId = $("#TimeTableId").val();
    var DayId = $("#DayId").val();
    $.ajax({
        type: "POST", url: url, data: { CMId: ClassMasterId, TimeTId: TimeTableId, DId: DayId }, success: function (response) {
            if (response != null && response != undefined) {
                $('#childs > tbody').html(response);
                setSerialNumber();
                hideLoading();
                window.datepickerIntialize();
            }

        }
    });
}


function FillNonScholasticSubSubject() {

    var url = "/NonScholasticSubSubjectMaster/Modify";
    var $parent = $("#childs");
    // showLoading();
    var ClassMasterId = $("#ClassMasterId").val();
    var NonScholasticSubjectMasterID = $("#NonScholasticSubjectMasterID").val();
    $.ajax({
        type: "POST", url: url, data: { cmid: ClassMasterId, insid: NonScholasticSubjectMasterID }, success: function (response) {
            if (response != null && response != undefined) {
                $('#childs > tbody').html(response);
                setSerialNumber();
            }

        }
    });
}

function FillNonScholasticGrade() {
   // debugger;
    var url = "/NonScholasticGradeMaster/Modify";
    var $parent = $("#childs");
    // showLoading();
    var ClassMasterId = $("#ClassMasterId").val();
    var NonScholasticSubjectMasterID = $("#SubjectId").val();
    var SubSubjectId = $("#SubSubjectId").val();
    $.ajax({
        type: "POST", url: url, data: { cmid: ClassMasterId, insid: NonScholasticSubjectMasterID, SubSubjectId: SubSubjectId }, success: function (response) {
            if (response != null && response != undefined) {
                $('#childs > tbody').html(response);
                setSerialNumber();
            }

        }
    });
}

function FeeCalculation(Duedate) {
    var TotalDepositamt = 0;
    var TotaldDiscountAmt = 0;

    if (Duedate != "") {
        $("#feestatus > tbody > tr").each(function () {
            var parent11 = $(this);
            var feechk1 = parent11.find(".feechk");
            feechk1.prop("checked", false);
        });
    }

    $("#childs > tbody > tr").each(function () {
        var parent = $(this);
        var drpDate = Duedate; //drp.val();
        // var FeesHeadId = parent.find(".FeesHeadId");

        var DepositAmount = parent.find(".DepositAmount");
        var DiscountAmount = parent.find(".DiscountAmount");
        var FeesHeadId = parent.find(".FeesHeadId");
        var damt = 0;
        var dDiscountAmt = 0;

        $("#feestatus > tbody > tr").each(function () {
            var parent1 = $(this);
            var FeesHeadIdStatus = parent1.find(".FeesHeadId");
            var instdate = parent1.find(".duedate");
            var DueAmount = parent1.find(".DueAmount");
            var DepositAmount = parent1.find(".DepositAmount");
            var DisAmount = parent1.find(".DiscountAmount");
            var feechk = parent1.find(".feechk");

            if (Duedate != "") {
                Duedate = Duedate.replace("-", "/").replace("-", "/");
                var d1 = new Date(Duedate).getTime();
                var c1 = instdate.val().replace("-", "/").replace("-", "/");
                var d2 = new Date(c1).getTime();

                if (FeesHeadIdStatus.val() == FeesHeadId.val() && d2 <= d1 && DueAmount.val() > 0) {
                    damt += parseFloat(DepositAmount.val());
                    dDiscountAmt += parseFloat(DisAmount.val());
                    feechk.prop("checked", true);
                }
            }
            else {
                if (FeesHeadIdStatus.val() == FeesHeadId.val() && feechk.prop('checked') == true) {
                    damt += parseFloat(DepositAmount.val());
                    dDiscountAmt += parseFloat(DisAmount.val());
                }
            }

        });


        if (damt > 0 || dDiscountAmt > 0) {
            DepositAmount.val(damt);
            DiscountAmount.val(dDiscountAmt);

            TotalDepositamt = TotalDepositamt + parseFloat(DepositAmount.val());
            TotaldDiscountAmt = TotaldDiscountAmt + parseFloat(DiscountAmount.val());

            damt = 0;
            dDiscountAmt = 0;

        }
        else {
            DepositAmount.val('0');
            DiscountAmount.val('0');

        }
    });

    $('#DepoistedAmt').val(TotalDepositamt);
    $("#GTotalDiscount").val(TotaldDiscountAmt);
    $('#GrandTotalDeposite').val(TotalDepositamt);

}


function addnewrow(url) {
    //debugger;
    showLoading();
    //$.ajax({ url: url }).success(function (response) {
    //    $('#childs > tbody').append(response);
    //    $("form").removeData("validator");
    //    $("form").removeData("unobtrusiveValidation");
    //    $.validator.unobtrusive.parse("form");
    //    setSerialNumber();
    //    hideLoading();
    //    window.datepickerIntialize();
    //});

    $.ajax({
        type: "POST", url: url, success: function (response) {
            $('#childs > tbody').append(response);
            $("form").removeData("validator");
            $("form").removeData("unobtrusiveValidation");
            $.validator.unobtrusive.parse("form");
            setSerialNumber();
            hideLoading();
            window.datepickerIntialize();
        }
    });


}







function setSerialNumber() {
    var i = 1;
    $("#childs > tbody > tr").each(function () {
        var parent = $(this);
        var serialnumber = parent.find(".serialnumber");
        if (serialnumber.val() != undefined) {
            serialnumber.val(i);
            i++;
        }
    })
}


function setSerialNumberAnyTable(tId) {
    var i = 1;
    $(tId + " > tr").each(function () {
        var parent = $(this);
        var serialnumber = parent.find(".serialnumber");
        if (serialnumber.val() != undefined) {
            serialnumber.val(i);
            i++;
        }
    })
}

function SetBillTotal() {
    // debugger;
    var i = 1;
    var Discount = 0;
    var SubTotal = 0;
    var TotCgst = 0;
    var TotSgst = 0;
    var NetAmount = 0;

    var a = 0, b = 0, c = 0, d = 0, e = 0, rndAmount = 0;

    var parent = $(this);
    $("#childs > tbody > tr").each(function () {
        var parent = $(this);
        var GtotalAmt = parent.find(".Gtotal");
        var SubtotalAmount = parent.find(".SubTotalAmt");
        var CGSTAmount = parent.find(".CGSTAmount");
        var SGSTAmount = parent.find(".SGSTAmount");
        var DiscountAmount = parent.find(".DiscountAmt");

        if (SubtotalAmount.val() == undefined || SubtotalAmount.val().length <= 0 || isNaN(SubtotalAmount.val())) {
            SubtotalAmount.val('0.00');
        }
        if (CGSTAmount.val() == undefined || CGSTAmount.val().length <= 0 || isNaN(CGSTAmount.val())) {
            CGSTAmount.val('0.00');
        }
        if (SGSTAmount.val() == undefined || SGSTAmount.val().length <= 0 || isNaN(SGSTAmount.val())) {
            SGSTAmount.val('0.00');
        }
        if (GtotalAmt.val() == undefined || GtotalAmt.val().length <= 0 || isNaN(GtotalAmt.val())) {
            GtotalAmt.val('0.00');
        }
        if (DiscountAmount.val() == undefined || DiscountAmount.val().length <= 0 || isNaN(DiscountAmount.val())) {
            DiscountAmount.val('0.00');
        }

        if (GtotalAmt.val() != undefined) { a = GtotalAmt.val() == undefined ? 0 : GtotalAmt.val(); }

        b = CGSTAmount.val() == undefined ? 0 : CGSTAmount.val();
        c = SGSTAmount.val() == undefined ? 0 : SGSTAmount.val();
        d = SubtotalAmount.val() == undefined ? 0 : SubtotalAmount.val();
        e = DiscountAmount.val() == undefined ? 0 : DiscountAmount.val();


        Discount = Discount + parseFloat(e);
        SubTotal = SubTotal + parseFloat(d);
        NetAmount = NetAmount + parseFloat(a);
        TotCgst = TotCgst + parseFloat(b);
        TotSgst = TotSgst + parseFloat(c);
        rndAmount = parseFloat(NetAmount.toFixed(2)) - parseFloat(NetAmount.toFixed(0));
        // Amount = parseFloat(a) - (parseFloat(b) + parseFloat(c));

    })

    var parent1 = $(this);
    // var tmt = $("#childs > tfoot > tr").find(".NetAmount");
    //  $tmt.val(NetAmount);
    //$('#SubTotal').text(SubTotal.toFixed(2));
    //$('#CGSTL').text(TotCgst.toFixed(2));
    //$('#SGSTL').text(TotSgst.toFixed(2));
    //$('#NetAmount').text(NetAmount.toFixed(2));
    // debugger;
    $('#SubTotal').val(SubTotal.toFixed(2));
    $('#DISCO').val(Discount.toFixed(2));
    $('#CGSTL').val(TotCgst.toFixed(2));
    $('#SGSTL').val(TotSgst.toFixed(2));
    $('#RoundOff').val((parseFloat(NetAmount.toFixed(0)) - parseFloat(NetAmount.toFixed(2))).toFixed(2));
    $('#NetAmount').val(NetAmount.toFixed(0));

}

function setRoundoff(parent) {
    //debugger;
    var amt = 0;
    var rndAmt = 0;
    var ntAmt = 0;

    rndAmt = parseFloat($('#RoundOff').val()) + parseFloat($('#SubTotal').val()) + parseFloat($('#CGSTL').val()) + parseFloat($('#SGSTL').val());
    // ntAmt = $('#NetAmount').val();
    amt = rndAmt.toFixed(2);
    if ($('#RoundOff').val() == "")
        SetBillTotal();
    else
        $('#NetAmount').val(parseFloat(amt).toFixed(2));


}


function CheckRowValue(tblName, chkValue, classname) {
    //this function is used to chech duplicate value in list
    var cnt = 0;
    if (chkValue != "") {
        $(tblName).each(function () {
            var parent11 = $(this);
            var NchkValue = parent11.find(classname);
            if (NchkValue.val() == chkValue) {
                cnt = cnt + 1;
            }
        });
    }
    return cnt;
}


function Stockcalculation(parent) {
    // debugger;
    var itemid = parent.find(".groupitem");
    var quantity = parent.find(".Qty");
    var Rate = parent.find(".Rate");
    var cgstrate = parent.find(".CgstRate");
    var sgstrate = parent.find(".SgstRate");
    var DiscountPer = parent.find(".DiscountP");
    var DiscountAmount = parent.find(".DiscountAmt");
    var CGSTAmount = parent.find(".CGSTAmount");
    var SGSTAmount = parent.find(".SGSTAmount");
    var SubTotal = parent.find(".SubTotalAmt");
    var Gtotal = parent.find(".Gtotal");

    var iRate = 0, icgstrate = 0, isgstrate = 0, iCGSTAmount = 0, iSGSTAmount = 0, iSubTotal = 0, iGtotal = 0, tValue = 0, iDiscountRate = 0, iDiscountAmt = 0;
    var qty = 1;


    if (itemid.val() == "") {
        Rate.val("0.00")
        cgstrate.val("0.00")
        sgstrate.val("0.00")
        CGSTAmount.val("0.00");
        SGSTAmount.val("0.00");
        DiscountPer.val("0.00");
        iDiscountAmt.val("0.00");
        Gtotal.val("0.00");
    }

    if (Rate.val() == undefined || Rate.val().length <= 0 || isNaN(Rate.val())) {
        Rate.val('0.00');
    }
    if (DiscountPer.val() == undefined || DiscountPer.val().length <= 0 || isNaN(DiscountPer.val())) {
        DiscountPer.val('0.00');
    }
    if (DiscountAmount.val() == undefined || DiscountAmount.val().length <= 0 || isNaN(DiscountAmount.val())) {
        DiscountAmount.val('0.00');
    }
    if (cgstrate.val() == undefined || cgstrate.val().length <= 0 || isNaN(cgstrate.val())) {
        cgstrate.val('0.00');
    }
    if (sgstrate.val() == undefined || sgstrate.val().length <= 0 || isNaN(sgstrate.val())) {
        sgstrate.val('0.00');
    }
    if (CGSTAmount.val() == undefined || CGSTAmount.val().length <= 0 || isNaN(CGSTAmount.val())) {
        CGSTAmount.val('0.00');
    }
    if (SGSTAmount.val() == undefined || SGSTAmount.val().length <= 0 || isNaN(SGSTAmount.val())) {
        SGSTAmount.val('0.00');
    }
    if (Gtotal.val() == undefined || Gtotal.val().length <= 0 || isNaN(Gtotal.val())) {
        Gtotal.val('0.00');
    }

    iRate = Rate.val() == undefined ? 0 : Rate.val();
    iDiscountRate = DiscountPer.val() == undefined ? 0 : DiscountPer.val();
    iDiscountAmt = DiscountAmount.val() == undefined ? 0 : DiscountAmount.val();
    icgstrate = cgstrate.val() == undefined ? 0 : cgstrate.val();
    isgstrate = sgstrate.val() == undefined ? 0 : sgstrate.val();
    iCGSTAmount = CGSTAmount.val() == undefined ? 0 : CGSTAmount.val();
    iSGSTAmount = SGSTAmount.val() == undefined ? 0 : SGSTAmount.val();
    iSubTotal = SubTotal.val() == undefined ? 0 : SubTotal.val();
    iGtotal = Gtotal.val() == undefined ? 0 : Gtotal.val();

    if (quantity.val() == undefined || isNaN(quantity.val())) {
        quantity.val('1');
    }

    qty = quantity.val() != undefined && quantity.val().length > 0 ? parseFloat(quantity.val()) : qty;
    qty = qty == 0 ? 1 : qty; // if input qty 0 then always 1
    // debugger;
    if (Rate.val() != undefined) {
        tValue = Rate.val().length > 0 ? parseFloat(Rate.val()) : tValue;
        tValue = tValue * qty;
        if (DiscountPer.val() != undefined) {
            iDiscountAmt = tValue * (parseFloat(iDiscountRate) / 100);
        }
        //  iSubTotal = (tValue - iDiscountAmt).toFixed(2);
        iSubTotal = (tValue).toFixed(2);
        tValue = tValue - iDiscountAmt;
    }
    SubTotal.val(iSubTotal);
    Gtotal.val(tValue);

    //debugger;
    iCGSTAmount = tValue * (parseFloat(icgstrate) / 100);
    iSGSTAmount = tValue * (parseFloat(isgstrate) / 100);


    DiscountAmount.val(parseFloat(iDiscountAmt).toFixed(2))
    CGSTAmount.val(parseFloat(iCGSTAmount).toFixed(2))
    SGSTAmount.val(parseFloat(iSGSTAmount).toFixed(2))

    Gtotal.val((parseFloat(tValue) + parseFloat(iCGSTAmount) + parseFloat(iSGSTAmount)).toFixed(2));

    SetBillTotal();

}

function commonCalculation(parent) {
    //alert(parent.find(".qty").val());
    //alert(parent.find(".rate").val(20));
    //var igstrate = parent.find(".igstrate");
    //var cgstrate = parent.find(".cgstrate");
    //var sgstrate = parent.find(".sgstrate");
    //var cessigstrate = parent.find(".cessigstrate");
    //var cesscgstrate = parent.find(".cesscgstrate");

    //var igstamount = parent.find(".igstamount");
    //var cgstamount = parent.find(".cgstamount");
    //var sgstamount = parent.find(".sgstamount");
    //var cessigstamount = parent.find(".cessigstamount");
    //var cesscgstamount = parent.find(".cesscgstamount");

    //var pricevalue = parent.find(".pricevalue");

    //var quantity = parent.find(".quantity");
    //var discount = parent.find(".discount");
    //var netamount = parent.find(".netamount");
    //var amount = parent.find(".amount");
    //var othercharge = parent.find(".othercharge");

    //if (amount.prop("readonly") && !amount.hasClass('validate')) {
    //    amount.addClass('validate');
    //}

    //var isexempted = parent.find(".isexempted");
    //var isnongst = parent.find(".isnongst");
    //var isnilrated = parent.find(".isnilrated");
    //var itemid = parent.find(".itemid");

    //var noTaxApplicable = $(".no-taxapplicable").val() != undefined && $(".no-taxapplicable").val().toLowerCase() == "true" ? true : false;
    //var isreversecharge = $(".isreversecharge");
    //var formtype = $("#formtype").length > 0 ? $("#formtype").val() == "purchaseadvancepayment" ? true : false : false;
    //var iscompositiondealer = $(".iscompositiondealer").length > 0 ? $(".iscompositiondealer").prop("checked") : false;
    //// if sale and isreversecharge is checked then no tax applied
    //if ($(".requesttype").val() == "Sale") {
    //    noTaxApplicable = isreversecharge.val() != undefined ? isreversecharge.prop("checked") ? true : noTaxApplicable : noTaxApplicable;
    //}
    //// if pruchase and isreversecharge is checked then tax applied
    //else {
    //    noTaxApplicable = isreversecharge.val() != undefined ? isreversecharge.prop("checked") ? iscompositiondealer : formtype ? true : noTaxApplicable : noTaxApplicable;
    //}

    //var iRate = 0, cRate = 0, sRate = 0, csiRate = 0, cscRate = 0, iAmount = 0, cAmount = 0, sAmount = 0, csiAmount = 0, cscAmount = 0, tValue = 0, rCharge = 0; //iReverse = 0, cReverse = 0, sReverse = 0;
    //var qty = 1;

    //var isreverse = (isreversecharge.val() != undefined ? isreversecharge.prop("checked") : false);
    //if (itemid.val() == "" || isexempted.val() == true || isnongst.val() == true || isnilrated.val() == true || noTaxApplicable == true) {
    //    if (isreverse == false || iscompositiondealer) {
    //        igstamount.val("0.00")
    //        cgstamount.val("0.00")
    //        sgstamount.val("0.00")
    //        cessigstamount.val("0.00");
    //        cesscgstamount.val("0.00");
    //        igstrate.val("0.00");
    //        cgstrate.val("0.00");
    //        sgstrate.val("0.00");
    //        cessigstrate.val("0.00");
    //        cesscgstrate.val("0.00");
    //    }
    //}
    //if (igstrate.val() == undefined || igstrate.val().length <= 0 || isNaN(igstrate.val())) {
    //    igstrate.val('0.00');
    //}

    //if (cgstrate.val() == undefined || cgstrate.val().length <= 0 || isNaN(cgstrate.val())) {
    //    cgstrate.val('0.00');
    //}
    //if (sgstrate.val() == undefined || sgstrate.val().length <= 0 || isNaN(sgstrate.val())) {
    //    sgstrate.val('0.00');
    //}
    //if (cessigstrate.val() == undefined || cessigstrate.val().length <= 0 || isNaN(cessigstrate.val())) {
    //    cessigstrate.val('0.00');
    //}
    //if (cesscgstrate.val() == undefined || cesscgstrate.val().length <= 0 || isNaN(cesscgstrate.val())) {
    //    cesscgstrate.val('0.00');
    //}

    //iRate = igstrate.val() == undefined ? 0 : igstrate.val();
    //cRate = cgstrate.val() == undefined ? 0 : cgstrate.val();
    //sRate = sgstrate.val() == undefined ? 0 : sgstrate.val();
    //csiRate = cessigstrate.val() == undefined ? 0 : cessigstrate.val();
    //cscRate = cesscgstrate.val() == undefined ? 0 : cesscgstrate.val();
    //if (pricevalue.val() != undefined && pricevalue.val().length <= 0 || isNaN(pricevalue.val())) {
    //    pricevalue.val('0.00');
    //}

    //if (quantity.val() == undefined || isNaN(quantity.val())) {
    //    quantity.val('1');
    //}
    //if (isNaN(discount.val()) || discount.val().length <= 0) {
    //    discount.val('0');
    //}

    //qty = quantity.val() != undefined && quantity.val().length > 0 ? parseFloat(quantity.val()) : qty;

    //qty = qty == 0 ? 1 : qty; // if input qty 0 then always 1

    //if (pricevalue.val() != undefined) {
    //    tValue = pricevalue.val().length > 0 ? parseFloat(pricevalue.val()) : tValue;
    //    tValue = tValue * qty;
    //}

    //var variable = $('.isdiscountinpercent');
    //if (variable.val() != undefined && variable.prop('checked') == true) {
    //    tValue = tValue - ((tValue * parseFloat(discount.val())) / 100);
    //}
    //else {
    //    if (discount.val() != undefined && !isNaN(discount.val())) {
    //        tValue = tValue - parseFloat(discount.val());
    //    }
    //}
    //if ($('.pricevalue').length == 0) {
    //    tValue = 0;
    //    if (parent.find(".amount")) {
    //        if (parent.find(".amount").val().length <= 0) {
    //            parent.find(".amount").val('0');
    //        }
    //        tValue = parent.find(".amount").val();
    //    }
    //}

    //amount.val(tValue);

    //if (othercharge.length > 0) {
    //    tValue = tValue + parseFloat(othercharge.val().length > 0 ? othercharge.val() : 0);
    //}

    //var netAmtWithInludingTaxMode = tValue;
    //////  for Exclude Taxes : 1
    //////  for Include Taxes : 2

    //if ((!isreverse && $(".requesttype").val() == "Sale") || (isreverse && $(".requesttype").val() != "Sale" && formtype) || ($(".requesttype").val() != "Sale" && !formtype)) {
    //    var taxmode = $('.taxmode').val();
    //    if (taxmode != undefined || taxmode != null) {
    //        if (parseInt(taxmode) == 2) {
    //            var taxrate = parseFloat(iRate) + parseFloat(cRate) + parseFloat(sRate) + parseFloat(csiRate) + parseFloat(cscRate);

    //            tValue = ((tValue / (100 + taxrate)) * 100);
    //        }
    //    }
    //    iAmount = tValue * (parseFloat(iRate) / 100);
    //    cAmount = tValue * (parseFloat(cRate) / 100);
    //    sAmount = tValue * (parseFloat(sRate) / 100);
    //    csiAmount = tValue * (parseFloat(csiRate) / 100);
    //    cscAmount = tValue * (parseFloat(cscRate) / 100);

    //    igstamount.val(parseFloat(iAmount).toFixed(2))
    //    cgstamount.val(parseFloat(cAmount).toFixed(2))
    //    sgstamount.val(parseFloat(sAmount).toFixed(2))
    //    cessigstamount.val(parseFloat(csiAmount).toFixed(2))
    //    cesscgstamount.val(parseFloat(cscAmount).toFixed(2))
    //}
    //else {
    //    igstamount.val("0.00");
    //    cgstamount.val("0.00");
    //    sgstamount.val("0.00");
    //    cessigstamount.val("0.00");
    //    cesscgstamount.val("0.00");
    //}
    //if ($('.pricevalue').length == 0) {
    //    netamount.val((parseFloat(tValue) + parseFloat(iAmount) + parseFloat(cAmount) + parseFloat(sAmount) + parseFloat(csiAmount) + parseFloat(cscAmount)).toFixed(2));
    //}
    //else {
    //    netamount.val(parseFloat(tValue + iAmount + cAmount + sAmount + csiAmount + cscAmount).toFixed(2));
    //}
    //if (taxmode != undefined || taxmode != null) {
    //    if (parseInt(taxmode) == 2) {
    //        netamount.val(parseFloat(netAmtWithInludingTaxMode).toFixed(2));
    //    }
    //}
    //setTotalAmount();
}

var showLoading = function (setting) {
    setting = jQuery.extend({ Text: 'Please Wait...', Effect: 'ios', background: 'rgba(160, 160, 160, 0.48)', ColorCode: '#000', SizeW: '', SizeH: '', dvContent: 'dvWaitMe' }, setting);
    //debugger;
    var $container = $('#' + setting.dvContent);
    if ($container.length) {
        //clear if already opened.
        $container.removeAttr('class').hide().children().remove();
        $container.css({
            'width': '100%',
            'height': '100%',
            'position': 'fixed',
            'top': '0',
            'left': '0',
            'z-index': '99999',
            'display': 'none'
        });
        $('body').addClass('ajax-waitme');
        $container.waitMe({
            effect: setting.Effect,
            text: setting.Text,
            bg: setting.background,
            color: setting.ColorCode,
            sizeW: setting.SizeW,
            sizeH: setting.SizeH
        });
        $container.show();
    }
};

var hideLoading = function (setting) {
    setting = jQuery.extend({ dvContent: 'dvWaitMe' }, setting);
    var $container = $('#' + setting.dvContent);
    $container.removeAttr('class').hide().children().remove();
    $('body').removeClass('ajax-waitme');
};

function sortTable(n, tableId) {
    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
    table = document.getElementById(tableId);
    switching = true;
    // Set the sorting direction to ascending:
    dir = "asc";
    /* Make a loop that will continue until
    no switching has been done: */
    while (switching) {
        // Start by saying: no switching is done:
        switching = false;
        rows = table.rows;
        /* Loop through all table rows (except the
        first, which contains table headers): */
        for (i = 1; i < (rows.length - 1); i++) {
            // Start by saying there should be no switching:
            shouldSwitch = false;
            /* Get the two elements you want to compare,
            one from current row and one from the next: */
            x = rows[i].getElementsByTagName("TD")[n];
            y = rows[i + 1].getElementsByTagName("TD")[n];
            /* Check if the two rows should switch place,
            based on the direction, asc or desc: */
            if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                    // If so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                    // If so, mark as a switch and break the loop:
                    shouldSwitch = true;
                    break;
                }
            }
        }
        if (shouldSwitch) {
            /* If a switch has been marked, make the switch
            and mark that a switch has been done: */
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            // Each time a switch is done, increase this count by 1:
            switchcount++;
        } else {
            /* If no switching has been done AND the direction is "asc",
            set the direction to "desc" and run the while loop again. */
            if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
            }
        }
    }
}
//$('.datepicker').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
//$('.datepicker').datepicker({
//    autoclose: true,
//    format: "dd/mm/yyyy"
//});