﻿(function ($) {
    function BookRecords() {
        var $this = this, form;

        function initilizeModel() {

            $("#modal-add-edit-bill").on('loaded.bs.modal', function (e) {
                form = new Global.FormHelper($("#modal-add-edit-bill-form form"), { updateTargetId: "validation-summary" }, null, function (jqXHR, status, error) {
                    form.find("#validation-summary").html(JSON.parse(jqXHR.responseText).value.data);
                });

                form.find('#btn-submit').click(function () {

                    if (form.valid()) {
                        var id = form.find("#Id").val();
                        var instituteid = form.find("#InstituteId").val();
                        var branchid = form.find("#BranchId").val();
                        var createdate = form.find("#CreateDate").val();
                        var createid = form.find("#CreateId").val();
                        var orderno = form.find("#OrderNo").val();
                        var billdetailid = form.find("#BillDetailId").val();
                        var booknostartfrom = form.find("#BookNoStartFrom").val();
                        var booktitle = form.find("#BookTitle").val();
                        var alttitle = form.find("#AltTitle").val();
                        var collation = form.find("#Collation").val();
                        var corp = form.find("#Corp").val();
                        var edition = form.find("#Edition").val();
                        var isbn = form.find("#Isbn").val();
                        var lccno = form.find("#Lccno").val();
                        var mediumId = form.find("#MediumId").val();
                        var publishyear = form.find("#PublishYear").val();
                        var publishermasterid = form.find("#PublisherMasterId").val();
                        var bookcatmasterid = form.find("#BookCatMasterId").val();
                        var authermasterid = form.find("#AutherMasterId").val();
                        var almirahmasterid = form.find("#AlmirahMasterId").val();
                        var rackmasterId = form.find("#RackMasterId").val();
                        var qty = form.find("#Qty").val();
                        var price = form.find("#Price").val();
                        var totalamount = form.find("#TotalAmount").val();
                        var guid = $("#childs tbody tr").length;//Global.GenerateGuid();

                        var $table = $("#childs");

                        $("#childs tr").each(function () {
                            //debugger;
                            var trId = $(this).attr("id");
                            if (trId !== "" && trId !== undefined) {
                                if (trId === id) {
                                    $(this).remove();
                                }
                            }
                        });

                        $('<tr/>', {
                            'class': 'item-row',
                            'id': id,
                            html: function () {
                                $('<input/>', {
                                    'type': 'hidden',
                                    'name': 'BookRecords[' + guid + '].index',
                                    'value': guid
                                }).appendTo(this);

                                $('<td/>', {
                                    html: function () {
                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Id',
                                            'value': id
                                        }).appendTo(this);
                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].InstituteId',
                                            'value': instituteid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].BranchId',
                                            'value': branchid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].CreateDate',
                                            'value': createdate
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].CreateId',
                                            'value': createid
                                        }).appendTo(this);


                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].OrderNo',
                                            'value': orderno
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].BillDetailId',
                                            'value': billdetailid
                                        }).appendTo(this);
                                                          
                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].AltTitle',
                                            'value': alttitle
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].MediumId',
                                            'value': mediumId
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Collation',
                                            'value': collation
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Corp',
                                            'value': corp
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Edition',
                                            'value': edition
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Isbn',
                                            'value': isbn
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].Lccno',
                                            'value': lccno
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].PublishYear',
                                            'value': publishyear
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].PublisherMasterId',
                                            'value': publishermasterid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].BookCatMasterId',
                                            'value': bookcatmasterid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].AutherMasterId',
                                            'value': authermasterid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].AlmirahMasterId',
                                            'value': almirahmasterid
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'hidden',
                                            'name': 'BookRecords[' + guid + '].RackMasterId',
                                            'value': rackmasterId
                                        }).appendTo(this);

                                        $('<input/>', {
                                            'type': 'text',
                                            'class': 'form-control',
                                            'readonly': 'readonly',
                                            'style': { 'width': '100%' },
                                            'name': 'BookRecords[' + guid + '].BookNoStartFrom',
                                            'value': booknostartfrom
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);

                                $('<td/>', {
                                    html: function () {
                                        $('<input/>', {
                                            'type': 'text',
                                            'class': 'form-control',
                                            'readonly': 'readonly',
                                            'style': { 'width': '100%' },
                                            'name': 'BookRecords[' + guid + '].BookTitle',
                                            'value': booktitle
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);

                                $('<td/>', {
                                    html: function () {
                                        $('<input/>', {
                                            'type': 'text',
                                            'class': 'form-control',
                                            'readonly': 'readonly',
                                            'style': { 'width': '100%' },
                                            'name': 'BookRecords[' + guid + '].Qty',
                                            'value': qty
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);

                                $('<td/>', {
                                    html: function () {
                                        $('<input/>', {
                                            'type': 'text',
                                            'class': 'form-control',
                                            'readonly': 'readonly',
                                            'style': { 'width': '100%' },
                                            'name': 'BookRecords[' + guid + '].Price',
                                            'value': price
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);

                                $('<td/>', {
                                    html: function () {
                                        $('<input/>', {
                                            'type': 'text',
                                            'class': 'form-control',
                                            'readonly': 'readonly',
                                            'style': { 'width': '100%' },
                                            'name': 'BookRecords[' + guid + '].TotalAmount',
                                            'value': qty * price
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);

                                $('<td/>', {
                                    'valign': 'middle',
                                    'align': 'center',
                                    html: function () {
                                        $('<a/>', {
                                            'title': 'Edit',
                                            'data-id': guid,
                                            'class': 'badge btn-sm bg-yellow-gradient edit',
                                            'href': 'javascript:void(0);',
                                            html: function () {
                                                $('<i/>', {
                                                    'class': 'fa fa-pencil'
                                                }).appendTo(this);
                                            }
                                        }).appendTo(this);

                                        $('<a/>', {
                                            'title': 'Delete',
                                            'data-id': guid,
                                            'class': 'badge btn-sm bg-red-gradient delete',
                                            'href': 'javascript:void(0);',
                                            html: function () {
                                                $('<i/>', {
                                                    'class': 'fa fa-trash-o'
                                                }).appendTo(this);
                                            }
                                        }).appendTo(this);
                                    }
                                }).appendTo(this);
                            }
                        }).appendTo($table);


                        $("#modal-add-edit-bill").modal('hide').data('bs.modal', null);
                        return false;
                    }

                });

            }).on('hidden.bs.modal', function (e) {
                $(this).removeData('bs.modal');
            });
        }

        $this.init = function () {
            initilizeModel();
        }
    }

    $(function () {
        var self = new BookRecords();
        self.init();
    });
})(jQuery)