﻿/*global window, $*/
var Global = {};
Global.FormHelper = function (formElement, options, onSucccess, onError) {
    //"use strict";
    var settings = {};
    settings = $.extend({}, settings, options);
    $.validator.unobtrusive.parse(formElement);
    formElement.validate(settings.validateSettings);

    formElement.submit(function (e) {

        var submitBtn = formElement.find(':submit');
        if (formElement.validate().valid()) {
            Global.ShowLoading();
            $.ajax(formElement.attr("action"), {
                type: "POST",
                data: formElement.serializeArray(),
                beforeSend: function (xhr) {
                    $(':input[type="submit"]').prop('disabled', true);
                },
                success: function (result) {
                    if (onSucccess === null || onSucccess === undefined) {
                        if (result.isSuccess) {

                            window.location.href = result.redirectUrl;
                        } else {

                            if (settings.updateTargetId) {
                                if (result.data == undefined) {
                                    formElement.find("#" + settings.updateTargetId).html("<span>" + result + "</span>");
                                }
                                else {
                                    formElement.find("#" + settings.updateTargetId).html("<span>" + result.data + "</span>");
                                }
                            }
                        }
                    } else {

                        onSucccess(result);
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                    }
                    Global.HideLoading();
                    $(':input[type="submit"]').prop('disabled', false);
                }, complete: function () {
                    Global.HideLoading();
                    $(':input[type="submit"]').prop('disabled', false);
                }
            });
        }
        e.preventDefault();
    });

    return formElement;
};

Global.FormHelperWithFiles = function (formElement, options, onSucccess, onError, loadingElementId, onComplete) {
    "use strict";
    var settings = {};

    settings = $.extend({}, settings, options);
    formElement.validate(settings.validateSettings);
    formElement.submit(function (e) {

        var formdata = new FormData();
        formElement.find('input[type="file"]').each(function () {
            
            var elem = document.getElementById($(this).attr('id'));
            if (elem != undefined &&elem.files != undefined && elem.files.length > 0) {
                for (var i = 0; i < elem.files.length; i++) {
                    var file = elem.files[i];
                    formdata.append($(this).attr('name'), file);
                }
            }
        });

        $.each(formElement.serializeArray(), function (i, item) {
            formdata.append(item.name, item.value);
        });


        var submitBtn = formElement.find('#btn-submit');
        if (formElement.validate().valid()) {
            Global.ShowLoading();
            submitBtn.find('i').removeClass("fa fa-arrow-circle-right");
            submitBtn.find('i').addClass("fa fa-refresh");
            submitBtn.prop('disabled', true);
            submitBtn.find('span').html('Submiting..');
            $.ajax(formElement.attr("action"), {
                type: "POST",
                data: formdata,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    if (settings.loadingElementId != null || settings.loadingElementId != undefined) {
                        $("#" + settings.loadingElementId).show();
                        submitBtn.hide();
                    }
                },
                success: function (result) {
                    if (onSucccess === null || onSucccess === undefined) {
                        if (result.isSuccess) {
                            $(window).unbind('beforeunload');
                            window.location.href = result.redirectUrl;
                        } else {
                            if (settings.updateTargetId) {
                                var datatresult = (result.message == null || result.message == undefined) ? ((result.data == null || result.data == undefined) ? result : result.data) : result.message;
                                $("#" + settings.updateTargetId).html(datatresult);
                            }
                        }
                    } else {
                        onSucccess(result);
                    }
                },
                error: function (jqXHR, status, error) {
                    if (onError !== null && onError !== undefined) {
                        onError(jqXHR, status, error);
                        Global.HideLoading();
                    }
                },
                complete: function (result) {
                    if (onComplete === null || onComplete === undefined) {
                        if (settings.loadingElementId != null || settings.loadingElementId != undefined) {
                            $("#" + settings.loadingElementId).hide();
                        }
                        submitBtn.find('i').removeClass("fa fa-refresh");
                        submitBtn.find('i').addClass("fa fa-arrow-circle-right");
                        submitBtn.find('span').html('Submit');
                        submitBtn.prop('disabled', false);
                    } else {
                        onComplete(result);
                    }
                }
            });
        }

        e.preventDefault();
    });

    return formElement;
};

Global.GridHelper = function (gridElement, options) {
    if ($(gridElement).find("thead tr th").length > 1) {
        var settings = {};
        settings = $.extend({}, settings, options);
        $(gridElement).dataTable(settings);
        return $(gridElement);
    }
};

Global.FormValidationReset = function (formElement, validateOption) {
    if ($(formElement).data('validator')) {
        $(formElement).data('validator', null);
    }

    $(formElement).validate(validateOption);
    return $(formElement);
};

Global.DateProcess = function process(date) {
    var parts = date.split("/");
    return new Date(parts[2], parts[1] - 1, parts[0]);
}

Date.prototype.isSameDateAs = function (pDate) {
    return (
        this.getFullYear() === pDate.getFullYear() &&
        this.getMonth() === pDate.getMonth() &&
        this.getDate() === pDate.getDate()
    );
}

Global.ShowLoading = function (setting) {
    setting = jQuery.extend({ Text: 'Please Wait...', Effect: 'ios', background: 'rgba(160, 160, 160, 0.48)', ColorCode: '#000', SizeW: '', SizeH: '', dvContent: 'dvWaitMe' }, setting);

    var $container = $('#' + setting.dvContent);
    if ($container.length) {
        //clear if already opened.
        $container.removeAttr('class').hide().children().remove();
        $container.css({
            'width': '100%',
            'height': '100%',
            'position': 'fixed',
            'top': '0',
            'left': '0',
            'z-index': '99999',
            'display': 'none'
        });
        $('body').addClass('ajax-waitme');
        $container.waitMe({
            effect: setting.Effect,
            text: setting.Text,
            bg: setting.background,
            color: setting.ColorCode,
            sizeW: setting.SizeW,
            sizeH: setting.SizeH
        });
        $container.show();
    }
};

Global.HideLoading = function (setting) {
    setting = jQuery.extend({ dvContent: 'dvWaitMe' }, setting);
    var $container = $('#' + setting.dvContent);
    $container.removeAttr('class').hide().children().remove();
    $('body').removeClass('ajax-waitme');
};

Global.ShowSucessMessage = function (message) {
    var $html = '<div class="alert alert-success alert-dismissable">' +
        '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + message + '</div>';
    $("#notificationMessage").html($html);
}

Global.ShowErrorMessage = function (message) {
    var $html = '<div class="alert alert-danger alert-dismissable">' +
        '<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>' + message + '</div>';
    $("#notificationMessage").html($html);
}

Global.GenerateGuid = function () {
    var d = new Date().getTime();
    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
};

Global.Print = function (html, title) {
    var mywindow = window.open('', 'new div', 'height=400,width=600');
    mywindow.document.write('<html><head><title>' + title + '</title>');
    mywindow.document.write('</head><body >');
    mywindow.document.writeln(html);
    mywindow.document.write('</body></html>');
    mywindow.print();
    mywindow.close();
    return true;
};

Global.Pdf = function (html) {
    var pdfForm = $('#pdfForm');
    pdfForm.find("input[name='htmlContent']").val(html);
    pdfForm.submit();
};

$(document).on('keypress', '.number', function (event) {
    //Added by arnav
    if ((event.which < 48 || event.which > 57) && event.which != 8 && event.which != 0) {
        event.preventDefault();
    }
});

/*Arnav*/
$(document).on('keypress', '.decimal', function (event) {
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which < 48 || event.which > 57) && event.which != 8 && event.which != 0) {
        event.preventDefault();
    }
});

$(document).on('keypress', '.decimalNegative', function (event) {
    if ((event.which != 46 || $(this).val().indexOf('.') != -1) && (event.which != 45 || $(this).val().indexOf('-') != -1) && (event.which < 48 || event.which > 57) && event.which != 8 && event.which != 0) {
        event.preventDefault();
    }
});

$(document).on('change', '.number, .decimal, .decimalNegative', function () { if ($(this).val() != "0" && $(this).val() != "" && !$.isNumeric($(this).val())) { alert("Please enter a valid value"); return false; } });

$(document).on('focus', '.number, .decimal, .decimalNegative', function (event) {
    var default_value = 0;
    if ($(this).val() == default_value) $(this).val("");
});

$(document).on('blur', '.number, .decimal, .decimalNegative', function (event) {
    var default_value = 0;
    if ($(this).val().length == 0) $(this).val(default_value);
});

$(document).on('bind', '.disablecopy', function (e) {
    e.preventDefault();
});

$(document).on('cut copy paste', '.disablecopy', function (e) {
    e.preventDefault();
});

$(".disableRightClick").on("contextmenu", function (e) {
    return false;
});

