﻿var host = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');


var ajaxLoader = function (tableId) {
    $('#' + tableId).parent().append('<div id="' + tableId + '_loading_overlay" class="loading-overlay active zindex-100"> <img src="/Content/ajax-loader.gif" class="loader loading-icon fa-lg"></div>');
}

var removeAjaxLoader = function (tableId) {
    $('#' + tableId + "_loading_overlay").remove();
}


function ShowMSG(msg, msgType, _icon) {
    $.notify({
        icon: _icon,
        title: '',
        message: msg
    }, {
            type: msgType,//'minimalist',// type: "info",
            delay: 5000,
            icon_type: 'class',
            allow_dismiss: true,
            newest_on_top: true,
            offset: 20,
            timer: 1000,
            spacing: 10,
            animate: {
                enter: 'animated fadeInDown',
                exit: 'animated fadeOutUp'
            },
            template: '<div data-notify="container" class="col-xs-11 col-sm-3 alert alert-{0}" role="alert">' +
            '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">&times;</button>' +
            '<i data-notify="icon" class="img-circle pull-left">' +
            //'<span data-notify="title"> {1}</span>' +
            '<span data-notify="message"> {2}</span>' +
            '</div>'
        });
}

//-------------------- Delete Confirmation box-------------------------
window.deleteConfirmation =
    (function () {
    debugger;
        $('.confirmation').click(function (e) {
            var href = $(this).attr('href');

            swal({
                title: "Are you sure?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel it!",
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        window.location.href = href;
                    }
                });

            return false;
        });
    });
 
$(document).on("click", '.confirmationsatus', function (e) {
    var href = $(this).attr('href');
    swal({
        title: "Are you sure?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, change it!",
        cancelButtonText: "No, close it!",
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {
                window.location.href = href;
            }
        });

    return false;
})

$(document).on("click", '.deleteconfirm', function (e) {
    var href = $(this).attr('href');
    swal({
        title: "Are you sure?",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "No, cancel it!",
        closeOnConfirm: true,
        closeOnCancel: true
    },
        function (isConfirm) {
            if (isConfirm) {
                window.location.href = href;
            }
        });

    return false;
})


var showLoading = function (setting) {
    setting = jQuery.extend({ Text: 'Please Wait...', Effect: 'ios', background: 'rgba(160, 160, 160, 0.48)', ColorCode: '#000', SizeW: '', SizeH: '', dvContent: 'dvWaitMe' }, setting);
    var $container = $('#' + setting.dvContent);
    if ($container.length) {
        //clear if already opened.
        $container.removeAttr('class').hide().children().remove();
        $container.css({
            'width': '100%',
            'height': '100%',
            'position': 'fixed',
            'top': '0',
            'left': '0',
            'z-index': '99999',
            'display': 'none'
        });
        $('body').addClass('ajax-waitme');
        $container.waitMe({
            effect: setting.Effect,
            text: setting.Text,
            bg: setting.background,
            color: setting.ColorCode,
            sizeW: setting.SizeW,
            sizeH: setting.SizeH
        });
        $container.show();
    }
};
var hideLoading = function (setting) {
    setting = jQuery.extend({ dvContent: 'dvWaitMe' }, setting);
    var $container = $('#' + setting.dvContent);
    $container.removeAttr('class').hide().children().remove();
    $('body').removeClass('ajax-waitme');
};