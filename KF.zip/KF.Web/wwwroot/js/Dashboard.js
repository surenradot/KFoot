﻿(function ($) {
    'use strict';
    function Dashboard() {
        var $this = this;
        var $loader = '<i class="fa fa-circle-o-notch fa-spin"></i>';

        function initEvents() {
            FeesStructureChart();
            TotalStudent();
            TotalSTAttendance();
            TotalStaff();
            TotalDueFee();
        }


        function TotalStudent() {

            var $totalStudent = $("#totalStudent");
            $totalStudent.html($loader);
            $.ajax({
                type: "POST",
                //data: { deepLink: polyUrl },
                url: "/home/TotalStudant",
                dataType: "json",
                success: function (result) {
                    if (result.isSucess) {
                        $totalStudent.html(result.data);
                    } else {
                        $totalStudent.html("0");
                    }
                },
                complete: function () {
                    //$totalStudent.parent().find('.loader')
                }
            });
        }

        function TotalSTAttendance() {

            var $totalSTAttendance = $("#TotalSTAttendance");
            $totalSTAttendance.html($loader);
            $.ajax({
                type: "POST",
                //data: { deepLink: polyUrl },
                url: "/home/TotalSTAttendance",
                dataType: "json",
                success: function (result) {
                    if (result.isSucess) {
                        $totalSTAttendance.html(result.data + '<sup style="font-size: 20px">%</sup>');
                    } else {
                        $totalSTAttendance.html('0 <sup style="font - size: 20px">%</sup>');
                    }
                },
                complete: function () {
                    //$totalStudent.parent().find('.loader')
                }
            });
        }

        function TotalStaff() {

            var $totalStaff = $("#TotalStaff");
            $totalStaff.html($loader);
            $.ajax({
                type: "POST",
                //data: { deepLink: polyUrl },
                url: "/home/TotalStaff",
                dataType: "json",
                success: function (result) {
                    if (result.isSucess) {
                        //$totalStaff.html(result.data);
                        $totalStaff.html(result.data + '<sup style="font-size: 20px">%</sup>');
                    } else {
                        $totalStaff.html('0');
                    }
                },
                complete: function () {
                    //totalStaff.parent().find('.loader')
                }
            });
        }

        function TotalDueFee() {

            var TotalDueFee = $("#TotalDueFee");
            TotalDueFee.html($loader);
            $.ajax({
                type: "POST",
                url: "/home/TotalDueFee",
                dataType: "json",
                success: function (result) {
                    if (result.isSucess) {
                        TotalDueFee.html(result.data + '<sup style="font-size: 20px">%</sup>');
                    } else {
                        TotalDueFee.html('0');
                    }
                },
                complete: function () {
                }
            });
        }

        function FeesStructureChart() {


            $.ajax({
                type: "POST",                
                url: "/home/FeesStructureChart",
                dataType: "json",
                success: function (result) {

                    var dataarr = new Array();
                    for (var i = 0; i < result.data.length; i++) {
                        dataarr.push({m: result.data[i].year, Received:result.data[i].received, Due: result.data[i].due});
                    }
                    //Area /Line /Bar
                    var area = new Morris.Area({
                        element: 'feestructure-chart',
                        resize: true,
                        data: dataarr,
                        xkey: 'm',
                        ykeys: ['Received', 'Due'],
                        labels: ['Received', 'Due'],
                        lineColors: ['#a0d0e0', '#3c8dbc'],
                        hideHover: 'auto'
                    });
                    area.redraw();

                },
                complete: function () {

                }
            });


        }

        $this.init = function () {
            initEvents();
        };
    }
    $(function () {
        var self = new Dashboard();
        self.init();
    });

}(jQuery));
