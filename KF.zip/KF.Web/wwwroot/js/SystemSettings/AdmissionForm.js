﻿(function ($) {
    function Index() {
        var $this = this, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Name", "data": "Name", "orderable": false, "searchable": false },
                    { "title": "Father Name", "data": "FatherName", "orderable": false, "searchable": false },
                    { "title": "Class Name", "data": "ClassName", "orderable": false, "searchable": false },
                    { "title": "Address", "data": "Address", "orderable": false, "searchable": false },
                    { "title": "session", "data": "session", "orderable": false, "searchable": false },
                    { "title": "Receipt Date", "data": "ReceiptDate", "orderable": false, "searchable": false },
                    { "title": "Form No", "data": "FormNo", "orderable": false, "searchable": false },
                    { "title": "Receipt No", "data": "ReceiptNo", "orderable": false, "searchable": false },
                    { "title": "Amount", "data": "Amount", "orderable": false, "searchable": false },

                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/Inquiry/print/" + record.Id + "' title='Print'  target='_blank' class='badge btnpvoucherprint btn-sm bg-light'><i class='fa fa-print'></i></a>";
                            return btns;
                        }
                    }],
                //order: [[0, "asc"]],
                url: route,
                fnCallBack:function() {                    
                    $(".print-btn").click(function () {                        
                        $.get($(this).data('url'), function (response) {
                            Global.Print(response, 'AdmissionForm');
                        });
                    });
                }
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/AdmissionForm/create' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Create</a>");
        }



        $this.init = function () {
            initializeGrid();
        }
    }

    $(function () {
        var self = new Index();
        self.init();
    })
})(jQuery)