﻿(function ($) {
    function Index() {
        var $this = this, form;

        function initializeGrid() {
            BindGrid({
                'sDom': "<'row'<'col-sm-6'l><'col-sm-6'<'#buttonContainer.site-datatable-button-container'>f>>" + "<'row'<'col-sm-12'tr>>" + "<'row'<'col-sm-5'i><'col-sm-7'p>>",
                columns: [
                    { "title": "Class Name", "data": "Name", "orderable": true, "searchable": true },
                    //{ "title": "Next Class Name", "data": "NextClass", "orderable": true, "searchable": true },
                    {
                        "data": null, "title": "Action",
                        "targets": -1,
                        "width": "20%",
                        "class": "column-action text-center",
                        "shorting": false,
                        "orderable": false,
                        "mRender": function (data, type, record) {
                            var btns = '';
                            btns += "<a href='/classlist/view/" + record.Id + "' title='View' class='badge btn-sm bg-light-blue-gradient'><i class='fa fa-eye'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/classlist/modify/" + record.Id + "' title='Edit' class='badge btn-sm bg-yellow-gradient'><i class='fa fa-pencil'></i></a>";
                            btns += "&nbsp;&nbsp;<a href='/classlist/deleteconfirm/" + record.Id + "' title= 'Delete' class='badge btn-sm bg-red-gradient'><i class='fa fa-trash-o'></i></a >";
                            return btns;
                        }
                    }],
                //order: [[0, "asc"]],
                url: route
            });
            $("#buttonContainer").addClass("pull-right").append("<a href='/classlist/create' class='btn btn-sm btn-primary mg-l-5'><i class='fa fa-plus'></i> Create</a>");
        }



        $this.init = function () {
            initializeGrid();
        }
    }

    $(function () {
        var self = new Index();
        self.init();
    })
})(jQuery)