﻿namespace KF.Core
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// DataTableSearch
    /// </summary>
    public class DataTableSearch
    {
        public string Value { get; set; }

        public bool Regex { get; set; }
    }
}
