﻿
namespace KF.Core
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// DataTableOrder
    /// </summary>
    public class DataTableOrder
    {
        public int Column { get; set; }


        public string Dir { get; set; }
    }
}
