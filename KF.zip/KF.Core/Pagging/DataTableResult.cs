﻿namespace KF.Core
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    /// <summary>
    /// DataTableResult
    /// </summary>
    public class DataTableResult
    {
        [JsonProperty(PropertyName = "draw")]
        public int Draw { get; set; }


        [JsonProperty(PropertyName = "recordsTotal")]
        public int RecordsTotal { get; set; }


        [JsonProperty(PropertyName = "recordsFiltered")]
        public int RecordsFiltered { get; set; }


        [JsonProperty(PropertyName = "error")]
        public object Error { get; set; }


        [JsonProperty(PropertyName = "data")]
        public List<object> Data { get; set; }
    }
}
