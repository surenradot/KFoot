﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KF.Core
{
    public enum DataTableFilterType
    {
        Contains = 0,
        Equals = 1,
        StartsWith = 2,
        LessThanOrEqual = 3,
        GreaterThanOrEqual = 4
    }
}
