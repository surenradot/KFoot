
    CREATE TABLE [dbo].[Role](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](50) NOT NULL
	)

	INSERT INTO [dbo].[Role](Name) VALUES('Admin');
	INSERT INTO [dbo].[Role](Name) VALUES('User');


	CREATE TABLE [dbo].[User](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[RoleId] [INT] NOT NULL,
	[Email] [NVARCHAR](50) NOT NULL,
	[Password] [NVARCHAR](256) NOT NULL,
	[SaltKey] [NVARCHAR](64) NOT NULL,
	[OTPCode] [NVARCHAR](64)  NULL,
	[FirstName] [NVARCHAR](50) NOT NULL,
	[MiddleName] [NVARCHAR](50) NULL,
	[LastName] [NVARCHAR](50) NOT NULL,
	[MobileNo] [NVARCHAR](10) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[IsEmailVerify] [bit] NOT NULL,
	CONSTRAINT FK_User_Role_RoleId FOREIGN KEY([RoleId]) REFERENCES [Role] ([Id])
	)


	INSERT INTO [dbo].[User](RoleId,Email,Password,SaltKey,FirstName,LastName,MiddleName,MobileNo,IsActive,IsEmailVerify) 
	VALUES(1,'admin@admin.com','92A721E0B1D79B10929AA850A51740C8','b746c124-8c52-4346-90a9-325d0ce3cd44','Surendra','Kandira',NULL,'9876543210',1,1);


	CREATE TABLE [dbo].[Group](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](256) NOT NULL,
	[PageUrl] [NVARCHAR](256) NOT NULL,
	[Title] [NVARCHAR](256),
	[MetaKeyword] [NVARCHAR](256),
	[MetaDescription] [NVARCHAR](1000),
	[ImageName] [NVARCHAR](100),
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL	
	)


	CREATE TABLE [dbo].[Category](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[GroupId] [INT] NOT NULL,
	[Name] [NVARCHAR](256) NOT NULL,
	[PageUrl] [NVARCHAR](256) NOT NULL,
	[Title] [NVARCHAR](256),
	[MetaKeyword] [NVARCHAR](256),
	[MetaDescription] [NVARCHAR](1000),
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	CONSTRAINT FK_Category_Group_GroupId FOREIGN KEY([GroupId]) REFERENCES [Group] ([Id])
	)



	CREATE TABLE [dbo].[MaterialType](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](256) NOT NULL,	
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	)

	CREATE TABLE [dbo].[Color](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](256) NOT NULL,
	[Code] [NVARCHAR](10) NOT NULL,	
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	)

	CREATE TABLE [dbo].[Size](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,	
	[Name] [NVARCHAR](10) NOT NULL,
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	)


	CREATE TABLE [dbo].[Vendor](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](256) NOT NULL,
	[GSTNo] [NVARCHAR](10) NOT NULL,	
	[PhoneNo] [NVARCHAR](15) NULL,	
	[MobileNo] [NVARCHAR](10) NOT NULL,
	[Email] [NVARCHAR](256) NOT NULL,	
	[City] [NVARCHAR](256) NOT NULL,	
	[Address] [NVARCHAR](256) NOT NULL,	
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	)


	CREATE TABLE [dbo].[HSNCode](
	Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	Code NVARCHAR(500) NOT NULL,
	CGST DECIMAL(18,2) NOT NULL,
	SGST DECIMAL(18,2) NOT NULL,
	IGST DECIMAL(18,2) NOT NULL,
	Cess DECIMAL(18,2) NULL,
	[Description] NVARCHAR(500) NULL,
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	)


	CREATE TABLE [dbo].[Product](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Name] [NVARCHAR](256) NOT NULL,
	[PageUrl] [NVARCHAR](256) NOT NULL,
	[Code] [NVARCHAR](20) NOT NULL,	
	[Description] [NVARCHAR](500) NOT NULL,		
	[GroupId] [INT] NOT NULL,	
	[CategoryId] [INT] NOT NULL,	
	[HSNCodeId] [INT] NOT NULL,	
	[MaterialTypeId] [INT]  NULL,
	[MaterialDescription] [NVARCHAR](500) NOT NULL,
	[Retail] [DECIMAL] NOT NULL,	
	[Wholesale] [DECIMAL] NOT NULL,
	[Discount] [DECIMAL] NULL,
	[DiscountType] [tinyINT] NULL,
	[IsActive] [bit] NOT NULL,	
	[IsHot] [bit] NOT NULL,
	[PrimaryImage] [NVARCHAR](100) NOT NULL,
	[Title] [NVARCHAR](256),
	[MetaKeyword] [NVARCHAR](256),
	[MetaDescription] [NVARCHAR](1000),
	[CreatedBy] [NVARCHAR](256) NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyBy] [NVARCHAR](256) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL
	CONSTRAINT FK_Product_Group_GroupId FOREIGN KEY([GroupId]) REFERENCES [Group] ([Id]),
	CONSTRAINT FK_Product_Categorye_CategoryId FOREIGN KEY([CategoryId]) REFERENCES [Category] ([Id]),
	CONSTRAINT FK_Product_HSNCode_HSNCodeId FOREIGN KEY([HSNCodeId]) REFERENCES [HSNCode] ([Id]),
	CONSTRAINT FK_Product_MaterialType_MaterialTypeId FOREIGN KEY([MaterialTypeId]) REFERENCES [MaterialType] ([Id])
	)	

	CREATE TABLE [dbo].[ProductSize](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[ProductId] [INT] NOT NULL,
	[SizeId] [INT] NOT NULL,	
	CONSTRAINT FK_ProductSize_Product_ProductId FOREIGN KEY([ProductId]) REFERENCES [Product] ([Id]),
	CONSTRAINT FK_ProductSize_Size_SizeId FOREIGN KEY([SizeId]) REFERENCES [Size] ([Id])
	)	
	
	CREATE TABLE [dbo].[ProductColor](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[ProductId] [INT] NOT NULL,
	[ColorId] [INT] NOT NULL,
	CONSTRAINT FK_ProductColor_Product_ProductId FOREIGN KEY([ProductId]) REFERENCES [Product] ([Id]),
	CONSTRAINT FK_ProductColor_Color_ColorId FOREIGN KEY([ColorId]) REFERENCES [Color] ([Id])
	)



	CREATE TABLE [dbo].[ProductImage](
	[Id] [INT] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[ProductId] [INT] NOT NULL,
	[Name] [NVARCHAR](100) NOT NULL,
	[CreatedBy] [INT] NOT NULL,
	[CreatedDate] [DATETIME2](7) NOT NULL,
	[ModifyDate] [DATETIME2](7) NOT NULL,
	CONSTRAINT FK_ProductImage_Product_ProductId FOREIGN KEY([ProductId]) REFERENCES [Product] ([Id]),
	CONSTRAINT FK_ProductImage_User_UseId FOREIGN KEY([CreatedBy]) REFERENCES [User] ([Id])
	)




	CREATE TABLE [dbo].[Order](
	[Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[UserId] [INT] NOT NULL,
	[ShippingAddress] [NVARCHAR](500)  NOT NULL,
	[OrderNumer] INT NOT NULL,
	[PaymentModeId] [INT] NOT NULL, -- COD,Online Payment
	[OrderDate] [DATETIME2] NOT NULL,
	[NetAmount] [DECIMAL](10,2)  NOT NULL, 
	[ShippingAmount] [DECIMAL](10,2) NOT NULL,
	[IGST] [DECIMAL](18,2) NOT NULL,
	[CGST] [DECIMAL](18,2) NOT NULL,
	[SGST] [DECIMAL](18,2) NOT NULL,
	[TotalAmount] [DECIMAL](10,2)  NOT NULL,
	DeliveryDate DATETIME2 NOT NULL,
	[Status] [INT] NOT NULL,  -- shipping in process, Canceled, Returned,Delivered
	[StatusDate] [DATETIME2] NOT NULL,
	CONSTRAINT FK_Order_User_UserId FOREIGN KEY([UserId]) REFERENCES [User] ([Id])
	)



	CREATE TABLE [dbo].[OrderDetail](
	Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	OrderId INT NOT NULL,
	ProductId INT NOT NULL,
	Product  	NVARCHAR(250)  NOT NULL,
	Size  	NVARCHAR(250)  NOT NULL,
	Color NVARCHAR(250) NOT NULL,
	Price DECIMAL(10,2) NOT NULL,
	Quantity INT  NOT NULL,
	Discount DECIMAL(10,2) NOT NULL,
	[NetAmount] [DECIMAL](10,2)  NOT NULL, 
	IGST DECIMAL(18,2) NOT NULL,
	CGST DECIMAL(18,2) NOT NULL,
	SGST DECIMAL(18,2) NOT NULL,
	TotalAmount	DECIMAL(10,2) NOT NULL
	CONSTRAINT FK_OrderDetail_Order_OrderId FOREIGN KEY([OrderId]) REFERENCES [Order] ([Id]),
	CONSTRAINT FK_OrderDetail_Product_ProductId FOREIGN KEY([ProductId]) REFERENCES [Product] ([Id])
	)

	CREATE TABLE [dbo].[Payment](
	Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[UserId] INT NOT NULL,
	[OrderId] INT NOT NULL,
	[TotalAmount] DECIMAL(10,2)  NOT NULL, 
	[Received Amount] DECIMAL(10,2)  NOT NULL, 
	[RemainingAmount] DECIMAL(10,2)  NOT NULL, 
	[TransactionId] NVARCHAR(256),
	[TransactionResponse] NVARCHAR(max),
	[Status] INT NOT NULL,  -- Cancel,Partial, Complete
	[PaymentDate] DATETIME2 NOT NULL,
	[Reason] NVARCHAR(500)
	CONSTRAINT FK_Payment_User_UserId FOREIGN KEY([UserId]) REFERENCES [User] ([Id]),
	CONSTRAINT FK_Payment_Order_OrderId FOREIGN KEY([OrderId]) REFERENCES [Order] ([Id])
	)



	CREATE TABLE [dbo].[ReturnOrder](
	Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[UserId] INT NOT NULL,
	[OrderId] INT NOT NULL,
	[RefundAmount] DECIMAL(10,2)  NOT NULL, 
	[Status] INT NOT NULL,  -- Cancel, Return
	[StatusDate] DATETIME2 NOT NULL,
	[IsRefund] bit NOT NULL
	CONSTRAINT FK_ReturnOrder_User_UserId FOREIGN KEY([UserId]) REFERENCES [User] ([Id]),
	CONSTRAINT FK_ReturnOrder_Order_OrderId FOREIGN KEY([OrderId]) REFERENCES [Order] ([Id])
	)

	CREATE TABLE [dbo].ProductInquiry(
	Id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ProductId INT NOT NULL,
	Product  NVARCHAR(250)  NOT NULL,
	Quantity INT NULL,
	ContactName NVARCHAR(250) NOT NULL,
	BusinessName NVARCHAR(250) NULL,
	MobileNo NVARCHAR(12) NOT NULL,
	Email NVARCHAR(250) NULL,
	Location NVARCHAR(250) NULL,
	Remark NVARCHAR(500),
	CreatedDate DATETIME2 NOT NULL,
	CONSTRAINT FK_ProductInquiry_Product_ProductId FOREIGN KEY([ProductId]) REFERENCES [Product] ([Id])
	)


	CREATE TABLE [dbo].Slider(
	Id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Name NVARCHAR(250) NOT NULL,
	IsActive bit NOT NULL
	) 



	CREATE TABLE [dbo].Gallery(
	Id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ImageName NVARCHAR(100) NOT NULL,
	Title NVARCHAR(500),
	CreatedDate DATETIME2 NOT NULL,
	)



	CREATE TABLE [dbo].[Carrier](
	Id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	[OrderId] INT NOT NULL,
	[Name] NVARCHAR(250) NOT NULL,
	[Description] NVARCHAR(250) NOT NULL,
	[CarrierId] NVARCHAR(250) NOT NULL,
	[TrackUrl] NVARCHAR(256) NOT NULL,
	[DeliveryDate] DATETIME2 NOT NULL,
	[CreatedDate] DATETIME2 NOT NULL,
	[ModifyDate] DATETIME2 NOT NULL,
	CONSTRAINT FK_Carrier_Order_OrderId FOREIGN KEY([OrderId]) REFERENCES [Order] ([Id])
	)



	CREATE TABLE [dbo].[CMSPage](
	Id INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	PageUrl  NVARCHAR(256) NOT NULL,
	Title NVARCHAR(256) NOT NULL,
	Content NVARCHAR(max) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [DATETIME] NOT NULL,
	[ModifiedDate] [DATETIME] NOT NULL,
	)

	INSERT INTO CMSPage(PageUrl,Title,Content,IsActive,CreatedDate,ModifiedDate)
	VALUES
	('about-us',' ',' ',1,GETDATE(),GETDATE()),
	('contact-us',' ',' ',1,GETDATE(),GETDATE()),
	('terms-conditions','','',1,GETDATE(),GETDATE()),
	('help','','',1,GETDATE(),GETDATE()),
	('shipping-tax','','',1,GETDATE(),GETDATE()),
	('return-policy','','',1,GETDATE(),GETDATE()),
	('delivery','','',1,GETDATE(),GETDATE()),
	('legal-notice','','',1,GETDATE(),GETDATE())