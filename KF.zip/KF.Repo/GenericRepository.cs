﻿

namespace KF.Repo
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using KF.Core;
    using KF.Data;
    using Microsoft.EntityFrameworkCore;

    public partial class GenericRepository<T> : ToPaggedList, IGenericRepository<T>
         where T : class
    {
        private readonly KandiraFootwareContext context;
       
        private DbSet<T> dbSet;

        /// <summary>
        /// The disposed
        /// </summary>
        private bool disposed = false;

      
        public GenericRepository(KandiraFootwareContext context)
        {
            this.context = context;
            this.dbSet = context.Set<T>();
        }
        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        public IQueryable<T> GetAll()
        {
            return this.dbSet;
        }

        /// <summary>
        /// Gets all asyn.
        /// </summary>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        public virtual async Task<ICollection<T>> GetAllAsync()
        {
            try
            {
                return await this.dbSet.AsNoTracking().ToListAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        /// <summary>
        /// Gets the specified identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual T Get(object id)
        {
            return this.dbSet.Find(id);
        }

        /// <summary>
        /// Gets the asynchronous.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual async Task<T> GetAsync(object key)
        {
            return await this.dbSet.FindAsync(key);
        }

        /// <summary>
        /// Adds the specified t.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual T Add(T t)
        {
            this.dbSet.Add(t);
            ////this.context.SaveChanges();
            return t;
        }

        /// <summary>
        /// Adds the asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual async Task<T> AddAsyn(T t)
        {
            this.dbSet.Add(t);
            await this.context.SaveChangesAsync();
            return t;
        }

        public virtual async Task<List<T>> AddRangeAsyn(List<T> t)
        {
            try
            {
                this.dbSet.AddRange(t);
                await this.context.SaveChangesAsync();
                return t;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Finds the specified match.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual T Find(Expression<Func<T, bool>> match)
        {
            return this.dbSet.AsNoTracking().SingleOrDefault(match);
        }

        /// <summary>
        /// Finds the asynchronous.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual async Task<T> FindAsync(Expression<Func<T, bool>> match)
        {
            return await this.dbSet.AsNoTracking().SingleOrDefaultAsync(match);
        }

        /// <summary>
        /// Finds all.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        public ICollection<T> FindAll(Expression<Func<T, bool>> match)
        {
            return this.dbSet.AsNoTracking().Where(match).ToList();
        }

        /// <summary>
        /// Finds all asynchronous.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        public async Task<ICollection<T>> FindAllAsync(Expression<Func<T, bool>> match)
        {
            return await this.dbSet.AsNoTracking().Where(match).ToListAsync();
        }

        /// <summary>
        /// Deletes the specified entity.
        /// </summary>
        /// <param name="key">The key.</param>
        public virtual void Delete(object key)
        {
            var entity = this.Get(key);
            this.dbSet.Remove(entity);
            ////this.context.SaveChanges();
        }

        /// <summary>
        /// Deletes the asyn.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns>
        /// Integer Value
        /// </returns>
        public virtual async Task<int> DeleteAsyn(object id)
        {
            var entity = await this.GetAsync(id);

            this.dbSet.Remove(entity);
            return await this.context.SaveChangesAsync();
        }

        public virtual async Task<int> DeleteEntityAsyn(T entity)
        {
            this.dbSet.Remove(entity);
            return await this.context.SaveChangesAsync();
        }

        public virtual async Task<int> DeleteRangeAsyn(List<T> entity)
        {
            this.dbSet.RemoveRange(entity);
            return await this.context.SaveChangesAsync();
        }

        public virtual void DeleteEntity(T entity)
        {
            this.dbSet.Remove(entity);
        }

        public virtual void DeleteRange(List<T> entity)
        {
            this.dbSet.RemoveRange(entity);
        }

        /// <summary>
        /// Updates the specified t.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        public virtual T Update(T t, object key)
        {
            if (t == null)
            {
                return null;
            }

            T exist = this.dbSet.Find(key);
            if (exist != null)
            {
                ////this.context.Entry(exist).OriginalValues["RowVersion"] = rowVersion;

                this.context.Entry(exist).CurrentValues.SetValues(t);
                ////this.context.SaveChanges();
            }

            return exist;
        }

        /// <summary>
        /// Updates the asyn.
        /// </summary>
        /// <param name="t">The t.</param>
        /// <param name="key">The key.</param>
        /// <returns>
        /// Type of Entity
        /// </returns>
        //public virtual async Task<T> UpdateAsync(T t, object key)
        //{
        //    if (t == null)
        //    {
        //        return null;
        //    }

        //    T exist = await this.dbSet.FindAsync(key);
        //    if (exist != null)
        //    {
        //        this.context.Entry(exist).CurrentValues.SetValues(t);
        //        await this.context.SaveChangesAsync();
        //    }

        //    return exist;
        //}

        public virtual async Task<T> UpdateAsync(T t, object key, DateTime RowVersion)
        {
            if (t == null)
            {
                return null;
            }

            T exist = await this.dbSet.FindAsync(key);
            if (exist != null)
            {
                this.context.Entry(exist).CurrentValues.SetValues(t);
                //  this.context.Entry(exist).Property("RowVersion").OriginalValue = RowVersion;

                try
                {
                    await this.context.SaveChangesAsync();
                }
                catch (Exception ex)
                {

                    throw ex;
                }


            }

            return exist;
        }

        public virtual async Task<T> UpdateAsync(T t, object key)
        {
            if (t == null)
            {
                return null;
            }

            T exist = await this.dbSet.FindAsync(key);
            if (exist != null)
            {
                this.context.Entry(exist).CurrentValues.SetValues(t);
                await this.context.SaveChangesAsync();
            }

            return exist;
        }

        public virtual async Task<List<T>> UpdateAsync(List<T> entity)
        {

            this.dbSet.UpdateRange(entity);
            await this.context.SaveChangesAsync();
            return entity;
        }

        /// <summary>
        /// Counts this instance.
        /// </summary>
        /// <returns>
        /// Integer Value
        /// </returns>
        public int Count()
        {
            return this.dbSet.Count();
        }

        /// <summary>
        /// Counts the asynchronous.
        /// </summary>
        /// <returns>
        /// Interger Value
        /// </returns>
        public async Task<int> CountAsync()
        {
            return await this.dbSet.CountAsync();
        }

        /// <summary>
        /// Saves this instance.
        /// </summary>
        public virtual void Save()
        {
            this.context.SaveChanges();
        }



        /// <summary>
        /// Saves the asynchronous.
        /// </summary>
        /// <returns>
        /// Integer Value
        /// </returns>
        public async virtual Task<int> SaveAsync()
        {
            return await this.context.SaveChangesAsync();
        }

        /// <summary>
        /// Finds the by.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        public virtual IQueryable<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            IQueryable<T> query = this.dbSet.Where(predicate);
            return query;
        }

        /// <summary>
        /// Finds the by asyn.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns>
        /// Collection of Type of Entity
        /// </returns>
        public virtual async Task<ICollection<T>> FindByAsyn(Expression<Func<T, bool>> predicate)
        {
            return await this.dbSet.Where(predicate).ToListAsync();
        }
        /// <summary>
        /// Records the count.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns></returns>
        public virtual int RecordCount(Expression<Func<T, bool>> predicate)
        {
            IQueryable<T> query = this.dbSet.Where(predicate);
            return query.Count();
        }
        /// <summary>
        /// Records the count asyn.
        /// </summary>
        /// <param name="predicate">The predicate.</param>
        /// <returns></returns>
        public virtual async Task<int> RecordCountAsyn(Expression<Func<T, bool>> predicate)
        {
            IQueryable<T> query = this.dbSet.Where(predicate);
            return await query.CountAsync();
        }
        /// <summary>
        /// Gets all including.
        /// </summary>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// Queryable Type of Entity
        /// </returns>
        public IQueryable<T> GetAllIncluding(Expression<Func<T, bool>> match, Func<IQueryable<T>, IQueryable<T>> includeMembers = null)
        {
            // IQueryable<T> queryable = this.GetAll();
            IQueryable<T> queryable = this.FindBy(match);
            IQueryable<T> result = includeMembers(queryable);

            return result;
        }

        /// <summary>
        /// Gets all including asyn.
        /// </summary>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// collection
        /// </returns>
        public async Task<ICollection<T>> GetAllIncludingAsyn(Expression<Func<T, bool>> match, Func<IQueryable<T>, IQueryable<T>> includeMembers = null)
        {
            // IQueryable<T> queryable = this.GetAll();
            IQueryable<T> queryable = this.FindBy(match);
            IQueryable<T> result;
            if (includeMembers != null)
            {
                result = includeMembers(queryable);
            }
            else
            {
                result = queryable;
            }
            return await result.ToListAsync();
        }



        public IQueryable<T> GetAllIncludingIQueryableAsyn(Func<IQueryable<T>, IQueryable<T>> includeMembers = null)
        {
            IQueryable<T> queryable = this.GetAll();
            IQueryable<T> result;
            if (includeMembers != null)
            {
                result = includeMembers(queryable);
            }
            else
            {
                result = queryable;
            }
            return result;
        }


        public IQueryable<T> GetAllIncludingIQueryableAsyn(Expression<Func<T, bool>> predicate, Func<IQueryable<T>, IQueryable<T>> includeMembers = null)
        {
            IQueryable<T> queryable = this.dbSet.Where(predicate);
            IQueryable<T> result;
            if (includeMembers != null)
            {
                result = includeMembers(queryable);
            }
            else
            {
                result = queryable;
            }
            return result;
        }

        /// <summary>
        /// Gets all including by identifier asyn.
        /// </summary>
        /// <param name="match">The match.</param>
        /// <param name="includeMembers">The include members.</param>
        /// <returns>
        /// Type of entity
        /// </returns>
        public async Task<T> GetIncludingByIdAsyn(Expression<Func<T, bool>> match, Func<IQueryable<T>, IQueryable<T>> includeMembers = null)
        {
            IQueryable<T> queryable = this.FindBy(match);
            //IQueryable<T> result = includeMembers(queryable);
            IQueryable<T> result;
            if (includeMembers != null)
            {
                result = includeMembers(queryable);
            }
            else
            {
                result = queryable;
            }
            return await result.SingleOrDefaultAsync();
        }

        /// <summary>
        /// To the paged list asynchronous.
        /// </summary>
        /// <param name="query">The query.</param>
        /// <param name="model">The model.</param>
        /// <returns>
        /// Get Pagging Entites List By Querable Data with search parameters
        /// </returns>
        public async Task<DataTableResult> ToPagedListAsync(IQueryable<T> query, DataTableParameter model)
        {
            return await this.ToPaggedListAsync(query, model);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.context.Dispose();
                }

                this.disposed = true;
            }
        }

        public virtual async Task<ICollection<T>> GetIncludingFindByAsyn(Expression<Func<T, bool>> predicate, Func<IQueryable<T>, IQueryable<T>> includeMembers)
        {
            IQueryable<T> queryable = this.dbSet.Where(predicate);
            IQueryable<T> result = includeMembers(queryable);
            return await result.ToListAsync();
        }

        
    }
}
