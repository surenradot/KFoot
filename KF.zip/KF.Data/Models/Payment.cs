﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Payment
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int OrderId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal ReceivedAmount { get; set; }
        public decimal RemainingAmount { get; set; }
        public string TransactionId { get; set; }
        public string TransactionResponse { get; set; }
        public int Status { get; set; }
        public DateTime PaymentDate { get; set; }
        public string Reason { get; set; }

        public virtual Order Order { get; set; }
        public virtual User User { get; set; }
    }
}
