﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Product
    {
        public Product()
        {
            OrderDetail = new HashSet<OrderDetail>();
            ProductColor = new HashSet<ProductColor>();
            ProductImage = new HashSet<ProductImage>();
            ProductInquiry = new HashSet<ProductInquiry>();
            ProductSize = new HashSet<ProductSize>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string PageUrl { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public int GroupId { get; set; }
        public int CategoryId { get; set; }
        public int HsncodeId { get; set; }
        public int? MaterialTypeId { get; set; }
        public string MaterialDescription { get; set; }
        public decimal Retail { get; set; }
        public decimal Wholesale { get; set; }
        public decimal? Discount { get; set; }
        public byte? DiscountType { get; set; }
        public bool IsActive { get; set; }
        public bool IsHot { get; set; }
        public string PrimaryImage { get; set; }
        public string Title { get; set; }
        public string MetaKeyword { get; set; }
        public string MetaDescription { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifyBy { get; set; }
        public DateTime ModifyDate { get; set; }

        public virtual Category Category { get; set; }
        public virtual Group Group { get; set; }
        public virtual Hsncode Hsncode { get; set; }
        public virtual MaterialType MaterialType { get; set; }
        public virtual ICollection<OrderDetail> OrderDetail { get; set; }
        public virtual ICollection<ProductColor> ProductColor { get; set; }
        public virtual ICollection<ProductImage> ProductImage { get; set; }
        public virtual ICollection<ProductInquiry> ProductInquiry { get; set; }
        public virtual ICollection<ProductSize> ProductSize { get; set; }
    }
}
