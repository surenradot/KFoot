﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class ProductInquiry
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string Product { get; set; }
        public int? Quantity { get; set; }
        public string ContactName { get; set; }
        public string BusinessName { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public string Remark { get; set; }
        public DateTime CreatedDate { get; set; }

        public virtual Product ProductNavigation { get; set; }
    }
}
