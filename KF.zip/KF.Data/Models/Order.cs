﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Order
    {
        public Order()
        {
            Carrier = new HashSet<Carrier>();
            OrderDetail = new HashSet<OrderDetail>();
            Payment = new HashSet<Payment>();
            ReturnOrder = new HashSet<ReturnOrder>();
        }

        public int Id { get; set; }
        public int UserId { get; set; }
        public string ShippingAddress { get; set; }
        public int OrderNumer { get; set; }
        public int PaymentModeId { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal NetAmount { get; set; }
        public decimal ShippingAmount { get; set; }
        public decimal Igst { get; set; }
        public decimal Cgst { get; set; }
        public decimal Sgst { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DeliveryDate { get; set; }
        public int Status { get; set; }
        public DateTime StatusDate { get; set; }

        public virtual User User { get; set; }
        public virtual ICollection<Carrier> Carrier { get; set; }
        public virtual ICollection<OrderDetail> OrderDetail { get; set; }
        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<ReturnOrder> ReturnOrder { get; set; }
    }
}
