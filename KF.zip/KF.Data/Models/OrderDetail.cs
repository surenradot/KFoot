﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class OrderDetail
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public string Product { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal Discount { get; set; }
        public decimal NetAmount { get; set; }
        public decimal Igst { get; set; }
        public decimal Cgst { get; set; }
        public decimal Sgst { get; set; }
        public decimal TotalAmount { get; set; }

        public virtual Order Order { get; set; }
        public virtual Product ProductNavigation { get; set; }
    }
}
