﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class MaterialType
    {
        public MaterialType()
        {
            Product = new HashSet<Product>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifyBy { get; set; }
        public DateTime ModifyDate { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
