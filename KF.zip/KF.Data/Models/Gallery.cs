﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Gallery
    {
        public int Id { get; set; }
        public string ImageName { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
