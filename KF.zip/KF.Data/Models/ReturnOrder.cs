﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class ReturnOrder
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int OrderId { get; set; }
        public decimal RefundAmount { get; set; }
        public int Status { get; set; }
        public DateTime StatusDate { get; set; }
        public bool IsRefund { get; set; }

        public virtual Order Order { get; set; }
        public virtual User User { get; set; }
    }
}
