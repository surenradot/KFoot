﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class User
    {
        public User()
        {
            Order = new HashSet<Order>();
            Payment = new HashSet<Payment>();
            ProductImage = new HashSet<ProductImage>();
            ReturnOrder = new HashSet<ReturnOrder>();
        }

        public int Id { get; set; }
        public int RoleId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string SaltKey { get; set; }
        public string Otpcode { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string MobileNo { get; set; }
        public bool IsActive { get; set; }
        public bool IsEmailVerify { get; set; }

        public virtual Role Role { get; set; }
        public virtual ICollection<Order> Order { get; set; }
        public virtual ICollection<Payment> Payment { get; set; }
        public virtual ICollection<ProductImage> ProductImage { get; set; }
        public virtual ICollection<ReturnOrder> ReturnOrder { get; set; }
    }
}
