﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Hsncode
    {
        public Hsncode()
        {
            Product = new HashSet<Product>();
        }

        public int Id { get; set; }
        public string Code { get; set; }
        public decimal Cgst { get; set; }
        public decimal Sgst { get; set; }
        public decimal Igst { get; set; }
        public decimal? Cess { get; set; }
        public string Description { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifyBy { get; set; }
        public DateTime ModifyDate { get; set; }

        public virtual ICollection<Product> Product { get; set; }
    }
}
