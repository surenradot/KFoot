﻿using System;
using System.Collections.Generic;

namespace KF.Data.Models
{
    public partial class Carrier
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string CarrierId { get; set; }
        public string TrackUrl { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifyDate { get; set; }

        public virtual Order Order { get; set; }
    }
}
