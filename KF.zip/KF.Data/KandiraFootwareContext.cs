﻿using KF.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace KF.Data
{
    public partial class KandiraFootwareContext : DbContext
    {
        public KandiraFootwareContext()
        {
        }

        public KandiraFootwareContext(DbContextOptions<KandiraFootwareContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Carrier> Carrier { get; set; }
        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<Cmspage> Cmspage { get; set; }
        public virtual DbSet<Color> Color { get; set; }
        public virtual DbSet<Gallery> Gallery { get; set; }
        public virtual DbSet<Group> Group { get; set; }
        public virtual DbSet<Hsncode> Hsncode { get; set; }
        public virtual DbSet<MaterialType> MaterialType { get; set; }
        public virtual DbSet<Order> Order { get; set; }
        public virtual DbSet<OrderDetail> OrderDetail { get; set; }
        public virtual DbSet<Payment> Payment { get; set; }
        public virtual DbSet<Product> Product { get; set; }
        public virtual DbSet<ProductColor> ProductColor { get; set; }
        public virtual DbSet<ProductImage> ProductImage { get; set; }
        public virtual DbSet<ProductInquiry> ProductInquiry { get; set; }
        public virtual DbSet<ProductSize> ProductSize { get; set; }
        public virtual DbSet<ReturnOrder> ReturnOrder { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<Size> Size { get; set; }
        public virtual DbSet<Slider> Slider { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Vendor> Vendor { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=KANDIRA\\MSSQLSERVER01;Database=KandiraFootware;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Carrier>(entity =>
            {
                entity.Property(e => e.CarrierId)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.TrackUrl)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.Carrier)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Category>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.MetaDescription).HasMaxLength(1000);

                entity.Property(e => e.MetaKeyword).HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.PageUrl)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Title).HasMaxLength(256);

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.Category)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Cmspage>(entity =>
            {
                entity.ToTable("CMSPage");

                entity.Property(e => e.Content).IsRequired();

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.PageUrl)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Title)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<Color>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<Gallery>(entity =>
            {
                entity.Property(e => e.ImageName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Title).HasMaxLength(500);
            });

            modelBuilder.Entity<Group>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.ImageName).HasMaxLength(100);

                entity.Property(e => e.MetaDescription).HasMaxLength(1000);

                entity.Property(e => e.MetaKeyword).HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.PageUrl)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Title).HasMaxLength(256);
            });

            modelBuilder.Entity<Hsncode>(entity =>
            {
                entity.ToTable("HSNCode");

                entity.Property(e => e.Cgst).HasColumnName("CGST");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Igst).HasColumnName("IGST");

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Sgst).HasColumnName("SGST");
            });

            modelBuilder.Entity<MaterialType>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.Property(e => e.Cgst).HasColumnName("CGST");

                entity.Property(e => e.Igst).HasColumnName("IGST");

                entity.Property(e => e.NetAmount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Sgst).HasColumnName("SGST");

                entity.Property(e => e.ShippingAddress)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(e => e.ShippingAmount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Order)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.Property(e => e.Cgst).HasColumnName("CGST");

                entity.Property(e => e.Color)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Discount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Igst).HasColumnName("IGST");

                entity.Property(e => e.NetAmount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.Product)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Sgst).HasColumnName("SGST");

                entity.Property(e => e.Size)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.OrderDetail)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.ProductNavigation)
                    .WithMany(p => p.OrderDetail)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Payment>(entity =>
            {
                entity.Property(e => e.Reason).HasMaxLength(500);

                entity.Property(e => e.ReceivedAmount)
                    .HasColumnName("Received Amount")
                    .HasColumnType("decimal(10, 2)");

                entity.Property(e => e.RemainingAmount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.TotalAmount).HasColumnType("decimal(10, 2)");

                entity.Property(e => e.TransactionId).HasMaxLength(256);

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.Payment)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Payment)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(e => e.Discount).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.HsncodeId).HasColumnName("HSNCodeId");

                entity.Property(e => e.MaterialDescription)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(e => e.MetaDescription).HasMaxLength(1000);

                entity.Property(e => e.MetaKeyword).HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.PageUrl)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.PrimaryImage)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Retail).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.Title).HasMaxLength(256);

                entity.Property(e => e.Wholesale).HasColumnType("decimal(18, 0)");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Product_Categorye_CategoryId");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.GroupId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Hsncode)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.HsncodeId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.MaterialType)
                    .WithMany(p => p.Product)
                    .HasForeignKey(d => d.MaterialTypeId);
            });

            modelBuilder.Entity<ProductColor>(entity =>
            {
                entity.HasOne(d => d.Color)
                    .WithMany(p => p.ProductColor)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductColor)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ProductImage>(entity =>
            {
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.CreatedByNavigation)
                    .WithMany(p => p.ProductImage)
                    .HasForeignKey(d => d.CreatedBy)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ProductImage_User_UseId");

                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductImage)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ProductInquiry>(entity =>
            {
                entity.Property(e => e.BusinessName).HasMaxLength(250);

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Email).HasMaxLength(250);

                entity.Property(e => e.Location).HasMaxLength(250);

                entity.Property(e => e.MobileNo)
                    .IsRequired()
                    .HasMaxLength(12);

                entity.Property(e => e.Product)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Remark).HasMaxLength(500);

                entity.HasOne(d => d.ProductNavigation)
                    .WithMany(p => p.ProductInquiry)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ProductSize>(entity =>
            {
                entity.HasOne(d => d.Product)
                    .WithMany(p => p.ProductSize)
                    .HasForeignKey(d => d.ProductId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.Size)
                    .WithMany(p => p.ProductSize)
                    .HasForeignKey(d => d.SizeId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<ReturnOrder>(entity =>
            {
                entity.Property(e => e.RefundAmount).HasColumnType("decimal(10, 2)");

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.ReturnOrder)
                    .HasForeignKey(d => d.OrderId)
                    .OnDelete(DeleteBehavior.ClientSetNull);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.ReturnOrder)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Size>(entity =>
            {
                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<Slider>(entity =>
            {
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(250);
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.MiddleName).HasMaxLength(50);

                entity.Property(e => e.MobileNo)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Otpcode)
                    .HasColumnName("OTPCode")
                    .HasMaxLength(64);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.SaltKey)
                    .IsRequired()
                    .HasMaxLength(64);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.User)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull);
            });

            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.CreatedBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Gstno)
                    .IsRequired()
                    .HasColumnName("GSTNo")
                    .HasMaxLength(10);

                entity.Property(e => e.MobileNo)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.ModifyBy)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.PhoneNo).HasMaxLength(15);
            });
        }
    }
}
